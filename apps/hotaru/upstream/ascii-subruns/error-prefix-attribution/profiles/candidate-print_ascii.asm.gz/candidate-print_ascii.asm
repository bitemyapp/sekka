
/home/callen/work/hotaru-error-ascii-prefix-20261028/target/release/hotaru-replay:     file format elf64-x86-64


Disassembly of section .text:

0000000000045fa0 <hotaru_core::screen::State::print_ascii>:
   45fa0:	push   %rbp
   45fa1:	push   %r15
   45fa3:	push   %r14
   45fa5:	push   %r13
   45fa7:	push   %r12
   45fa9:	push   %rbx
   45faa:	sub    $0xf8,%rsp
   45fb1:	cmpb   $0x0,0xa02(%rdi)
   45fb8:	mov    %rdx,%r15
   45fbb:	mov    %rsi,%r12
   45fbe:	mov    %rdi,%r13
   45fc1:	je     46005 <hotaru_core::screen::State::print_ascii+0x65>
   45fc3:	test   %r15,%r15
   45fc6:	je     45ff3 <hotaru_core::screen::State::print_ascii+0x53>
   45fc8:	mov    0x5d261(%rip),%r14        # a3230 <_DYNAMIC+0x5d0>
   45fcf:	xor    %ebx,%ebx
   45fd1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   45fe0:	movzbl (%r12,%rbx,1),%esi
   45fe5:	mov    %r13,%rdi
   45fe8:	call   *%r14
   45feb:	inc    %rbx
   45fee:	cmp    %rbx,%r15
   45ff1:	jne    45fe0 <hotaru_core::screen::State::print_ascii+0x40>
   45ff3:	add    $0xf8,%rsp
   45ffa:	pop    %rbx
   45ffb:	pop    %r12
   45ffd:	pop    %r13
   45fff:	pop    %r14
   46001:	pop    %r15
   46003:	pop    %rbp
   46004:	ret
   46005:	mov    0x3b8(%r13),%rdi
   4600c:	cmp    $0x4,%rdi
   46010:	jae    4696e <hotaru_core::screen::State::print_ascii+0x9ce>
   46016:	cmpb   $0x0,0x6d8(%r13,%rdi,1)
   4601f:	jne    45fc3 <hotaru_core::screen::State::print_ascii+0x23>
   46021:	cmpq   $0x0,0x260(%r13)
   46029:	jne    45fc3 <hotaru_core::screen::State::print_ascii+0x23>
   4602b:	test   %r15,%r15
   4602e:	je     45ff3 <hotaru_core::screen::State::print_ascii+0x53>
   46030:	lea    0x6ea(%r13),%rax
   46037:	lea    0x130(%r13),%rdx
   4603e:	lea    0x38(%rsp),%rcx
   46043:	mov    %r13,0x40(%rsp)
   46048:	mov    %rax,0x78(%rsp)
   4604d:	mov    %rdx,0x48(%rsp)
   46052:	mov    %rcx,0x68(%rsp)
   46057:	jmp    46073 <hotaru_core::screen::State::print_ascii+0xd3>
   46059:	nopl   0x0(%rax)
   46060:	xor    %r15d,%r15d
   46063:	mov    0x28(%rsp),%rax
   46068:	add    %r15,%r12
   4606b:	sub    %r15,%rax
   4606e:	mov    %rax,%r15
   46071:	je     45ff3 <hotaru_core::screen::State::print_ascii+0x53>
   46073:	cmpb   $0x0,0x6df(%r13)
   4607b:	mov    %r13,%rbx
   4607e:	cmovne 0x48(%rsp),%rbx
   46084:	cmpb   $0x1,0x12f(%rbx)
   4608b:	jne    46118 <hotaru_core::screen::State::print_ascii+0x178>
   46091:	movzbl 0xa01(%r13),%eax
   46099:	mov    0x6ee(%r13),%ebp
   460a0:	movb   $0x0,0x12f(%rbx)
   460a7:	cmp    $0x1,%al
   460a9:	jne    46118 <hotaru_core::screen::State::print_ascii+0x178>
   460ab:	mov    %rbx,%rdi
   460ae:	call   49e00 <hotaru_core::screen::Screen::row>
   460b3:	movb   $0x1,0x6e(%rax)
   460b7:	movq   $0x0,0x90(%rbx)
   460c2:	movb   $0x0,0x12f(%rbx)
   460c9:	mov    0x98(%rbx),%rax
   460d0:	cmp    0x100(%rbx),%rax
   460d7:	jne    460ef <hotaru_core::screen::State::print_ascii+0x14f>
   460d9:	mov    $0x1,%esi
   460de:	mov    $0x1,%edx
   460e3:	mov    %rbx,%rdi
   460e6:	mov    %ebp,%ecx
   460e8:	call   49f60 <hotaru_core::screen::Screen::scroll_up>
   460ed:	jmp    46107 <hotaru_core::screen::State::print_ascii+0x167>
   460ef:	mov    0x38(%rbx),%rcx
   460f3:	inc    %rax
   460f6:	dec    %rcx
   460f9:	cmp    %rax,%rcx
   460fc:	cmovae %rax,%rcx
   46100:	mov    %rcx,0x98(%rbx)
   46107:	mov    %rbx,%rdi
   4610a:	call   49e00 <hotaru_core::screen::Screen::row>
   4610f:	mov    0x40(%rsp),%r13
   46114:	movb   $0x1,0x6f(%rax)
   46118:	mov    %r13,%rdi
   4611b:	mov    %r15,%rsi
   4611e:	call   47660 <hotaru_core::screen::State::scalar_metadata_writes>
   46123:	mov    %r15,0x28(%rsp)
   46128:	test   %al,%al
   4612a:	je     462d0 <hotaru_core::screen::State::print_ascii+0x330>
   46130:	cmpb   $0x0,0x6df(%r13)
   46138:	mov    %r13,%r14
   4613b:	mov    0x78(%rsp),%rcx
   46140:	cmovne 0x48(%rsp),%r14
   46146:	mov    (%rcx),%rax
   46149:	mov    0x6(%rcx),%rcx
   4614d:	cmpb   $0x1,0x12f(%r14)
   46155:	mov    %rcx,0x5e(%rsp)
   4615a:	mov    %rax,0x58(%rsp)
   4615f:	je     46060 <hotaru_core::screen::State::print_ascii+0xc0>
   46165:	movzbl 0x6e6(%r13),%eax
   4616d:	movzbl 0xa01(%r13),%edx
   46175:	movzbl 0xa04(%r13),%ecx
   4617d:	mov    %al,0x20(%rsp)
   46181:	mov    0x118(%r14),%rax
   46188:	mov    %dl,0x7(%rsp)
   4618c:	test   %rax,%rax
   4618f:	je     4619b <hotaru_core::screen::State::print_ascii+0x1fb>
   46191:	lock incq (%rax)
   46195:	jle    46905 <hotaru_core::screen::State::print_ascii+0x965>
   4619b:	mov    0x98(%r14),%rbx
   461a2:	mov    %rax,0x8(%rsp)
   461a7:	mov    %rax,0x38(%rsp)
   461ac:	cmp    0x38(%r14),%rbx
   461b0:	jae    4690b <hotaru_core::screen::State::print_ascii+0x96b>
   461b6:	add    0x30(%r14),%rbx
   461ba:	mov    0x20(%r14),%rax
   461be:	mov    0x28(%r14),%r13
   461c2:	mov    %cl,0x14(%rsp)
   461c6:	mov    $0x0,%ecx
   461cb:	mov    0x90(%r14),%r15
   461d2:	cmp    %rax,%rbx
   461d5:	cmovae %rax,%rcx
   461d9:	sub    %rcx,%rbx
   461dc:	mov    0x0(%r13,%rbx,8),%rax
   461e1:	mov    (%rax),%rax
   461e4:	mov    0x0(%r13,%rbx,8),%rbp
   461e9:	cmp    $0x1,%rax
   461ed:	je     46262 <hotaru_core::screen::State::print_ascii+0x2c2>
   461ef:	lea    0x8(%rbp),%rsi
   461f3:	lea    0x88(%rsp),%rdi
   461fb:	call   *0x5d037(%rip)        # a3238 <_DYNAMIC+0x5d8>
   46201:	mov    $0x78,%edi
   46206:	movq   $0x1,0x80(%rsp)
   46212:	call   *0x5cc30(%rip)        # a2e48 <malloc@GLIBC_2.2.5>
   46218:	test   %rax,%rax
   4621b:	je     46926 <hotaru_core::screen::State::print_ascii+0x986>
   46221:	vmovdqu64 0xb8(%rsp),%zmm1
   4622c:	vmovdqu64 0x80(%rsp),%zmm0
   46234:	lea    0x0(%r13,%rbx,8),%rbx
   46239:	vmovdqu64 %zmm1,0x38(%rax)
   46243:	vmovdqu64 %zmm0,(%rax)
   46249:	lock decq 0x0(%rbp)
   4624e:	mov    %rax,%rbp
   46251:	jne    4625f <hotaru_core::screen::State::print_ascii+0x2bf>
   46253:	mov    %rbx,%rdi
   46256:	vzeroupper
   46259:	call   *0x5cfe1(%rip)        # a3240 <_DYNAMIC+0x5e0>
   4625f:	mov    %rbp,(%rbx)
   46262:	movzbl (%r12),%edi
   46267:	cmpb   $0x0,0x20(%rsp)
   4626c:	lea    0x8(%rbp),%rax
   46270:	mov    %rbp,0x70(%rsp)
   46275:	mov    %rax,0x18(%rsp)
   4627a:	mov    %edi,(%rsp)
   4627d:	je     4644e <hotaru_core::screen::State::print_ascii+0x4ae>
   46283:	cmp    $0xa0,%dil
   46287:	jl     46479 <hotaru_core::screen::State::print_ascii+0x4d9>
   4628d:	mov    0xf0(%r14),%rcx
   46294:	lea    0x1(%r15),%rax
   46298:	mov    %rcx,0x30(%rsp)
   4629d:	cmp    %rcx,%rax
   462a0:	ja     46479 <hotaru_core::screen::State::print_ascii+0x4d9>
   462a6:	movzbl 0x7(%rsp),%edx
   462ab:	mov    0x18(%rsp),%rdi
   462b0:	mov    (%rsp),%ecx
   462b3:	mov    %r15,%rsi
   462b6:	vzeroupper
   462b9:	call   44200 <hotaru_core::screen::unicode_batch_boundary>
   462be:	mov    $0x1,%ebx
   462c3:	test   %al,%al
   462c5:	je     46479 <hotaru_core::screen::State::print_ascii+0x4d9>
   462cb:	jmp    465a2 <hotaru_core::screen::State::print_ascii+0x602>
   462d0:	cmpb   $0x0,0x6df(%r13)
   462d8:	mov    %r13,%r14
   462db:	mov    0x6ee(%r13),%edx
   462e2:	movzbl 0xa04(%r13),%ecx
   462ea:	cmovne 0x48(%rsp),%r14
   462f0:	mov    0x118(%r14),%rax
   462f7:	test   %rax,%rax
   462fa:	je     46306 <hotaru_core::screen::State::print_ascii+0x366>
   462fc:	lock incq (%rax)
   46300:	jle    46905 <hotaru_core::screen::State::print_ascii+0x965>
   46306:	mov    %edx,0x20(%rsp)
   4630a:	mov    0xf0(%r14),%rdx
   46311:	mov    0x90(%r14),%rbp
   46318:	mov    %rax,0x8(%rsp)
   4631d:	mov    %rax,0x80(%rsp)
   46325:	mov    %r15,%rax
   46328:	mov    %cl,(%rsp)
   4632b:	mov    %rdx,%r15
   4632e:	sub    %rbp,%r15
   46331:	mov    %rdx,0x18(%rsp)
   46336:	cmp    %rax,%r15
   46339:	cmovae %rax,%r15
   4633d:	mov    %r14,%rdi
   46340:	call   49e00 <hotaru_core::screen::Screen::row>
   46345:	mov    %rax,%rbx
   46348:	mov    0x10(%rbx),%rdx
   4634c:	lea    (%r15,%rbp,1),%rax
   46350:	cmp    $0x2,%rbp
   46354:	jae    463b0 <hotaru_core::screen::State::print_ascii+0x410>
   46356:	cmp    $0x2,%rax
   4635a:	mov    $0x2,%esi
   4635f:	cmovb  %rax,%rsi
   46363:	cmp    %rdx,%rsi
   46366:	ja     468dd <hotaru_core::screen::State::print_ascii+0x93d>
   4636c:	mov    0x8(%rbx),%rax
   46370:	lea    0x0(,%rbp,8),%rcx
   46378:	shl    $0x3,%rsi
   4637c:	sub    %rcx,%rsi
   4637f:	add    %rcx,%rax
   46382:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   46390:	test   %rsi,%rsi
   46393:	setne  %r13b
   46397:	je     463a7 <hotaru_core::screen::State::print_ascii+0x407>
   46399:	add    $0xfffffffffffffff8,%rsi
   4639d:	cmpb   $0x1,0x6(%rax)
   463a1:	lea    0x8(%rax),%rax
   463a5:	je     46390 <hotaru_core::screen::State::print_ascii+0x3f0>
   463a7:	test   %rbp,%rbp
   463aa:	jne    463b3 <hotaru_core::screen::State::print_ascii+0x413>
   463ac:	xor    %eax,%eax
   463ae:	jmp    463c8 <hotaru_core::screen::State::print_ascii+0x428>
   463b0:	xor    %r13d,%r13d
   463b3:	cmp    %rdx,%rbp
   463b6:	jae    46951 <hotaru_core::screen::State::print_ascii+0x9b1>
   463bc:	mov    0x8(%rbx),%rax
   463c0:	cmpb   $0x0,0x6(%rax,%rbp,8)
   463c5:	sete   %al
   463c8:	mov    0x20(%rsp),%r8d
   463cd:	movzbl %al,%ecx
   463d0:	lea    (%r15,%rbp,1),%rdx
   463d4:	mov    %rbx,%rdi
   463d7:	mov    %rbp,%rsi
   463da:	call   40b10 <hotaru_core::row::Row::prepare_write_with_left>
   463df:	mov    0x78(%rsp),%rsi
   463e4:	mov    %rbx,%rdi
   463e7:	call   41e70 <hotaru_core::row::Row::style_id>
   463ec:	mov    0x10(%rbx),%rdx
   463f0:	lea    (%r15,%rbp,1),%rsi
   463f4:	cmp    %rbp,%rsi
   463f7:	jb     468eb <hotaru_core::screen::State::print_ascii+0x94b>
   463fd:	mov    %rsi,0x20(%rsp)
   46402:	cmp    %rdx,%rsi
   46405:	ja     468e6 <hotaru_core::screen::State::print_ascii+0x946>
   4640b:	cmp    %rbp,0x18(%rsp)
   46410:	je     46814 <hotaru_core::screen::State::print_ascii+0x874>
   46416:	movzbl (%rsp),%edx
   4641a:	mov    0x8(%rbx),%rsi
   4641e:	movzwl %ax,%eax
   46421:	movabs $0x1000000000000,%rdi
   4642b:	shl    $0x20,%rax
   4642f:	shl    $0x38,%rdx
   46433:	lea    (%rsi,%rbp,8),%rcx
   46437:	or     %rdx,%rax
   4643a:	or     %rdi,%rax
   4643d:	cmp    $0x8,%r15
   46441:	jae    464d2 <hotaru_core::screen::State::print_ascii+0x532>
   46447:	xor    %edx,%edx
   46449:	jmp    46800 <hotaru_core::screen::State::print_ascii+0x860>
   4644e:	vzeroupper
   46451:	call   43ab0 <hotaru_core::screen::char_width>
   46456:	mov    %rax,%rbx
   46459:	test   %rax,%rax
   4645c:	je     46479 <hotaru_core::screen::State::print_ascii+0x4d9>
   4645e:	mov    0xf0(%r14),%rcx
   46465:	mov    %rbx,%rax
   46468:	add    %r15,%rax
   4646b:	mov    %rcx,0x30(%rsp)
   46470:	cmp    %rcx,%rax
   46473:	jbe    465a2 <hotaru_core::screen::State::print_ascii+0x602>
   46479:	mov    %r15,0x90(%r14)
   46480:	mov    $0x110000,%ebx
   46485:	xor    %r15d,%r15d
   46488:	mov    %r14,%rdi
   4648b:	vzeroupper
   4648e:	call   491b0 <hotaru_core::screen::Screen::enforce_budget>
   46493:	mov    0x40(%rsp),%r13
   46498:	cmp    $0x110000,%ebx
   4649e:	je     464a7 <hotaru_core::screen::State::print_ascii+0x507>
   464a0:	mov    %ebx,0x6d0(%r13)
   464a7:	mov    0x8(%rsp),%rax
   464ac:	test   %rax,%rax
   464af:	je     464c2 <hotaru_core::screen::State::print_ascii+0x522>
   464b1:	lock decq (%rax)
   464b5:	jne    464c2 <hotaru_core::screen::State::print_ascii+0x522>
   464b7:	lea    0x38(%rsp),%rdi
   464bc:	call   *0x5cd2e(%rip)        # a31f0 <_DYNAMIC+0x590>
   464c2:	cmp    0x28(%rsp),%r15
   464c7:	jbe    46063 <hotaru_core::screen::State::print_ascii+0xc3>
   464cd:	jmp    468c5 <hotaru_core::screen::State::print_ascii+0x925>
   464d2:	vpbroadcastq %rax,%zmm0
   464d8:	cmp    $0x20,%r15
   464dc:	jae    464e5 <hotaru_core::screen::State::print_ascii+0x545>
   464de:	xor    %edx,%edx
   464e0:	jmp    46572 <hotaru_core::screen::State::print_ascii+0x5d2>
   464e5:	lea    0xc0(%rsi,%rbp,8),%rsi
   464ed:	mov    %r15,%rdx
   464f0:	and    $0xffffffffffffffe0,%rdx
   464f4:	xor    %edi,%edi
   464f6:	cs nopw 0x0(%rax,%rax,1)
   46500:	vpmovzxbq (%r12,%rdi,1),%zmm1
   46507:	vpmovzxbq 0x8(%r12,%rdi,1),%zmm2
   4650f:	vpmovzxbq 0x10(%r12,%rdi,1),%zmm3
   46517:	vpmovzxbq 0x18(%r12,%rdi,1),%zmm4
   4651f:	vporq  %zmm1,%zmm0,%zmm1
   46525:	vporq  %zmm2,%zmm0,%zmm2
   4652b:	vporq  %zmm3,%zmm0,%zmm3
   46531:	vporq  %zmm4,%zmm0,%zmm4
   46537:	vmovdqu64 %zmm1,-0xc0(%rsi,%rdi,8)
   4653f:	vmovdqu64 %zmm2,-0x80(%rsi,%rdi,8)
   46547:	vmovdqu64 %zmm3,-0x40(%rsi,%rdi,8)
   4654f:	vmovdqu64 %zmm4,(%rsi,%rdi,8)
   46556:	add    $0x20,%rdi
   4655a:	cmp    %rdi,%rdx
   4655d:	jne    46500 <hotaru_core::screen::State::print_ascii+0x560>
   4655f:	cmp    %rdx,%r15
   46562:	je     46814 <hotaru_core::screen::State::print_ascii+0x874>
   46568:	test   $0x18,%r15b
   4656c:	je     46800 <hotaru_core::screen::State::print_ascii+0x860>
   46572:	mov    %rdx,%rsi
   46575:	mov    %r15,%rdx
   46578:	and    $0xfffffffffffffff8,%rdx
   4657c:	nopl   0x0(%rax)
   46580:	vpmovzxbq (%r12,%rsi,1),%zmm1
   46587:	vporq  %zmm1,%zmm0,%zmm1
   4658d:	vmovdqu64 %zmm1,(%rcx,%rsi,8)
   46594:	add    $0x8,%rsi
   46598:	cmp    %rsi,%rdx
   4659b:	jne    46580 <hotaru_core::screen::State::print_ascii+0x5e0>
   4659d:	jmp    4680f <hotaru_core::screen::State::print_ascii+0x86f>
   465a2:	cmp    $0x1,%r15
   465a6:	ja     465d6 <hotaru_core::screen::State::print_ascii+0x636>
   465a8:	mov    0x70(%rsp),%rax
   465ad:	mov    0x18(%rax),%rsi
   465b1:	cmp    %rsi,%r15
   465b4:	jae    46983 <hotaru_core::screen::State::print_ascii+0x9e3>
   465ba:	mov    0x10(%rax),%rax
   465be:	movzbl 0x6(%rax,%r15,8),%eax
   465c4:	cmp    $0x1,%rax
   465c8:	setne  %cl
   465cb:	cmp    %eax,%ebx
   465cd:	setne  %r13b
   465d1:	and    %cl,%r13b
   465d4:	jmp    465d9 <hotaru_core::screen::State::print_ascii+0x639>
   465d6:	xor    %r13d,%r13d
   465d9:	mov    0x58(%rsp),%rax
   465de:	mov    0x5e(%rsp),%rcx
   465e3:	mov    %rcx,0x86(%rsp)
   465eb:	mov    %rax,0x80(%rsp)
   465f3:	movzbl 0x14(%rsp),%r9d
   465f9:	mov    0x18(%rsp),%rdi
   465fe:	mov    (%rsp),%edx
   46601:	lea    0x80(%rsp),%r8
   46609:	mov    %r15,%rsi
   4660c:	mov    %rbx,%rcx
   4660f:	mov    %r9d,0x54(%rsp)
   46614:	call   40f90 <hotaru_core::row::Row::put>
   46619:	add    %r15,%rbx
   4661c:	cmpq   $0x0,0x8(%rsp)
   46622:	je     46639 <hotaru_core::screen::State::print_ascii+0x699>
   46624:	mov    0x18(%rsp),%rdi
   46629:	lea    0x38(%rsp),%rcx
   4662e:	mov    %r15,%rsi
   46631:	mov    %rbx,%rdx
   46634:	call   407f0 <hotaru_core::row::Row::set_hyperlink_range>
   46639:	mov    $0x1,%r15d
   4663f:	cmp    0x30(%rsp),%rbx
   46644:	jne    4665b <hotaru_core::screen::State::print_ascii+0x6bb>
   46646:	mov    0x30(%rsp),%rbx
   4664b:	movb   $0x1,0x12f(%r14)
   46653:	dec    %rbx
   46656:	jmp    467c4 <hotaru_core::screen::State::print_ascii+0x824>
   4665b:	cmpq   $0x1,0x28(%rsp)
   46661:	je     467c4 <hotaru_core::screen::State::print_ascii+0x824>
   46667:	nopw   0x0(%rax,%rax,1)
   46670:	movzbl (%r12,%r15,1),%r8d
   46675:	cmpb   $0x0,0x20(%rsp)
   4667a:	mov    %r8d,0x14(%rsp)
   4667f:	je     466d0 <hotaru_core::screen::State::print_ascii+0x730>
   46681:	xor    %eax,%eax
   46683:	cmp    $0xa0,%r8b
   46687:	setge  %cl
   4668a:	jl     467c4 <hotaru_core::screen::State::print_ascii+0x824>
   46690:	mov    %cl,%al
   46692:	add    %rbx,%rax
   46695:	cmp    0x30(%rsp),%rax
   4669a:	ja     467c4 <hotaru_core::screen::State::print_ascii+0x824>
   466a0:	movzbl 0x7(%rsp),%edx
   466a5:	mov    0x18(%rsp),%rdi
   466aa:	mov    %rbx,%rsi
   466ad:	mov    %r8d,%ecx
   466b0:	call   44200 <hotaru_core::screen::unicode_batch_boundary>
   466b5:	mov    $0x1,%ebp
   466ba:	test   %al,%al
   466bc:	jne    466f5 <hotaru_core::screen::State::print_ascii+0x755>
   466be:	jmp    467c4 <hotaru_core::screen::State::print_ascii+0x824>
   466c3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   466d0:	mov    %r8d,%edi
   466d3:	call   43ab0 <hotaru_core::screen::char_width>
   466d8:	mov    %rax,%rbp
   466db:	test   %rax,%rax
   466de:	je     467c4 <hotaru_core::screen::State::print_ascii+0x824>
   466e4:	mov    %rbp,%rax
   466e7:	add    %rbx,%rax
   466ea:	cmp    0x30(%rsp),%rax
   466ef:	ja     467c4 <hotaru_core::screen::State::print_ascii+0x824>
   466f5:	cmp    $0x1,%rbx
   466f9:	ja     46730 <hotaru_core::screen::State::print_ascii+0x790>
   466fb:	mov    0x70(%rsp),%rax
   46700:	mov    0x18(%rax),%rsi
   46704:	cmp    %rsi,%rbx
   46707:	jae    46980 <hotaru_core::screen::State::print_ascii+0x9e0>
   4670d:	mov    0x10(%rax),%rax
   46711:	movzbl 0x6(%rax,%rbx,8),%eax
   46716:	cmp    $0x1,%rax
   4671a:	setne  %cl
   4671d:	cmp    %eax,%ebp
   4671f:	setne  %al
   46722:	and    %cl,%al
   46724:	mov    %eax,(%rsp)
   46727:	jmp    46737 <hotaru_core::screen::State::print_ascii+0x797>
   46729:	nopl   0x0(%rax)
   46730:	movl   $0x0,(%rsp)
   46737:	mov    0x58(%rsp),%rax
   4673c:	mov    0x5e(%rsp),%rcx
   46741:	mov    %rcx,0x86(%rsp)
   46749:	mov    %rax,0x80(%rsp)
   46751:	mov    0x18(%rsp),%rdi
   46756:	mov    0x14(%rsp),%edx
   4675a:	mov    0x54(%rsp),%r9d
   4675f:	lea    0x80(%rsp),%r8
   46767:	mov    %rbx,%rsi
   4676a:	mov    %rbp,%rcx
   4676d:	call   40f90 <hotaru_core::row::Row::put>
   46772:	add    %rbx,%rbp
   46775:	cmpq   $0x0,0x8(%rsp)
   4677b:	je     46792 <hotaru_core::screen::State::print_ascii+0x7f2>
   4677d:	mov    0x18(%rsp),%rdi
   46782:	lea    0x38(%rsp),%rcx
   46787:	mov    %rbx,%rsi
   4678a:	mov    %rbp,%rdx
   4678d:	call   407f0 <hotaru_core::row::Row::set_hyperlink_range>
   46792:	or     (%rsp),%r13b
   46796:	and    $0x1,%r13b
   4679a:	cmp    0x30(%rsp),%rbp
   4679f:	je     467e9 <hotaru_core::screen::State::print_ascii+0x849>
   467a1:	mov    0x14(%rsp),%eax
   467a5:	inc    %r15
   467a8:	mov    %rbp,%rbx
   467ab:	mov    %eax,(%rsp)
   467ae:	cmp    %r15,0x28(%rsp)
   467b3:	jne    46670 <hotaru_core::screen::State::print_ascii+0x6d0>
   467b9:	mov    0x28(%rsp),%r15
   467be:	mov    %rbp,%rbx
   467c1:	mov    %eax,(%rsp)
   467c4:	mov    %rbx,0x90(%r14)
   467cb:	test   $0x1,%r13b
   467cf:	je     467e1 <hotaru_core::screen::State::print_ascii+0x841>
   467d1:	mov    %r14,%rdi
   467d4:	call   492d0 <hotaru_core::screen::Screen::clear_previous_spacer>
   467d9:	mov    (%rsp),%ebx
   467dc:	jmp    46488 <hotaru_core::screen::State::print_ascii+0x4e8>
   467e1:	mov    (%rsp),%ebx
   467e4:	jmp    46488 <hotaru_core::screen::State::print_ascii+0x4e8>
   467e9:	mov    0x14(%rsp),%eax
   467ed:	inc    %r15
   467f0:	mov    %eax,(%rsp)
   467f3:	jmp    46646 <hotaru_core::screen::State::print_ascii+0x6a6>
   467f8:	nopl   0x0(%rax,%rax,1)
   46800:	movzbl (%r12,%rdx,1),%esi
   46805:	or     %rax,%rsi
   46808:	mov    %rsi,(%rcx,%rdx,8)
   4680c:	inc    %rdx
   4680f:	cmp    %rdx,%r15
   46812:	jne    46800 <hotaru_core::screen::State::print_ascii+0x860>
   46814:	cmpq   $0x0,0x8(%rsp)
   4681a:	je     46837 <hotaru_core::screen::State::print_ascii+0x897>
   4681c:	mov    0x20(%rsp),%rdx
   46821:	lea    0x80(%rsp),%rcx
   46829:	mov    %rbx,%rdi
   4682c:	mov    %rbp,%rsi
   4682f:	vzeroupper
   46832:	call   407f0 <hotaru_core::row::Row::set_hyperlink_range>
   46837:	test   %r13b,%r13b
   4683a:	je     46847 <hotaru_core::screen::State::print_ascii+0x8a7>
   4683c:	mov    %r14,%rdi
   4683f:	vzeroupper
   46842:	call   492d0 <hotaru_core::screen::Screen::clear_previous_spacer>
   46847:	mov    0x20(%rsp),%rcx
   4684c:	mov    0x18(%rsp),%rax
   46851:	mov    %rcx,0x90(%r14)
   46858:	cmp    %rax,%rcx
   4685b:	jne    4686f <hotaru_core::screen::State::print_ascii+0x8cf>
   4685d:	dec    %rax
   46860:	mov    %rax,0x90(%r14)
   46867:	movb   $0x1,0x12f(%r14)
   4686f:	mov    %r14,%rdi
   46872:	vzeroupper
   46875:	call   491b0 <hotaru_core::screen::Screen::enforce_budget>
   4687a:	lea    -0x1(%r15),%rdi
   4687e:	cmp    0x28(%rsp),%rdi
   46883:	jae    46938 <hotaru_core::screen::State::print_ascii+0x998>
   46889:	movzbl (%r12,%rdi,1),%eax
   4688e:	mov    0x40(%rsp),%r13
   46893:	mov    %eax,0x6d0(%r13)
   4689a:	mov    0x8(%rsp),%rax
   4689f:	test   %rax,%rax
   468a2:	je     46063 <hotaru_core::screen::State::print_ascii+0xc3>
   468a8:	lock decq (%rax)
   468ac:	jne    46063 <hotaru_core::screen::State::print_ascii+0xc3>
   468b2:	lea    0x80(%rsp),%rdi
   468ba:	call   *0x5c930(%rip)        # a31f0 <_DYNAMIC+0x590>
   468c0:	jmp    46063 <hotaru_core::screen::State::print_ascii+0xc3>
   468c5:	mov    0x28(%rsp),%rdx
   468ca:	lea    0x59ca7(%rip),%rcx        # a0578 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x688>
   468d1:	mov    %r15,%rdi
   468d4:	mov    %rdx,%rsi
   468d7:	call   *0x5c713(%rip)        # a2ff0 <_DYNAMIC+0x390>
   468dd:	lea    0x59c7c(%rip),%rcx        # a0560 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x670>
   468e4:	jmp    468f2 <hotaru_core::screen::State::print_ascii+0x952>
   468e6:	mov    0x20(%rsp),%rsi
   468eb:	lea    0x59c56(%rip),%rcx        # a0548 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x658>
   468f2:	mov    0x8(%rsp),%rbx
   468f7:	mov    %rbp,%rdi
   468fa:	call   *0x5c6f0(%rip)        # a2ff0 <_DYNAMIC+0x390>
   46900:	jmp    46993 <hotaru_core::screen::State::print_ascii+0x9f3>
   46905:	call   *0x5c8d5(%rip)        # a31e0 <_DYNAMIC+0x580>
   4690b:	lea    -0x396bd(%rip),%rdi        # d255 <hotaru_core::unicode::BREAKS+0x214d>
   46912:	lea    0x59d4f(%rip),%rdx        # a0668 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x778>
   46919:	mov    $0x14,%esi
   4691e:	call   *0x5c704(%rip)        # a3028 <_DYNAMIC+0x3c8>
   46924:	jmp    46993 <hotaru_core::screen::State::print_ascii+0x9f3>
   46926:	mov    $0x8,%edi
   4692b:	mov    $0x78,%esi
   46930:	call   *0x5c5b2(%rip)        # a2ee8 <_DYNAMIC+0x288>
   46936:	jmp    46993 <hotaru_core::screen::State::print_ascii+0x9f3>
   46938:	mov    0x28(%rsp),%rsi
   4693d:	mov    0x8(%rsp),%rbx
   46942:	lea    0x59be7(%rip),%rdx        # a0530 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x640>
   46949:	call   *0x5c551(%rip)        # a2ea0 <_DYNAMIC+0x240>
   4694f:	jmp    46993 <hotaru_core::screen::State::print_ascii+0x9f3>
   46951:	mov    0x8(%rsp),%rbx
   46956:	lea    0x5973b(%rip),%rax        # a0098 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x1a8>
   4695d:	mov    %rdx,%rsi
   46960:	mov    %rbp,%rdi
   46963:	mov    %rax,%rdx
   46966:	call   *0x5c534(%rip)        # a2ea0 <_DYNAMIC+0x240>
   4696c:	jmp    46993 <hotaru_core::screen::State::print_ascii+0x9f3>
   4696e:	lea    0x59ba3(%rip),%rdx        # a0518 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x628>
   46975:	mov    $0x4,%esi
   4697a:	call   *0x5c520(%rip)        # a2ea0 <_DYNAMIC+0x240>
   46980:	mov    %rbx,%r15
   46983:	lea    0x59cf6(%rip),%rdx        # a0680 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x790>
   4698a:	mov    %r15,%rdi
   4698d:	call   *0x5c50d(%rip)        # a2ea0 <_DYNAMIC+0x240>
   46993:	ud2
   46995:	mov    0x8(%rsp),%rcx
   4699a:	jmp    469d6 <hotaru_core::screen::State::print_ascii+0xa36>
   4699c:	mov    0x8(%rsp),%rcx
   469a1:	jmp    469d6 <hotaru_core::screen::State::print_ascii+0xa36>
   469a3:	jmp    469cc <hotaru_core::screen::State::print_ascii+0xa2c>
   469a5:	jmp    469cc <hotaru_core::screen::State::print_ascii+0xa2c>
   469a7:	mov    0x8(%rsp),%rbx
   469ac:	jmp    469e3 <hotaru_core::screen::State::print_ascii+0xa43>
   469ae:	jmp    469cc <hotaru_core::screen::State::print_ascii+0xa2c>
   469b0:	mov    0x8(%rsp),%rbx
   469b5:	jmp    469de <hotaru_core::screen::State::print_ascii+0xa3e>
   469b7:	lea    0x88(%rsp),%rdi
   469bf:	mov    %rax,%rbx
   469c2:	call   4f4c0 <core::ptr::drop_in_place<hotaru_core::row::Row>>
   469c7:	mov    %rbx,%rax
   469ca:	jmp    469cc <hotaru_core::screen::State::print_ascii+0xa2c>
   469cc:	mov    0x8(%rsp),%rcx
   469d1:	test   %rcx,%rcx
   469d4:	je     46a0c <hotaru_core::screen::State::print_ascii+0xa6c>
   469d6:	lock decq (%rcx)
   469da:	je     469f6 <hotaru_core::screen::State::print_ascii+0xa56>
   469dc:	jmp    46a0c <hotaru_core::screen::State::print_ascii+0xa6c>
   469de:	test   %rbx,%rbx
   469e1:	je     46a0c <hotaru_core::screen::State::print_ascii+0xa6c>
   469e3:	lock decq (%rbx)
   469e7:	lea    0x80(%rsp),%rcx
   469ef:	mov    %rcx,0x68(%rsp)
   469f4:	jne    46a0c <hotaru_core::screen::State::print_ascii+0xa6c>
   469f6:	mov    0x68(%rsp),%rdi
   469fb:	mov    %rax,%rbx
   469fe:	call   *0x5c7ec(%rip)        # a31f0 <_DYNAMIC+0x590>
   46a04:	mov    %rbx,%rdi
   46a07:	call   9ea60 <_Unwind_Resume@plt>
   46a0c:	mov    %rax,%rdi
   46a0f:	call   9ea60 <_Unwind_Resume@plt>
