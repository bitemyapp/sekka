
/home/callen/work/hotaru-error-ascii-prefix-20261028/target/release/hotaru-replay:     file format elf64-x86-64


Disassembly of section .text:

000000000004bd00 <hotaru_core::Terminal::feed_inner>:
   4bd00:	push   %rbp
   4bd01:	push   %r15
   4bd03:	push   %r14
   4bd05:	push   %r13
   4bd07:	push   %r12
   4bd09:	push   %rbx
   4bd0a:	sub    $0x58,%rsp
   4bd0e:	mov    %rcx,0x38(%rsp)
   4bd13:	mov    %rdx,%r15
   4bd16:	mov    %rdi,%r14
   4bd19:	test   %rdx,%rdx
   4bd1c:	je     4cb89 <hotaru_core::Terminal::feed_inner+0xe89>
   4bd22:	vpbroadcastb -0x4172b(%rip),%xmm1        # a600 <anon.58baeeae7d5fe476157d296c9f08f803.334.llvm.5844774155465566772+0x633>
   4bd2b:	vpbroadcastb -0x41733(%rip),%xmm2        # a601 <anon.58baeeae7d5fe476157d296c9f08f803.334.llvm.5844774155465566772+0x634>
   4bd34:	mov    %rsi,%r13
   4bd37:	mov    %r15,0x30(%rsp)
   4bd3c:	mov    %r15,%rbx
   4bd3f:	xor    %ebp,%ebp
   4bd41:	jmp    4bd96 <hotaru_core::Terminal::feed_inner+0x96>
   4bd43:	movb   $0x0,0xad7(%r14)
   4bd4b:	movq   $0x0,0xa28(%r14)
   4bd56:	mov    %r14,%rdi
   4bd59:	vzeroupper
   4bd5c:	call   491b0 <hotaru_core::screen::Screen::enforce_budget>
   4bd61:	lea    0x130(%r14),%rdi
   4bd68:	call   491b0 <hotaru_core::screen::Screen::enforce_budget>
   4bd6d:	vpbroadcastb -0x41776(%rip),%xmm1        # a600 <anon.58baeeae7d5fe476157d296c9f08f803.334.llvm.5844774155465566772+0x633>
   4bd76:	vpbroadcastb -0x4177e(%rip),%xmm2        # a601 <anon.58baeeae7d5fe476157d296c9f08f803.334.llvm.5844774155465566772+0x634>
   4bd7f:	dec    %rbx
   4bd82:	inc    %r13
   4bd85:	cmp    $0x1,%rbp
   4bd89:	adc    $0xffffffffffffffff,%rbp
   4bd8d:	test   %rbx,%rbx
   4bd90:	je     4cb8d <hotaru_core::Terminal::feed_inner+0xe8d>
   4bd96:	mov    0x38(%rsp),%rax
   4bd9b:	cmp    %rax,0x298(%r14)
   4bda2:	jae    4cb8f <hotaru_core::Terminal::feed_inner+0xe8f>
   4bda8:	movzbl 0xad9(%r14),%ecx
   4bdb0:	movzbl 0xad7(%r14),%eax
   4bdb8:	mov    %ecx,%edx
   4bdba:	or     %al,%dl
   4bdbc:	jne    4c060 <hotaru_core::Terminal::feed_inner+0x360>
   4bdc2:	cmp    $0x10,%rbx
   4bdc6:	jb     4be80 <hotaru_core::Terminal::feed_inner+0x180>
   4bdcc:	movabs $0x7ffffffffffffff0,%rax
   4bdd6:	mov    %rbx,%r15
   4bdd9:	mov    %r13,%rcx
   4bddc:	and    %rax,%r15
   4bddf:	xor    %eax,%eax
   4bde1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   4bdf0:	vpaddb (%rcx),%xmm1,%xmm0
   4bdf4:	vpcmpltub %xmm2,%xmm0,%k0
   4bdfb:	kortestw %k0,%k0
   4bdff:	jne    4bed9 <hotaru_core::Terminal::feed_inner+0x1d9>
   4be05:	lea    -0x10(%rbx,%rax,1),%rdx
   4be0a:	add    $0xfffffffffffffff0,%rax
   4be0e:	add    $0x10,%rcx
   4be12:	cmp    $0xf,%rdx
   4be16:	ja     4bdf0 <hotaru_core::Terminal::feed_inner+0xf0>
   4be18:	add    %rbx,%rax
   4be1b:	jne    4be86 <hotaru_core::Terminal::feed_inner+0x186>
   4be1d:	xor    %ecx,%ecx
   4be1f:	add    %rcx,%r15
   4be22:	test   %r15,%r15
   4be25:	je     4bec6 <hotaru_core::Terminal::feed_inner+0x1c6>
   4be2b:	cmp    %rbx,%r15
   4be2e:	ja     4cbc7 <hotaru_core::Terminal::feed_inner+0xec7>
   4be34:	mov    %r14,%rdi
   4be37:	mov    %r13,%rsi
   4be3a:	mov    %r15,%rdx
   4be3d:	call   45fa0 <hotaru_core::screen::State::print_ascii>
   4be42:	vpbroadcastb -0x4184a(%rip),%xmm2        # a601 <anon.58baeeae7d5fe476157d296c9f08f803.334.llvm.5844774155465566772+0x634>
   4be4b:	vpbroadcastb -0x41854(%rip),%xmm1        # a600 <anon.58baeeae7d5fe476157d296c9f08f803.334.llvm.5844774155465566772+0x633>
   4be54:	sub    %r15,%rbp
   4be57:	mov    $0x0,%eax
   4be5c:	cmovb  %rax,%rbp
   4be60:	add    %r15,%r13
   4be63:	sub    %r15,%rbx
   4be66:	test   %rbx,%rbx
   4be69:	jne    4bd96 <hotaru_core::Terminal::feed_inner+0x96>
   4be6f:	jmp    4cb8d <hotaru_core::Terminal::feed_inner+0xe8d>
   4be74:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   4be80:	mov    %rbx,%rax
   4be83:	xor    %r15d,%r15d
   4be86:	mov    %rbx,%rsi
   4be89:	lea    0x0(%r13,%r15,1),%rdx
   4be8e:	sub    %r15,%rsi
   4be91:	xor    %ecx,%ecx
   4be93:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   4bea0:	movzbl (%rdx,%rcx,1),%edi
   4bea4:	add    $0x81,%dil
   4bea8:	cmp    $0xa1,%dil
   4beac:	jb     4be1f <hotaru_core::Terminal::feed_inner+0x11f>
   4beb2:	inc    %rcx
   4beb5:	cmp    %rcx,%rsi
   4beb8:	jne    4bea0 <hotaru_core::Terminal::feed_inner+0x1a0>
   4beba:	add    %rax,%r15
   4bebd:	test   %r15,%r15
   4bec0:	jne    4be2b <hotaru_core::Terminal::feed_inner+0x12b>
   4bec6:	movzbl 0x0(%r13),%r12d
   4becb:	test   %r12b,%r12b
   4bece:	js     4bef0 <hotaru_core::Terminal::feed_inner+0x1f0>
   4bed0:	xor    %ecx,%ecx
   4bed2:	xor    %eax,%eax
   4bed4:	jmp    4c0f0 <hotaru_core::Terminal::feed_inner+0x3f0>
   4bed9:	kmovd  %k0,%ecx
   4bedd:	tzcnt  %ecx,%r15d
   4bee2:	sub    %rax,%r15
   4bee5:	test   %r15,%r15
   4bee8:	jne    4be2b <hotaru_core::Terminal::feed_inner+0x12b>
   4beee:	jmp    4bec6 <hotaru_core::Terminal::feed_inner+0x1c6>
   4bef0:	test   %rbp,%rbp
   4bef3:	jne    4bf9c <hotaru_core::Terminal::feed_inner+0x29c>
   4bef9:	cmp    $0x10,%rbx
   4befd:	jb     4bf5e <hotaru_core::Terminal::feed_inner+0x25e>
   4beff:	movabs $0x7ffffffffffffff0,%rax
   4bf09:	mov    %rbx,%rbp
   4bf0c:	mov    %r13,%rcx
   4bf0f:	and    %rax,%rbp
   4bf12:	xor    %eax,%eax
   4bf14:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   4bf20:	vmovdqu (%rcx),%xmm0
   4bf24:	vpcmpltub -0x4312f(%rip),%xmm0,%k0        # 8e00 <anon.58baeeae7d5fe476157d296c9f08f803.1.llvm.5844774155465566772+0x30>
   4bf2f:	vpcmpeqb -0x43459(%rip),%xmm0,%k1        # 8ae0 <anon.eb89d4395b0ead844ef0b45b8b54da85.151.llvm.3643936799275306673+0x172>
   4bf39:	kortestw %k1,%k0
   4bf3d:	jne    4bf8d <hotaru_core::Terminal::feed_inner+0x28d>
   4bf3f:	lea    -0x10(%rbx,%rax,1),%rdx
   4bf44:	add    $0xfffffffffffffff0,%rax
   4bf48:	add    $0x10,%rcx
   4bf4c:	cmp    $0xf,%rdx
   4bf50:	ja     4bf20 <hotaru_core::Terminal::feed_inner+0x220>
   4bf52:	add    %rbx,%rax
   4bf55:	jne    4bf63 <hotaru_core::Terminal::feed_inner+0x263>
   4bf57:	xor    %ecx,%ecx
   4bf59:	add    %rcx,%rbp
   4bf5c:	jmp    4bf9c <hotaru_core::Terminal::feed_inner+0x29c>
   4bf5e:	mov    %rbx,%rax
   4bf61:	xor    %ebp,%ebp
   4bf63:	mov    %rbx,%rsi
   4bf66:	lea    0x0(%r13,%rbp,1),%rdx
   4bf6b:	sub    %rbp,%rsi
   4bf6e:	xor    %ecx,%ecx
   4bf70:	movzbl (%rdx,%rcx,1),%edi
   4bf74:	cmp    $0x20,%dil
   4bf78:	jb     4bf59 <hotaru_core::Terminal::feed_inner+0x259>
   4bf7a:	cmp    $0x7f,%dil
   4bf7e:	je     4bf59 <hotaru_core::Terminal::feed_inner+0x259>
   4bf80:	inc    %rcx
   4bf83:	cmp    %rcx,%rsi
   4bf86:	jne    4bf70 <hotaru_core::Terminal::feed_inner+0x270>
   4bf88:	add    %rax,%rbp
   4bf8b:	jmp    4bf9c <hotaru_core::Terminal::feed_inner+0x29c>
   4bf8d:	korw   %k1,%k0,%k0
   4bf91:	kmovd  %k0,%ecx
   4bf95:	tzcnt  %ecx,%ebp
   4bf99:	sub    %rax,%rbp
   4bf9c:	cmp    %rbx,%rbp
   4bf9f:	ja     4cbdc <hotaru_core::Terminal::feed_inner+0xedc>
   4bfa5:	lea    0x40(%rsp),%rdi
   4bfaa:	mov    %r13,%rsi
   4bfad:	mov    %rbp,%rdx
   4bfb0:	call   3f580 <hotaru_core::validate_utf8_run>
   4bfb5:	cmpb   $0x0,0x40(%rsp)
   4bfba:	je     4c000 <hotaru_core::Terminal::feed_inner+0x300>
   4bfbc:	mov    0x48(%rsp),%rdx
   4bfc1:	cmp    %rbx,%rdx
   4bfc4:	ja     4cc08 <hotaru_core::Terminal::feed_inner+0xf08>
   4bfca:	mov    %rsp,%rdi
   4bfcd:	mov    %r13,%rsi
   4bfd0:	call   *0x5709a(%rip)        # a3070 <_DYNAMIC+0x410>
   4bfd6:	cmpb   $0x0,(%rsp)
   4bfda:	jne    4c047 <hotaru_core::Terminal::feed_inner+0x347>
   4bfdc:	mov    0x10(%rsp),%r15
   4bfe1:	test   %r15,%r15
   4bfe4:	je     4c047 <hotaru_core::Terminal::feed_inner+0x347>
   4bfe6:	mov    0x8(%rsp),%rsi
   4bfeb:	mov    %r14,%rdi
   4bfee:	mov    %r15,%rdx
   4bff1:	call   3f620 <hotaru_core::print_prefix_before_error>
   4bff6:	cmp    %rbx,%r15
   4bff9:	jbe    4c01e <hotaru_core::Terminal::feed_inner+0x31e>
   4bffb:	jmp    4cc5e <hotaru_core::Terminal::feed_inner+0xf5e>
   4c000:	mov    0x50(%rsp),%r15
   4c005:	mov    0x48(%rsp),%rsi
   4c00a:	mov    %r14,%rdi
   4c00d:	mov    %r15,%rdx
   4c010:	call   44490 <hotaru_core::screen::State::print_utf8>
   4c015:	cmp    %rbx,%r15
   4c018:	ja     4cc1d <hotaru_core::Terminal::feed_inner+0xf1d>
   4c01e:	vpbroadcastb -0x41a27(%rip),%xmm1        # a600 <anon.58baeeae7d5fe476157d296c9f08f803.334.llvm.5844774155465566772+0x633>
   4c027:	vpbroadcastb -0x41a2f(%rip),%xmm2        # a601 <anon.58baeeae7d5fe476157d296c9f08f803.334.llvm.5844774155465566772+0x634>
   4c030:	sub    %r15,%rbp
   4c033:	add    %r15,%r13
   4c036:	sub    %r15,%rbx
   4c039:	test   %rbx,%rbx
   4c03c:	jne    4bd96 <hotaru_core::Terminal::feed_inner+0x96>
   4c042:	jmp    4cb8d <hotaru_core::Terminal::feed_inner+0xe8d>
   4c047:	movzbl 0xad7(%r14),%eax
   4c04f:	movzbl 0xad9(%r14),%ecx
   4c057:	nopw   0x0(%rax,%rax,1)
   4c060:	movzbl 0x0(%r13),%r12d
   4c065:	xor    %esi,%esi
   4c067:	cmp    $0x90,%r12b
   4c06b:	setae  %dil
   4c06f:	cmp    $0xbf,%r12b
   4c073:	jg     4c0f0 <hotaru_core::Terminal::feed_inner+0x3f0>
   4c075:	test   %al,%al
   4c077:	setne  %dl
   4c07a:	test   %cl,%cl
   4c07c:	sete   %r8b
   4c080:	or     %dl,%r8b
   4c083:	jne    4c233 <hotaru_core::Terminal::feed_inner+0x533>
   4c089:	mov    0xacc(%r14),%edx
   4c090:	cmp    $0x2,%cl
   4c093:	sete   %al
   4c096:	cmp    $0x800,%edx
   4c09c:	sete   %r8b
   4c0a0:	test   %r8b,%al
   4c0a3:	je     4c1eb <hotaru_core::Terminal::feed_inner+0x4eb>
   4c0a9:	mov    0xac8(%r14),%eax
   4c0b0:	cmp    $0xa0,%r12b
   4c0b4:	setae  %cl
   4c0b7:	setb   %sil
   4c0bb:	test   %eax,%eax
   4c0bd:	sete   %dil
   4c0c1:	cmp    $0xd,%eax
   4c0c4:	sete   %dl
   4c0c7:	test   %dil,%sil
   4c0ca:	jne    4c215 <hotaru_core::Terminal::feed_inner+0x515>
   4c0d0:	and    %dl,%cl
   4c0d2:	jne    4c215 <hotaru_core::Terminal::feed_inner+0x515>
   4c0d8:	mov    $0x800,%edx
   4c0dd:	mov    $0x2,%cl
   4c0df:	jmp    4c2b9 <hotaru_core::Terminal::feed_inner+0x5b9>
   4c0e4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   4c0f0:	test   %al,%al
   4c0f2:	setne  %dl
   4c0f5:	test   %cl,%cl
   4c0f7:	sete   %cl
   4c0fa:	or     %dl,%cl
   4c0fc:	cmp    $0x18,%r12b
   4c100:	je     4c116 <hotaru_core::Terminal::feed_inner+0x416>
   4c102:	movzbl %r12b,%r15d
   4c106:	cmp    $0x5c,%r15d
   4c10a:	je     4c139 <hotaru_core::Terminal::feed_inner+0x439>
   4c10c:	cmp    $0x1a,%r15d
   4c110:	jne    4c1a0 <hotaru_core::Terminal::feed_inner+0x4a0>
   4c116:	test   %cl,%cl
   4c118:	jne    4bd43 <hotaru_core::Terminal::feed_inner+0x43>
   4c11e:	mov    $0xfffd,%esi
   4c123:	mov    %r14,%rdi
   4c126:	movb   $0x0,0xad9(%r14)
   4c12e:	call   *0x570fc(%rip)        # a3230 <_DYNAMIC+0x5d0>
   4c134:	jmp    4bd43 <hotaru_core::Terminal::feed_inner+0x43>
   4c139:	test   %cl,%cl
   4c13b:	jne    4c15b <hotaru_core::Terminal::feed_inner+0x45b>
   4c13d:	mov    $0xfffd,%esi
   4c142:	mov    %r14,%rdi
   4c145:	movb   $0x0,0xad9(%r14)
   4c14d:	call   *0x570dd(%rip)        # a3230 <_DYNAMIC+0x5d0>
   4c153:	movzbl 0xad7(%r14),%eax
   4c15b:	movzbl %al,%ecx
   4c15e:	lea    -0x414e5(%rip),%rdx        # ac80 <anon.58baeeae7d5fe476157d296c9f08f803.334.llvm.5844774155465566772+0xcb3>
   4c165:	mov    $0x5c,%r12b
   4c168:	movslq (%rdx,%rcx,4),%rcx
   4c16c:	add    %rdx,%rcx
   4c16f:	jmp    *%rcx
   4c171:	cmp    $0x3,%al
   4c173:	jne    4c597 <hotaru_core::Terminal::feed_inner+0x897>
   4c179:	mov    %r12b,0xad8(%r14)
   4c180:	movq   $0x0,0xa28(%r14)
   4c18b:	movb   $0x0,0xad5(%r14)
   4c193:	movb   $0x4,0xad7(%r14)
   4c19b:	jmp    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4c1a0:	test   %cl,%cl
   4c1a2:	jne    4c1c2 <hotaru_core::Terminal::feed_inner+0x4c2>
   4c1a4:	mov    $0xfffd,%esi
   4c1a9:	mov    %r14,%rdi
   4c1ac:	movb   $0x0,0xad9(%r14)
   4c1b4:	call   *0x57076(%rip)        # a3230 <_DYNAMIC+0x5d0>
   4c1ba:	movzbl 0xad7(%r14),%eax
   4c1c2:	movzbl %al,%ecx
   4c1c5:	lea    -0x41520(%rip),%rdx        # acac <anon.58baeeae7d5fe476157d296c9f08f803.334.llvm.5844774155465566772+0xcdf>
   4c1cc:	movslq (%rdx,%rcx,4),%rcx
   4c1d0:	add    %rdx,%rcx
   4c1d3:	jmp    *%rcx
   4c1d5:	cmp    $0x1b,%r12b
   4c1d9:	je     4c718 <hotaru_core::Terminal::feed_inner+0xa18>
   4c1df:	cmp    $0x1f,%r12b
   4c1e3:	jbe    4c903 <hotaru_core::Terminal::feed_inner+0xc03>
   4c1e9:	jmp    4c246 <hotaru_core::Terminal::feed_inner+0x546>
   4c1eb:	mov    0xac8(%r14),%eax
   4c1f2:	cmp    $0x3,%cl
   4c1f5:	jne    4c2b9 <hotaru_core::Terminal::feed_inner+0x5b9>
   4c1fb:	cmp    $0x10000,%edx
   4c201:	jne    4c2b9 <hotaru_core::Terminal::feed_inner+0x5b9>
   4c207:	mov    %dil,%sil
   4c20a:	shl    $0x2,%esi
   4c20d:	cmp    %esi,%eax
   4c20f:	jne    4c2b9 <hotaru_core::Terminal::feed_inner+0x5b9>
   4c215:	mov    $0xfffd,%esi
   4c21a:	mov    %r14,%rdi
   4c21d:	movb   $0x0,0xad9(%r14)
   4c225:	call   *0x57005(%rip)        # a3230 <_DYNAMIC+0x5d0>
   4c22b:	movzbl 0xad7(%r14),%eax
   4c233:	movzbl %al,%ecx
   4c236:	lea    -0x41565(%rip),%rdx        # acd8 <anon.58baeeae7d5fe476157d296c9f08f803.334.llvm.5844774155465566772+0xd0b>
   4c23d:	movslq (%rdx,%rcx,4),%rcx
   4c241:	add    %rdx,%rcx
   4c244:	jmp    *%rcx
   4c246:	lea    -0x30(%r12),%ecx
   4c24b:	cmp    $0xa,%cl
   4c24e:	jae    4c383 <hotaru_core::Terminal::feed_inner+0x683>
   4c254:	cmpq   $0x0,0xab8(%r14)
   4c25c:	jne    4ca26 <hotaru_core::Terminal::feed_inner+0xd26>
   4c262:	movb   $0x1,0xad4(%r14)
   4c26a:	mov    0xab0(%r14),%rsi
   4c271:	lea    -0x1(%rsi),%rdi
   4c275:	cmp    $0x1f,%rdi
   4c279:	ja     4cc9f <hotaru_core::Terminal::feed_inner+0xf9f>
   4c27f:	lea    0xa30(%r14),%rdx
   4c286:	mov    $0xa,%ax
   4c28a:	movb   $0x1,-0x1(%rdx,%rsi,4)
   4c28f:	mulw   -0x4(%rdx,%rsi,4)
   4c294:	jo     4cb80 <hotaru_core::Terminal::feed_inner+0xe80>
   4c29a:	movzbl %cl,%ecx
   4c29d:	mov    $0xffff,%edi
   4c2a2:	lea    0xa30(%r14),%rdx
   4c2a9:	add    %ax,%cx
   4c2ac:	cmovb  %edi,%ecx
   4c2af:	mov    %cx,-0x4(%rdx,%rsi,4)
   4c2b4:	jmp    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4c2b9:	movzbl %r12b,%edi
   4c2bd:	shl    $0x6,%eax
   4c2c0:	and    $0x3f,%edi
   4c2c3:	or     %eax,%edi
   4c2c5:	dec    %cl
   4c2c7:	mov    %edi,0xac8(%r14)
   4c2ce:	mov    %cl,0xad9(%r14)
   4c2d5:	jne    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4c2db:	xor    $0xd800,%eax
   4c2e0:	mov    $0xfffd,%ecx
   4c2e5:	mov    %edi,%esi
   4c2e7:	add    $0xffef0000,%eax
   4c2ec:	cmp    $0xffef0800,%eax
   4c2f1:	cmovb  %ecx,%esi
   4c2f4:	cmp    %edx,%edi
   4c2f6:	mov    %r14,%rdi
   4c2f9:	cmovb  %ecx,%esi
   4c2fc:	call   *0x56f2e(%rip)        # a3230 <_DYNAMIC+0x5d0>
   4c302:	jmp    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4c307:	movq   $0x0,0xa28(%r14)
   4c312:	movb   $0x1,0xad7(%r14)
   4c31a:	movq   $0x0,0xab8(%r14)
   4c325:	movzbl %r12b,%eax
   4c329:	add    $0xffffffb0,%eax
   4c32c:	cmp    $0xf,%eax
   4c32f:	ja     4c4a2 <hotaru_core::Terminal::feed_inner+0x7a2>
   4c335:	lea    -0x41638(%rip),%rcx        # ad04 <anon.58baeeae7d5fe476157d296c9f08f803.334.llvm.5844774155465566772+0xd37>
   4c33c:	movslq (%rcx,%rax,4),%rax
   4c340:	add    %rcx,%rax
   4c343:	jmp    *%rax
   4c345:	mov    0xab8(%r14),%rdx
   4c34c:	mov    $0x50,%r12b
   4c34f:	test   %rdx,%rdx
   4c352:	jne    4c86a <hotaru_core::Terminal::feed_inner+0xb6a>
   4c358:	mov    $0x3,%al
   4c35a:	jmp    4c44b <hotaru_core::Terminal::feed_inner+0x74b>
   4c35f:	cmp    $0x7,%r12b
   4c363:	je     4c5c7 <hotaru_core::Terminal::feed_inner+0x8c7>
   4c369:	movzbl %r12b,%eax
   4c36d:	cmp    $0x1b,%eax
   4c370:	jne    4c5f6 <hotaru_core::Terminal::feed_inner+0x8f6>
   4c376:	movb   $0x8,0xad7(%r14)
   4c37e:	jmp    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4c383:	cmp    $0x3a,%r12b
   4c387:	je     4c549 <hotaru_core::Terminal::feed_inner+0x849>
   4c38d:	movzbl %r12b,%ecx
   4c391:	cmp    $0x3b,%ecx
   4c394:	je     4c549 <hotaru_core::Terminal::feed_inner+0x849>
   4c39a:	cmp    $0x7f,%ecx
   4c39d:	je     4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4c3a3:	mov    %r12d,%ecx
   4c3a6:	and    $0xfc,%cl
   4c3a9:	cmp    $0x3c,%cl
   4c3ac:	jne    4c921 <hotaru_core::Terminal::feed_inner+0xc21>
   4c3b2:	cmpq   $0x1,0xab0(%r14)
   4c3ba:	jne    4ca26 <hotaru_core::Terminal::feed_inner+0xd26>
   4c3c0:	cmpw   $0x0,0xa30(%r14)
   4c3c9:	jne    4ca26 <hotaru_core::Terminal::feed_inner+0xd26>
   4c3cf:	cmpb   $0x0,0xad0(%r14)
   4c3d7:	jne    4ca26 <hotaru_core::Terminal::feed_inner+0xd26>
   4c3dd:	cmpq   $0x0,0xab8(%r14)
   4c3e5:	jne    4ca26 <hotaru_core::Terminal::feed_inner+0xd26>
   4c3eb:	movb   $0x1,0xad0(%r14)
   4c3f3:	mov    %r12b,0xad1(%r14)
   4c3fa:	jmp    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4c3ff:	movq   $0x0,0xa28(%r14)
   4c40a:	movb   $0x1,0xad7(%r14)
   4c412:	movq   $0x0,0xab8(%r14)
   4c41d:	cmp    $0x1b,%r12b
   4c421:	je     4c718 <hotaru_core::Terminal::feed_inner+0xa18>
   4c427:	cmp    $0x1f,%r12b
   4c42b:	ja     4c325 <hotaru_core::Terminal::feed_inner+0x625>
   4c431:	jmp    4c903 <hotaru_core::Terminal::feed_inner+0xc03>
   4c436:	mov    0xab8(%r14),%rdx
   4c43d:	mov    $0x5b,%r12b
   4c440:	test   %rdx,%rdx
   4c443:	jne    4c86a <hotaru_core::Terminal::feed_inner+0xb6a>
   4c449:	mov    $0x2,%al
   4c44b:	lea    0xa30(%r14),%rcx
   4c452:	mov    %al,0xad7(%r14)
   4c459:	vpxor  %xmm0,%xmm0,%xmm0
   4c45d:	vmovdqu64 %zmm0,0x40(%rcx)
   4c464:	vmovdqu64 %zmm0,(%rcx)
   4c46a:	movq   $0x1,0xab0(%r14)
   4c475:	movb   $0x0,0xad4(%r14)
   4c47d:	movb   $0x0,0xad0(%r14)
   4c485:	jmp    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4c48a:	mov    0xab8(%r14),%rdx
   4c491:	mov    $0x5f,%r12b
   4c494:	test   %rdx,%rdx
   4c497:	jne    4c86a <hotaru_core::Terminal::feed_inner+0xb6a>
   4c49d:	jmp    4c53c <hotaru_core::Terminal::feed_inner+0x83c>
   4c4a2:	cmp    $0x30,%r12b
   4c4a6:	jae    4c859 <hotaru_core::Terminal::feed_inner+0xb59>
   4c4ac:	mov    0xab8(%r14),%rax
   4c4b3:	cmp    $0x2,%rax
   4c4b7:	jae    4c914 <hotaru_core::Terminal::feed_inner+0xc14>
   4c4bd:	mov    %r12b,0xad2(%r14,%rax,1)
   4c4c5:	inc    %rax
   4c4c8:	mov    %rax,0xab8(%r14)
   4c4cf:	jmp    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4c4d4:	mov    0xab8(%r14),%rdx
   4c4db:	mov    $0x58,%r12b
   4c4de:	test   %rdx,%rdx
   4c4e1:	jne    4c86a <hotaru_core::Terminal::feed_inner+0xb6a>
   4c4e7:	jmp    4c53c <hotaru_core::Terminal::feed_inner+0x83c>
   4c4e9:	mov    0xab8(%r14),%rdx
   4c4f0:	mov    $0x5d,%r12b
   4c4f3:	test   %rdx,%rdx
   4c4f6:	jne    4c86a <hotaru_core::Terminal::feed_inner+0xb6a>
   4c4fc:	movb   $0x7,0xad7(%r14)
   4c504:	movq   $0x0,0xa28(%r14)
   4c50f:	movw   $0x0,0xad5(%r14)
   4c519:	movq   $0x800,0xac0(%r14)
   4c524:	jmp    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4c529:	mov    0xab8(%r14),%rdx
   4c530:	mov    $0x5e,%r12b
   4c533:	test   %rdx,%rdx
   4c536:	jne    4c86a <hotaru_core::Terminal::feed_inner+0xb6a>
   4c53c:	movb   $0x9,0xad7(%r14)
   4c544:	jmp    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4c549:	cmpq   $0x0,0xab8(%r14)
   4c551:	jne    4ca26 <hotaru_core::Terminal::feed_inner+0xd26>
   4c557:	movb   $0x1,0xad4(%r14)
   4c55f:	mov    0xab0(%r14),%rcx
   4c566:	cmp    $0x20,%rcx
   4c56a:	je     4ca26 <hotaru_core::Terminal::feed_inner+0xd26>
   4c570:	lea    -0x1(%rcx),%rdi
   4c574:	cmp    $0x1f,%rdi
   4c578:	ja     4ccc9 <hotaru_core::Terminal::feed_inner+0xfc9>
   4c57e:	cmp    $0x3a,%r12b
   4c582:	sete   0xa2e(%r14,%rcx,4)
   4c58b:	incq   0xab0(%r14)
   4c592:	jmp    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4c597:	mov    0xab0(%r14),%rsi
   4c59e:	cmp    $0x2,%rsi
   4c5a2:	jb     4c88d <hotaru_core::Terminal::feed_inner+0xb8d>
   4c5a8:	cmp    $0x21,%rsi
   4c5ac:	jae    4ccb1 <hotaru_core::Terminal::feed_inner+0xfb1>
   4c5b2:	lea    0xa30(%r14),%rax
   4c5b9:	movzbl -0x1(%rax,%rsi,4),%eax
   4c5be:	xor    $0x1,%rax
   4c5c2:	jmp    4c88f <hotaru_core::Terminal::feed_inner+0xb8f>
   4c5c7:	cmpb   $0x0,0xad5(%r14)
   4c5cf:	jne    4ca00 <hotaru_core::Terminal::feed_inner+0xd00>
   4c5d5:	mov    0xa20(%r14),%rsi
   4c5dc:	mov    0xa28(%r14),%rdx
   4c5e3:	mov    $0x1,%ecx
   4c5e8:	mov    %r14,%rdi
   4c5eb:	call   *0x56c97(%rip)        # a3288 <_DYNAMIC+0x628>
   4c5f1:	jmp    4ca00 <hotaru_core::Terminal::feed_inner+0xd00>
   4c5f6:	cmp    $0x7,%r12b
   4c5fa:	jb     4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4c600:	setne  %al
   4c603:	cmp    $0x20,%r12b
   4c607:	setb   %cl
   4c60a:	test   %cl,%al
   4c60c:	jne    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4c612:	movzbl 0xad5(%r14),%eax
   4c61a:	cmp    $0x3b,%r12b
   4c61e:	jne    4c66f <hotaru_core::Terminal::feed_inner+0x96f>
   4c620:	cmpb   $0x0,0xad6(%r14)
   4c628:	jne    4c66f <hotaru_core::Terminal::feed_inner+0x96f>
   4c62a:	test   %al,%al
   4c62c:	jne    4c66f <hotaru_core::Terminal::feed_inner+0x96f>
   4c62e:	mov    0xa28(%r14),%r15
   4c635:	cmp    $0x1,%r15
   4c639:	je     4cb32 <hotaru_core::Terminal::feed_inner+0xe32>
   4c63f:	mov    $0x800,%eax
   4c644:	cmp    $0x2,%r15
   4c648:	jne    4cb4a <hotaru_core::Terminal::feed_inner+0xe4a>
   4c64e:	mov    0xa20(%r14),%rax
   4c655:	mov    $0x800000,%ecx
   4c65a:	cmpw   $0x3235,(%rax)
   4c65f:	jmp    4cb41 <hotaru_core::Terminal::feed_inner+0xe41>
   4c664:	movzbl 0xad5(%r14),%eax
   4c66c:	mov    $0x5c,%r12b
   4c66f:	test   %al,%al
   4c671:	jne    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4c677:	mov    0xac0(%r14),%rax
   4c67e:	mov    0xa28(%r14),%r15
   4c685:	cmp    %rax,%r15
   4c688:	jae    4cb6a <hotaru_core::Terminal::feed_inner+0xe6a>
   4c68e:	lea    0xa18(%r14),%rcx
   4c695:	cmp    (%rcx),%r15
   4c698:	jne    4c828 <hotaru_core::Terminal::feed_inner+0xb28>
   4c69e:	lea    (%r15,%r15,1),%r10
   4c6a2:	mov    $0x40,%ecx
   4c6a7:	cmp    $0x41,%r10
   4c6ab:	cmovb  %rcx,%r10
   4c6af:	cmp    %r10,%rax
   4c6b2:	cmovb  %rax,%r10
   4c6b6:	cmp    %r15,%r10
   4c6b9:	je     4c81b <hotaru_core::Terminal::feed_inner+0xb1b>
   4c6bf:	jb     4cb6a <hotaru_core::Terminal::feed_inner+0xe6a>
   4c6c5:	mov    0xa20(%r14),%rdx
   4c6cc:	mov    $0x1,%r8d
   4c6d2:	mov    $0x1,%r9d
   4c6d8:	mov    %rsp,%rdi
   4c6db:	mov    %r15,%rsi
   4c6de:	mov    %r10,%rcx
   4c6e1:	mov    %r10,0x28(%rsp)
   4c6e6:	jmp    4cb0a <hotaru_core::Terminal::feed_inner+0xe0a>
   4c6eb:	cmp    $0x1b,%r12b
   4c6ef:	je     4c718 <hotaru_core::Terminal::feed_inner+0xa18>
   4c6f1:	cmp    $0x1f,%r12b
   4c6f5:	jbe    4c903 <hotaru_core::Terminal::feed_inner+0xc03>
   4c6fb:	add    $0xc0,%r12b
   4c6ff:	cmp    $0x3f,%r12b
   4c703:	jae    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4c709:	jmp    4ca0b <hotaru_core::Terminal::feed_inner+0xd0b>
   4c70e:	cmp    $0x1b,%r12b
   4c712:	jne    4c8fd <hotaru_core::Terminal::feed_inner+0xbfd>
   4c718:	movb   $0x1,0xad7(%r14)
   4c720:	movq   $0x0,0xab8(%r14)
   4c72b:	jmp    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4c730:	cmpb   $0x0,0xad5(%r14)
   4c738:	jne    4ca00 <hotaru_core::Terminal::feed_inner+0xd00>
   4c73e:	mov    0xa20(%r14),%rsi
   4c745:	mov    0xa28(%r14),%rdx
   4c74c:	mov    %r14,%rdi
   4c74f:	xor    %ecx,%ecx
   4c751:	call   *0x56b31(%rip)        # a3288 <_DYNAMIC+0x628>
   4c757:	jmp    4ca00 <hotaru_core::Terminal::feed_inner+0xd00>
   4c75c:	cmpb   $0x0,0xad5(%r14)
   4c764:	jne    4ca00 <hotaru_core::Terminal::feed_inner+0xd00>
   4c76a:	mov    0xab0(%r14),%rsi
   4c771:	cmp    $0x1,%rsi
   4c775:	jbe    4c974 <hotaru_core::Terminal::feed_inner+0xc74>
   4c77b:	cmp    $0x21,%rsi
   4c77f:	jae    4ccb1 <hotaru_core::Terminal::feed_inner+0xfb1>
   4c785:	lea    0xa30(%r14),%rax
   4c78c:	movzbl -0x1(%rax,%rsi,4),%eax
   4c791:	xor    $0x1,%rax
   4c795:	jmp    4c976 <hotaru_core::Terminal::feed_inner+0xc76>
   4c79a:	cmp    $0x1b,%r12b
   4c79e:	jne    4c7ad <hotaru_core::Terminal::feed_inner+0xaad>
   4c7a0:	movb   $0x5,0xad7(%r14)
   4c7a8:	jmp    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4c7ad:	cmp    $0x20,%r12b
   4c7b1:	setb   %al
   4c7b4:	cmp    $0x7f,%r12b
   4c7b8:	sete   %cl
   4c7bb:	or     %al,%cl
   4c7bd:	jne    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4c7c3:	cmpb   $0x0,0xad5(%r14)
   4c7cb:	jne    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4c7d1:	mov    0xa28(%r14),%r15
   4c7d8:	cmp    $0x1fff,%r15
   4c7df:	ja     4cb6a <hotaru_core::Terminal::feed_inner+0xe6a>
   4c7e5:	lea    0xa18(%r14),%rax
   4c7ec:	cmp    (%rax),%r15
   4c7ef:	jne    4c828 <hotaru_core::Terminal::feed_inner+0xb28>
   4c7f1:	lea    (%r15,%r15,1),%rcx
   4c7f5:	mov    $0x40,%eax
   4c7fa:	cmp    $0x41,%rcx
   4c7fe:	cmovb  %rax,%rcx
   4c802:	mov    $0x2000,%eax
   4c807:	cmp    $0x2000,%rcx
   4c80e:	cmovae %rax,%rcx
   4c812:	cmp    %r15,%rcx
   4c815:	jne    4caea <hotaru_core::Terminal::feed_inner+0xdea>
   4c81b:	lea    0xa18(%r14),%rdi
   4c822:	call   *0x566b0(%rip)        # a2ed8 <_DYNAMIC+0x278>
   4c828:	mov    0xa20(%r14),%rax
   4c82f:	mov    %r12b,(%rax,%r15,1)
   4c833:	inc    %r15
   4c836:	mov    %r15,0xa28(%r14)
   4c83d:	jmp    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4c842:	cmp    $0x1b,%r12b
   4c846:	jne    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4c84c:	movb   $0xa,0xad7(%r14)
   4c854:	jmp    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4c859:	cmp    $0x7e,%r12b
   4c85d:	ja     4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4c863:	mov    0xab8(%r14),%rdx
   4c86a:	cmp    $0x3,%rdx
   4c86e:	jae    4cbf1 <hotaru_core::Terminal::feed_inner+0xef1>
   4c874:	movzbl %r12b,%ecx
   4c878:	lea    0xad2(%r14),%rsi
   4c87f:	mov    %r14,%rdi
   4c882:	call   *0x56a08(%rip)        # a3290 <_DYNAMIC+0x630>
   4c888:	jmp    4ca0b <hotaru_core::Terminal::feed_inner+0xd0b>
   4c88d:	xor    %eax,%eax
   4c88f:	sub    %rax,%rsi
   4c892:	cmp    $0x21,%rsi
   4c896:	jae    4cc33 <hotaru_core::Terminal::feed_inner+0xf33>
   4c89c:	mov    0xab8(%r14),%rax
   4c8a3:	cmp    $0x3,%rax
   4c8a7:	jae    4cc47 <hotaru_core::Terminal::feed_inner+0xf47>
   4c8ad:	movzbl 0xad4(%r14),%edx
   4c8b5:	movzwl 0xad0(%r14),%ecx
   4c8bd:	lea    0xa30(%r14),%rdi
   4c8c4:	mov    %rdi,(%rsp)
   4c8c8:	mov    %rsi,0x8(%rsp)
   4c8cd:	mov    %r14,%rdi
   4c8d0:	mov    %rsp,%rsi
   4c8d3:	mov    %dl,0x23(%rsp)
   4c8d7:	lea    0xad2(%r14),%rdx
   4c8de:	mov    %cx,0x21(%rsp)
   4c8e3:	mov    %rdx,0x10(%rsp)
   4c8e8:	mov    %rax,0x18(%rsp)
   4c8ed:	mov    %r12b,0x20(%rsp)
   4c8f2:	call   *0x569a0(%rip)        # a3298 <_DYNAMIC+0x638>
   4c8f8:	jmp    4ca0b <hotaru_core::Terminal::feed_inner+0xd0b>
   4c8fd:	cmp    $0x1f,%r12b
   4c901:	ja     4c959 <hotaru_core::Terminal::feed_inner+0xc59>
   4c903:	mov    %r14,%rdi
   4c906:	mov    %r15d,%esi
   4c909:	call   *0x56991(%rip)        # a32a0 <_DYNAMIC+0x640>
   4c90f:	jmp    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4c914:	movb   $0x6,0xad7(%r14)
   4c91c:	jmp    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4c921:	cmp    $0x30,%r12b
   4c925:	jae    4ca18 <hotaru_core::Terminal::feed_inner+0xd18>
   4c92b:	mov    0xab8(%r14),%rdi
   4c932:	cmp    $0x2,%rdi
   4c936:	je     4ca26 <hotaru_core::Terminal::feed_inner+0xd26>
   4c93c:	jae    4ccdb <hotaru_core::Terminal::feed_inner+0xfdb>
   4c942:	mov    %r12b,0xad2(%r14,%rdi,1)
   4c94a:	inc    %rdi
   4c94d:	mov    %rdi,0xab8(%r14)
   4c954:	jmp    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4c959:	cmp    $0x7e,%r12b
   4c95d:	ja     4ca3d <hotaru_core::Terminal::feed_inner+0xd3d>
   4c963:	mov    %r14,%rdi
   4c966:	mov    %r15d,%esi
   4c969:	call   *0x568c1(%rip)        # a3230 <_DYNAMIC+0x5d0>
   4c96f:	jmp    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4c974:	xor    %eax,%eax
   4c976:	sub    %rax,%rsi
   4c979:	cmp    $0x21,%rsi
   4c97d:	jae    4cc74 <hotaru_core::Terminal::feed_inner+0xf74>
   4c983:	mov    0xab8(%r14),%rax
   4c98a:	cmp    $0x3,%rax
   4c98e:	jae    4cc88 <hotaru_core::Terminal::feed_inner+0xf88>
   4c994:	vmovd  0xad8(%r14),%xmm0
   4c99d:	lea    0xa30(%r14),%rcx
   4c9a4:	mov    0xa20(%r14),%rdx
   4c9ab:	mov    %r14,%rdi
   4c9ae:	mov    %rcx,(%rsp)
   4c9b2:	lea    0xad2(%r14),%rcx
   4c9b9:	mov    %rsi,0x8(%rsp)
   4c9be:	mov    %rsp,%rsi
   4c9c1:	mov    %rcx,0x10(%rsp)
   4c9c6:	mov    %rax,0x18(%rsp)
   4c9cb:	mov    0xad0(%r14),%rax
   4c9d2:	mov    %eax,%ecx
   4c9d4:	shr    $0x8,%ecx
   4c9d7:	vpinsrb $0x1,%eax,%xmm0,%xmm0
   4c9dd:	shr    $0x20,%rax
   4c9e1:	vpinsrb $0x2,%ecx,%xmm0,%xmm0
   4c9e7:	mov    0xa28(%r14),%rcx
   4c9ee:	vpinsrb $0x3,%eax,%xmm0,%xmm0
   4c9f4:	vmovd  %xmm0,0x20(%rsp)
   4c9fa:	call   *0x568a8(%rip)        # a32a8 <_DYNAMIC+0x648>
   4ca00:	movq   $0x0,0xa28(%r14)
   4ca0b:	movb   $0x0,0xad7(%r14)
   4ca13:	jmp    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4ca18:	lea    -0x40(%r12),%ecx
   4ca1d:	cmp    $0x3f,%cl
   4ca20:	jb     4c171 <hotaru_core::Terminal::feed_inner+0x471>
   4ca26:	xor    %ecx,%ecx
   4ca28:	cmp    $0x3,%al
   4ca2a:	sete   %cl
   4ca2d:	lea    0x6(%rcx,%rcx,2),%eax
   4ca31:	mov    %al,0xad7(%r14)
   4ca38:	jmp    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4ca3d:	cmp    $0x7f,%r12b
   4ca41:	je     4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4ca47:	lea    0x3e(%r12),%eax
   4ca4c:	cmp    $0x1e,%al
   4ca4e:	jae    4ca77 <hotaru_core::Terminal::feed_inner+0xd77>
   4ca50:	and    $0x1f,%r12b
   4ca54:	movzbl %r12b,%eax
   4ca58:	mov    %eax,0xac8(%r14)
   4ca5f:	movb   $0x1,0xad9(%r14)
   4ca67:	movl   $0x80,0xacc(%r14)
   4ca72:	jmp    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4ca77:	mov    %r12d,%eax
   4ca7a:	and    $0xf0,%al
   4ca7c:	cmp    $0xe0,%al
   4ca7e:	jne    4caa7 <hotaru_core::Terminal::feed_inner+0xda7>
   4ca80:	and    $0xf,%r12b
   4ca84:	movzbl %r12b,%eax
   4ca88:	mov    %eax,0xac8(%r14)
   4ca8f:	movb   $0x2,0xad9(%r14)
   4ca97:	movl   $0x800,0xacc(%r14)
   4caa2:	jmp    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4caa7:	lea    0x10(%r12),%eax
   4caac:	cmp    $0x5,%al
   4caae:	jae    4cad7 <hotaru_core::Terminal::feed_inner+0xdd7>
   4cab0:	and    $0x7,%r12b
   4cab4:	movzbl %r12b,%eax
   4cab8:	mov    %eax,0xac8(%r14)
   4cabf:	movb   $0x3,0xad9(%r14)
   4cac7:	movl   $0x10000,0xacc(%r14)
   4cad2:	jmp    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4cad7:	mov    $0xfffd,%esi
   4cadc:	mov    %r14,%rdi
   4cadf:	call   *0x5674b(%rip)        # a3230 <_DYNAMIC+0x5d0>
   4cae5:	jmp    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4caea:	jb     4cb6a <hotaru_core::Terminal::feed_inner+0xe6a>
   4caec:	mov    0xa20(%r14),%rdx
   4caf3:	mov    $0x1,%r8d
   4caf9:	mov    $0x1,%r9d
   4caff:	mov    %rsp,%rdi
   4cb02:	mov    %r15,%rsi
   4cb05:	mov    %rcx,0x28(%rsp)
   4cb0a:	call   50bd0 <alloc::raw_vec::RawVecInner<A>::finish_grow>
   4cb0f:	cmpl   $0x1,(%rsp)
   4cb13:	je     4cb6a <hotaru_core::Terminal::feed_inner+0xe6a>
   4cb15:	mov    0x8(%rsp),%rax
   4cb1a:	mov    0x28(%rsp),%rcx
   4cb1f:	mov    %rax,0xa20(%r14)
   4cb26:	mov    %rcx,0xa18(%r14)
   4cb2d:	jmp    4c828 <hotaru_core::Terminal::feed_inner+0xb28>
   4cb32:	mov    0xa20(%r14),%rax
   4cb39:	mov    $0x4000,%ecx
   4cb3e:	cmpb   $0x37,(%rax)
   4cb41:	mov    $0x800,%eax
   4cb46:	cmove  %rcx,%rax
   4cb4a:	lea    0x1(%r15,%rax,1),%rax
   4cb4f:	mov    $0x3b,%r12b
   4cb52:	mov    %rax,0xac0(%r14)
   4cb59:	movb   $0x1,0xad6(%r14)
   4cb61:	cmp    %rax,%r15
   4cb64:	jb     4c68e <hotaru_core::Terminal::feed_inner+0x98e>
   4cb6a:	movb   $0x1,0xad5(%r14)
   4cb72:	xor    %eax,%eax
   4cb74:	mov    %rax,0xa28(%r14)
   4cb7b:	jmp    4bd56 <hotaru_core::Terminal::feed_inner+0x56>
   4cb80:	mov    $0xffff,%ax
   4cb84:	jmp    4c29a <hotaru_core::Terminal::feed_inner+0x59a>
   4cb89:	xor    %ebx,%ebx
   4cb8b:	jmp    4cb94 <hotaru_core::Terminal::feed_inner+0xe94>
   4cb8d:	xor    %ebx,%ebx
   4cb8f:	mov    0x30(%rsp),%r15
   4cb94:	incq   0x6c8(%r14)
   4cb9b:	mov    %r14,%rdi
   4cb9e:	call   491b0 <hotaru_core::screen::Screen::enforce_budget>
   4cba3:	add    $0x130,%r14
   4cbaa:	mov    %r14,%rdi
   4cbad:	call   491b0 <hotaru_core::screen::Screen::enforce_budget>
   4cbb2:	sub    %rbx,%r15
   4cbb5:	mov    %r15,%rax
   4cbb8:	add    $0x58,%rsp
   4cbbc:	pop    %rbx
   4cbbd:	pop    %r12
   4cbbf:	pop    %r13
   4cbc1:	pop    %r14
   4cbc3:	pop    %r15
   4cbc5:	pop    %rbp
   4cbc6:	ret
   4cbc7:	lea    0x53d6a(%rip),%rcx        # a0938 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0xa48>
   4cbce:	xor    %edi,%edi
   4cbd0:	mov    %r15,%rsi
   4cbd3:	mov    %rbx,%rdx
   4cbd6:	call   *0x56414(%rip)        # a2ff0 <_DYNAMIC+0x390>
   4cbdc:	lea    0x53d3d(%rip),%rcx        # a0920 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0xa30>
   4cbe3:	xor    %edi,%edi
   4cbe5:	mov    %rbp,%rsi
   4cbe8:	mov    %rbx,%rdx
   4cbeb:	call   *0x563ff(%rip)        # a2ff0 <_DYNAMIC+0x390>
   4cbf1:	mov    %rdx,%rsi
   4cbf4:	lea    0x5376d(%rip),%rcx        # a0368 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x478>
   4cbfb:	mov    $0x2,%edx
   4cc00:	xor    %edi,%edi
   4cc02:	call   *0x563e8(%rip)        # a2ff0 <_DYNAMIC+0x390>
   4cc08:	lea    0x53cf9(%rip),%rcx        # a0908 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0xa18>
   4cc0f:	mov    %rdx,%rsi
   4cc12:	xor    %edi,%edi
   4cc14:	mov    %rbx,%rdx
   4cc17:	call   *0x563d3(%rip)        # a2ff0 <_DYNAMIC+0x390>
   4cc1d:	lea    0x53cb4(%rip),%rcx        # a08d8 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x9e8>
   4cc24:	mov    %r15,%rdi
   4cc27:	mov    %rbx,%rsi
   4cc2a:	mov    %rbx,%rdx
   4cc2d:	call   *0x563bd(%rip)        # a2ff0 <_DYNAMIC+0x390>
   4cc33:	lea    0x5378e(%rip),%rcx        # a03c8 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x4d8>
   4cc3a:	mov    $0x20,%edx
   4cc3f:	xor    %edi,%edi
   4cc41:	call   *0x563a9(%rip)        # a2ff0 <_DYNAMIC+0x390>
   4cc47:	lea    0x53762(%rip),%rcx        # a03b0 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x4c0>
   4cc4e:	mov    $0x2,%edx
   4cc53:	xor    %edi,%edi
   4cc55:	mov    %rax,%rsi
   4cc58:	call   *0x56392(%rip)        # a2ff0 <_DYNAMIC+0x390>
   4cc5e:	lea    0x53c8b(%rip),%rcx        # a08f0 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0xa00>
   4cc65:	mov    %r15,%rdi
   4cc68:	mov    %rbx,%rsi
   4cc6b:	mov    %rbx,%rdx
   4cc6e:	call   *0x5637c(%rip)        # a2ff0 <_DYNAMIC+0x390>
   4cc74:	lea    0x537ad(%rip),%rcx        # a0428 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x538>
   4cc7b:	mov    $0x20,%edx
   4cc80:	xor    %edi,%edi
   4cc82:	call   *0x56368(%rip)        # a2ff0 <_DYNAMIC+0x390>
   4cc88:	lea    0x53781(%rip),%rcx        # a0410 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x520>
   4cc8f:	mov    $0x2,%edx
   4cc94:	xor    %edi,%edi
   4cc96:	mov    %rax,%rsi
   4cc99:	call   *0x56351(%rip)        # a2ff0 <_DYNAMIC+0x390>
   4cc9f:	lea    0x53752(%rip),%rdx        # a03f8 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x508>
   4cca6:	mov    $0x20,%esi
   4ccab:	call   *0x561ef(%rip)        # a2ea0 <_DYNAMIC+0x240>
   4ccb1:	dec    %rsi
   4ccb4:	lea    0x536dd(%rip),%rdx        # a0398 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x4a8>
   4ccbb:	mov    %rsi,%rdi
   4ccbe:	mov    $0x20,%esi
   4ccc3:	call   *0x561d7(%rip)        # a2ea0 <_DYNAMIC+0x240>
   4ccc9:	lea    0x536b0(%rip),%rdx        # a0380 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x490>
   4ccd0:	mov    $0x20,%esi
   4ccd5:	call   *0x561c5(%rip)        # a2ea0 <_DYNAMIC+0x240>
   4ccdb:	lea    0x536fe(%rip),%rdx        # a03e0 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x4f0>
   4cce2:	mov    $0x2,%esi
   4cce7:	call   *0x561b3(%rip)        # a2ea0 <_DYNAMIC+0x240>
