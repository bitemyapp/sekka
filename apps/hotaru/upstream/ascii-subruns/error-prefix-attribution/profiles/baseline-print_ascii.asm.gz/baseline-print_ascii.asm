
/home/callen/work/hotaru-ascii-cell-store-20261028/target/release/hotaru-replay:     file format elf64-x86-64


Disassembly of section .text:

0000000000045cf0 <hotaru_core::screen::State::print_ascii>:
   45cf0:	push   %rbp
   45cf1:	push   %r15
   45cf3:	push   %r14
   45cf5:	push   %r13
   45cf7:	push   %r12
   45cf9:	push   %rbx
   45cfa:	sub    $0xf8,%rsp
   45d01:	cmpb   $0x0,0xa02(%rdi)
   45d08:	mov    %rdx,%r15
   45d0b:	mov    %rsi,%r12
   45d0e:	mov    %rdi,%r13
   45d11:	je     45d55 <hotaru_core::screen::State::print_ascii+0x65>
   45d13:	test   %r15,%r15
   45d16:	je     45d43 <hotaru_core::screen::State::print_ascii+0x53>
   45d18:	mov    0x5d1e1(%rip),%r14        # a2f00 <_DYNAMIC+0x5d0>
   45d1f:	xor    %ebx,%ebx
   45d21:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   45d30:	movzbl (%r12,%rbx,1),%esi
   45d35:	mov    %r13,%rdi
   45d38:	call   *%r14
   45d3b:	inc    %rbx
   45d3e:	cmp    %rbx,%r15
   45d41:	jne    45d30 <hotaru_core::screen::State::print_ascii+0x40>
   45d43:	add    $0xf8,%rsp
   45d4a:	pop    %rbx
   45d4b:	pop    %r12
   45d4d:	pop    %r13
   45d4f:	pop    %r14
   45d51:	pop    %r15
   45d53:	pop    %rbp
   45d54:	ret
   45d55:	mov    0x3b8(%r13),%rdi
   45d5c:	cmp    $0x4,%rdi
   45d60:	jae    466be <hotaru_core::screen::State::print_ascii+0x9ce>
   45d66:	cmpb   $0x0,0x6d8(%r13,%rdi,1)
   45d6f:	jne    45d13 <hotaru_core::screen::State::print_ascii+0x23>
   45d71:	cmpq   $0x0,0x260(%r13)
   45d79:	jne    45d13 <hotaru_core::screen::State::print_ascii+0x23>
   45d7b:	test   %r15,%r15
   45d7e:	je     45d43 <hotaru_core::screen::State::print_ascii+0x53>
   45d80:	lea    0x6ea(%r13),%rax
   45d87:	lea    0x130(%r13),%rdx
   45d8e:	lea    0x38(%rsp),%rcx
   45d93:	mov    %r13,0x40(%rsp)
   45d98:	mov    %rax,0x78(%rsp)
   45d9d:	mov    %rdx,0x48(%rsp)
   45da2:	mov    %rcx,0x68(%rsp)
   45da7:	jmp    45dc3 <hotaru_core::screen::State::print_ascii+0xd3>
   45da9:	nopl   0x0(%rax)
   45db0:	xor    %r15d,%r15d
   45db3:	mov    0x28(%rsp),%rax
   45db8:	add    %r15,%r12
   45dbb:	sub    %r15,%rax
   45dbe:	mov    %rax,%r15
   45dc1:	je     45d43 <hotaru_core::screen::State::print_ascii+0x53>
   45dc3:	cmpb   $0x0,0x6df(%r13)
   45dcb:	mov    %r13,%rbx
   45dce:	cmovne 0x48(%rsp),%rbx
   45dd4:	cmpb   $0x1,0x12f(%rbx)
   45ddb:	jne    45e68 <hotaru_core::screen::State::print_ascii+0x178>
   45de1:	movzbl 0xa01(%r13),%eax
   45de9:	mov    0x6ee(%r13),%ebp
   45df0:	movb   $0x0,0x12f(%rbx)
   45df7:	cmp    $0x1,%al
   45df9:	jne    45e68 <hotaru_core::screen::State::print_ascii+0x178>
   45dfb:	mov    %rbx,%rdi
   45dfe:	call   49b50 <hotaru_core::screen::Screen::row>
   45e03:	movb   $0x1,0x6e(%rax)
   45e07:	movq   $0x0,0x90(%rbx)
   45e12:	movb   $0x0,0x12f(%rbx)
   45e19:	mov    0x98(%rbx),%rax
   45e20:	cmp    0x100(%rbx),%rax
   45e27:	jne    45e3f <hotaru_core::screen::State::print_ascii+0x14f>
   45e29:	mov    $0x1,%esi
   45e2e:	mov    $0x1,%edx
   45e33:	mov    %rbx,%rdi
   45e36:	mov    %ebp,%ecx
   45e38:	call   49cb0 <hotaru_core::screen::Screen::scroll_up>
   45e3d:	jmp    45e57 <hotaru_core::screen::State::print_ascii+0x167>
   45e3f:	mov    0x38(%rbx),%rcx
   45e43:	inc    %rax
   45e46:	dec    %rcx
   45e49:	cmp    %rax,%rcx
   45e4c:	cmovae %rax,%rcx
   45e50:	mov    %rcx,0x98(%rbx)
   45e57:	mov    %rbx,%rdi
   45e5a:	call   49b50 <hotaru_core::screen::Screen::row>
   45e5f:	mov    0x40(%rsp),%r13
   45e64:	movb   $0x1,0x6f(%rax)
   45e68:	mov    %r13,%rdi
   45e6b:	mov    %r15,%rsi
   45e6e:	call   473b0 <hotaru_core::screen::State::scalar_metadata_writes>
   45e73:	mov    %r15,0x28(%rsp)
   45e78:	test   %al,%al
   45e7a:	je     46020 <hotaru_core::screen::State::print_ascii+0x330>
   45e80:	cmpb   $0x0,0x6df(%r13)
   45e88:	mov    %r13,%r14
   45e8b:	mov    0x78(%rsp),%rcx
   45e90:	cmovne 0x48(%rsp),%r14
   45e96:	mov    (%rcx),%rax
   45e99:	mov    0x6(%rcx),%rcx
   45e9d:	cmpb   $0x1,0x12f(%r14)
   45ea5:	mov    %rcx,0x5e(%rsp)
   45eaa:	mov    %rax,0x58(%rsp)
   45eaf:	je     45db0 <hotaru_core::screen::State::print_ascii+0xc0>
   45eb5:	movzbl 0x6e6(%r13),%eax
   45ebd:	movzbl 0xa01(%r13),%edx
   45ec5:	movzbl 0xa04(%r13),%ecx
   45ecd:	mov    %al,0x20(%rsp)
   45ed1:	mov    0x118(%r14),%rax
   45ed8:	mov    %dl,0x7(%rsp)
   45edc:	test   %rax,%rax
   45edf:	je     45eeb <hotaru_core::screen::State::print_ascii+0x1fb>
   45ee1:	lock incq (%rax)
   45ee5:	jle    46655 <hotaru_core::screen::State::print_ascii+0x965>
   45eeb:	mov    0x98(%r14),%rbx
   45ef2:	mov    %rax,0x8(%rsp)
   45ef7:	mov    %rax,0x38(%rsp)
   45efc:	cmp    0x38(%r14),%rbx
   45f00:	jae    4665b <hotaru_core::screen::State::print_ascii+0x96b>
   45f06:	add    0x30(%r14),%rbx
   45f0a:	mov    0x20(%r14),%rax
   45f0e:	mov    0x28(%r14),%r13
   45f12:	mov    %cl,0x14(%rsp)
   45f16:	mov    $0x0,%ecx
   45f1b:	mov    0x90(%r14),%r15
   45f22:	cmp    %rax,%rbx
   45f25:	cmovae %rax,%rcx
   45f29:	sub    %rcx,%rbx
   45f2c:	mov    0x0(%r13,%rbx,8),%rax
   45f31:	mov    (%rax),%rax
   45f34:	mov    0x0(%r13,%rbx,8),%rbp
   45f39:	cmp    $0x1,%rax
   45f3d:	je     45fb2 <hotaru_core::screen::State::print_ascii+0x2c2>
   45f3f:	lea    0x8(%rbp),%rsi
   45f43:	lea    0x88(%rsp),%rdi
   45f4b:	call   *0x5cfb7(%rip)        # a2f08 <_DYNAMIC+0x5d8>
   45f51:	mov    $0x78,%edi
   45f56:	movq   $0x1,0x80(%rsp)
   45f62:	call   *0x5cbb0(%rip)        # a2b18 <malloc@GLIBC_2.2.5>
   45f68:	test   %rax,%rax
   45f6b:	je     46676 <hotaru_core::screen::State::print_ascii+0x986>
   45f71:	vmovdqu64 0xb8(%rsp),%zmm1
   45f7c:	vmovdqu64 0x80(%rsp),%zmm0
   45f84:	lea    0x0(%r13,%rbx,8),%rbx
   45f89:	vmovdqu64 %zmm1,0x38(%rax)
   45f93:	vmovdqu64 %zmm0,(%rax)
   45f99:	lock decq 0x0(%rbp)
   45f9e:	mov    %rax,%rbp
   45fa1:	jne    45faf <hotaru_core::screen::State::print_ascii+0x2bf>
   45fa3:	mov    %rbx,%rdi
   45fa6:	vzeroupper
   45fa9:	call   *0x5cf61(%rip)        # a2f10 <_DYNAMIC+0x5e0>
   45faf:	mov    %rbp,(%rbx)
   45fb2:	movzbl (%r12),%edi
   45fb7:	cmpb   $0x0,0x20(%rsp)
   45fbc:	lea    0x8(%rbp),%rax
   45fc0:	mov    %rbp,0x70(%rsp)
   45fc5:	mov    %rax,0x18(%rsp)
   45fca:	mov    %edi,(%rsp)
   45fcd:	je     4619e <hotaru_core::screen::State::print_ascii+0x4ae>
   45fd3:	cmp    $0xa0,%dil
   45fd7:	jl     461c9 <hotaru_core::screen::State::print_ascii+0x4d9>
   45fdd:	mov    0xf0(%r14),%rcx
   45fe4:	lea    0x1(%r15),%rax
   45fe8:	mov    %rcx,0x30(%rsp)
   45fed:	cmp    %rcx,%rax
   45ff0:	ja     461c9 <hotaru_core::screen::State::print_ascii+0x4d9>
   45ff6:	movzbl 0x7(%rsp),%edx
   45ffb:	mov    0x18(%rsp),%rdi
   46000:	mov    (%rsp),%ecx
   46003:	mov    %r15,%rsi
   46006:	vzeroupper
   46009:	call   43f50 <hotaru_core::screen::unicode_batch_boundary>
   4600e:	mov    $0x1,%ebx
   46013:	test   %al,%al
   46015:	je     461c9 <hotaru_core::screen::State::print_ascii+0x4d9>
   4601b:	jmp    462f2 <hotaru_core::screen::State::print_ascii+0x602>
   46020:	cmpb   $0x0,0x6df(%r13)
   46028:	mov    %r13,%r14
   4602b:	mov    0x6ee(%r13),%edx
   46032:	movzbl 0xa04(%r13),%ecx
   4603a:	cmovne 0x48(%rsp),%r14
   46040:	mov    0x118(%r14),%rax
   46047:	test   %rax,%rax
   4604a:	je     46056 <hotaru_core::screen::State::print_ascii+0x366>
   4604c:	lock incq (%rax)
   46050:	jle    46655 <hotaru_core::screen::State::print_ascii+0x965>
   46056:	mov    %edx,0x20(%rsp)
   4605a:	mov    0xf0(%r14),%rdx
   46061:	mov    0x90(%r14),%rbp
   46068:	mov    %rax,0x8(%rsp)
   4606d:	mov    %rax,0x80(%rsp)
   46075:	mov    %r15,%rax
   46078:	mov    %cl,(%rsp)
   4607b:	mov    %rdx,%r15
   4607e:	sub    %rbp,%r15
   46081:	mov    %rdx,0x18(%rsp)
   46086:	cmp    %rax,%r15
   46089:	cmovae %rax,%r15
   4608d:	mov    %r14,%rdi
   46090:	call   49b50 <hotaru_core::screen::Screen::row>
   46095:	mov    %rax,%rbx
   46098:	mov    0x10(%rbx),%rdx
   4609c:	lea    (%r15,%rbp,1),%rax
   460a0:	cmp    $0x2,%rbp
   460a4:	jae    46100 <hotaru_core::screen::State::print_ascii+0x410>
   460a6:	cmp    $0x2,%rax
   460aa:	mov    $0x2,%esi
   460af:	cmovb  %rax,%rsi
   460b3:	cmp    %rdx,%rsi
   460b6:	ja     4662d <hotaru_core::screen::State::print_ascii+0x93d>
   460bc:	mov    0x8(%rbx),%rax
   460c0:	lea    0x0(,%rbp,8),%rcx
   460c8:	shl    $0x3,%rsi
   460cc:	sub    %rcx,%rsi
   460cf:	add    %rcx,%rax
   460d2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   460e0:	test   %rsi,%rsi
   460e3:	setne  %r13b
   460e7:	je     460f7 <hotaru_core::screen::State::print_ascii+0x407>
   460e9:	add    $0xfffffffffffffff8,%rsi
   460ed:	cmpb   $0x1,0x6(%rax)
   460f1:	lea    0x8(%rax),%rax
   460f5:	je     460e0 <hotaru_core::screen::State::print_ascii+0x3f0>
   460f7:	test   %rbp,%rbp
   460fa:	jne    46103 <hotaru_core::screen::State::print_ascii+0x413>
   460fc:	xor    %eax,%eax
   460fe:	jmp    46118 <hotaru_core::screen::State::print_ascii+0x428>
   46100:	xor    %r13d,%r13d
   46103:	cmp    %rdx,%rbp
   46106:	jae    466a1 <hotaru_core::screen::State::print_ascii+0x9b1>
   4610c:	mov    0x8(%rbx),%rax
   46110:	cmpb   $0x0,0x6(%rax,%rbp,8)
   46115:	sete   %al
   46118:	mov    0x20(%rsp),%r8d
   4611d:	movzbl %al,%ecx
   46120:	lea    (%r15,%rbp,1),%rdx
   46124:	mov    %rbx,%rdi
   46127:	mov    %rbp,%rsi
   4612a:	call   40860 <hotaru_core::row::Row::prepare_write_with_left>
   4612f:	mov    0x78(%rsp),%rsi
   46134:	mov    %rbx,%rdi
   46137:	call   41bc0 <hotaru_core::row::Row::style_id>
   4613c:	mov    0x10(%rbx),%rdx
   46140:	lea    (%r15,%rbp,1),%rsi
   46144:	cmp    %rbp,%rsi
   46147:	jb     4663b <hotaru_core::screen::State::print_ascii+0x94b>
   4614d:	mov    %rsi,0x20(%rsp)
   46152:	cmp    %rdx,%rsi
   46155:	ja     46636 <hotaru_core::screen::State::print_ascii+0x946>
   4615b:	cmp    %rbp,0x18(%rsp)
   46160:	je     46564 <hotaru_core::screen::State::print_ascii+0x874>
   46166:	movzbl (%rsp),%edx
   4616a:	mov    0x8(%rbx),%rsi
   4616e:	movzwl %ax,%eax
   46171:	movabs $0x1000000000000,%rdi
   4617b:	shl    $0x20,%rax
   4617f:	shl    $0x38,%rdx
   46183:	lea    (%rsi,%rbp,8),%rcx
   46187:	or     %rdx,%rax
   4618a:	or     %rdi,%rax
   4618d:	cmp    $0x8,%r15
   46191:	jae    46222 <hotaru_core::screen::State::print_ascii+0x532>
   46197:	xor    %edx,%edx
   46199:	jmp    46550 <hotaru_core::screen::State::print_ascii+0x860>
   4619e:	vzeroupper
   461a1:	call   43800 <hotaru_core::screen::char_width>
   461a6:	mov    %rax,%rbx
   461a9:	test   %rax,%rax
   461ac:	je     461c9 <hotaru_core::screen::State::print_ascii+0x4d9>
   461ae:	mov    0xf0(%r14),%rcx
   461b5:	mov    %rbx,%rax
   461b8:	add    %r15,%rax
   461bb:	mov    %rcx,0x30(%rsp)
   461c0:	cmp    %rcx,%rax
   461c3:	jbe    462f2 <hotaru_core::screen::State::print_ascii+0x602>
   461c9:	mov    %r15,0x90(%r14)
   461d0:	mov    $0x110000,%ebx
   461d5:	xor    %r15d,%r15d
   461d8:	mov    %r14,%rdi
   461db:	vzeroupper
   461de:	call   48f00 <hotaru_core::screen::Screen::enforce_budget>
   461e3:	mov    0x40(%rsp),%r13
   461e8:	cmp    $0x110000,%ebx
   461ee:	je     461f7 <hotaru_core::screen::State::print_ascii+0x507>
   461f0:	mov    %ebx,0x6d0(%r13)
   461f7:	mov    0x8(%rsp),%rax
   461fc:	test   %rax,%rax
   461ff:	je     46212 <hotaru_core::screen::State::print_ascii+0x522>
   46201:	lock decq (%rax)
   46205:	jne    46212 <hotaru_core::screen::State::print_ascii+0x522>
   46207:	lea    0x38(%rsp),%rdi
   4620c:	call   *0x5ccae(%rip)        # a2ec0 <_DYNAMIC+0x590>
   46212:	cmp    0x28(%rsp),%r15
   46217:	jbe    45db3 <hotaru_core::screen::State::print_ascii+0xc3>
   4621d:	jmp    46615 <hotaru_core::screen::State::print_ascii+0x925>
   46222:	vpbroadcastq %rax,%zmm0
   46228:	cmp    $0x20,%r15
   4622c:	jae    46235 <hotaru_core::screen::State::print_ascii+0x545>
   4622e:	xor    %edx,%edx
   46230:	jmp    462c2 <hotaru_core::screen::State::print_ascii+0x5d2>
   46235:	lea    0xc0(%rsi,%rbp,8),%rsi
   4623d:	mov    %r15,%rdx
   46240:	and    $0xffffffffffffffe0,%rdx
   46244:	xor    %edi,%edi
   46246:	cs nopw 0x0(%rax,%rax,1)
   46250:	vpmovzxbq (%r12,%rdi,1),%zmm1
   46257:	vpmovzxbq 0x8(%r12,%rdi,1),%zmm2
   4625f:	vpmovzxbq 0x10(%r12,%rdi,1),%zmm3
   46267:	vpmovzxbq 0x18(%r12,%rdi,1),%zmm4
   4626f:	vporq  %zmm1,%zmm0,%zmm1
   46275:	vporq  %zmm2,%zmm0,%zmm2
   4627b:	vporq  %zmm3,%zmm0,%zmm3
   46281:	vporq  %zmm4,%zmm0,%zmm4
   46287:	vmovdqu64 %zmm1,-0xc0(%rsi,%rdi,8)
   4628f:	vmovdqu64 %zmm2,-0x80(%rsi,%rdi,8)
   46297:	vmovdqu64 %zmm3,-0x40(%rsi,%rdi,8)
   4629f:	vmovdqu64 %zmm4,(%rsi,%rdi,8)
   462a6:	add    $0x20,%rdi
   462aa:	cmp    %rdi,%rdx
   462ad:	jne    46250 <hotaru_core::screen::State::print_ascii+0x560>
   462af:	cmp    %rdx,%r15
   462b2:	je     46564 <hotaru_core::screen::State::print_ascii+0x874>
   462b8:	test   $0x18,%r15b
   462bc:	je     46550 <hotaru_core::screen::State::print_ascii+0x860>
   462c2:	mov    %rdx,%rsi
   462c5:	mov    %r15,%rdx
   462c8:	and    $0xfffffffffffffff8,%rdx
   462cc:	nopl   0x0(%rax)
   462d0:	vpmovzxbq (%r12,%rsi,1),%zmm1
   462d7:	vporq  %zmm1,%zmm0,%zmm1
   462dd:	vmovdqu64 %zmm1,(%rcx,%rsi,8)
   462e4:	add    $0x8,%rsi
   462e8:	cmp    %rsi,%rdx
   462eb:	jne    462d0 <hotaru_core::screen::State::print_ascii+0x5e0>
   462ed:	jmp    4655f <hotaru_core::screen::State::print_ascii+0x86f>
   462f2:	cmp    $0x1,%r15
   462f6:	ja     46326 <hotaru_core::screen::State::print_ascii+0x636>
   462f8:	mov    0x70(%rsp),%rax
   462fd:	mov    0x18(%rax),%rsi
   46301:	cmp    %rsi,%r15
   46304:	jae    466d3 <hotaru_core::screen::State::print_ascii+0x9e3>
   4630a:	mov    0x10(%rax),%rax
   4630e:	movzbl 0x6(%rax,%r15,8),%eax
   46314:	cmp    $0x1,%rax
   46318:	setne  %cl
   4631b:	cmp    %eax,%ebx
   4631d:	setne  %r13b
   46321:	and    %cl,%r13b
   46324:	jmp    46329 <hotaru_core::screen::State::print_ascii+0x639>
   46326:	xor    %r13d,%r13d
   46329:	mov    0x58(%rsp),%rax
   4632e:	mov    0x5e(%rsp),%rcx
   46333:	mov    %rcx,0x86(%rsp)
   4633b:	mov    %rax,0x80(%rsp)
   46343:	movzbl 0x14(%rsp),%r9d
   46349:	mov    0x18(%rsp),%rdi
   4634e:	mov    (%rsp),%edx
   46351:	lea    0x80(%rsp),%r8
   46359:	mov    %r15,%rsi
   4635c:	mov    %rbx,%rcx
   4635f:	mov    %r9d,0x54(%rsp)
   46364:	call   40ce0 <hotaru_core::row::Row::put>
   46369:	add    %r15,%rbx
   4636c:	cmpq   $0x0,0x8(%rsp)
   46372:	je     46389 <hotaru_core::screen::State::print_ascii+0x699>
   46374:	mov    0x18(%rsp),%rdi
   46379:	lea    0x38(%rsp),%rcx
   4637e:	mov    %r15,%rsi
   46381:	mov    %rbx,%rdx
   46384:	call   40540 <hotaru_core::row::Row::set_hyperlink_range>
   46389:	mov    $0x1,%r15d
   4638f:	cmp    0x30(%rsp),%rbx
   46394:	jne    463ab <hotaru_core::screen::State::print_ascii+0x6bb>
   46396:	mov    0x30(%rsp),%rbx
   4639b:	movb   $0x1,0x12f(%r14)
   463a3:	dec    %rbx
   463a6:	jmp    46514 <hotaru_core::screen::State::print_ascii+0x824>
   463ab:	cmpq   $0x1,0x28(%rsp)
   463b1:	je     46514 <hotaru_core::screen::State::print_ascii+0x824>
   463b7:	nopw   0x0(%rax,%rax,1)
   463c0:	movzbl (%r12,%r15,1),%r8d
   463c5:	cmpb   $0x0,0x20(%rsp)
   463ca:	mov    %r8d,0x14(%rsp)
   463cf:	je     46420 <hotaru_core::screen::State::print_ascii+0x730>
   463d1:	xor    %eax,%eax
   463d3:	cmp    $0xa0,%r8b
   463d7:	setge  %cl
   463da:	jl     46514 <hotaru_core::screen::State::print_ascii+0x824>
   463e0:	mov    %cl,%al
   463e2:	add    %rbx,%rax
   463e5:	cmp    0x30(%rsp),%rax
   463ea:	ja     46514 <hotaru_core::screen::State::print_ascii+0x824>
   463f0:	movzbl 0x7(%rsp),%edx
   463f5:	mov    0x18(%rsp),%rdi
   463fa:	mov    %rbx,%rsi
   463fd:	mov    %r8d,%ecx
   46400:	call   43f50 <hotaru_core::screen::unicode_batch_boundary>
   46405:	mov    $0x1,%ebp
   4640a:	test   %al,%al
   4640c:	jne    46445 <hotaru_core::screen::State::print_ascii+0x755>
   4640e:	jmp    46514 <hotaru_core::screen::State::print_ascii+0x824>
   46413:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   46420:	mov    %r8d,%edi
   46423:	call   43800 <hotaru_core::screen::char_width>
   46428:	mov    %rax,%rbp
   4642b:	test   %rax,%rax
   4642e:	je     46514 <hotaru_core::screen::State::print_ascii+0x824>
   46434:	mov    %rbp,%rax
   46437:	add    %rbx,%rax
   4643a:	cmp    0x30(%rsp),%rax
   4643f:	ja     46514 <hotaru_core::screen::State::print_ascii+0x824>
   46445:	cmp    $0x1,%rbx
   46449:	ja     46480 <hotaru_core::screen::State::print_ascii+0x790>
   4644b:	mov    0x70(%rsp),%rax
   46450:	mov    0x18(%rax),%rsi
   46454:	cmp    %rsi,%rbx
   46457:	jae    466d0 <hotaru_core::screen::State::print_ascii+0x9e0>
   4645d:	mov    0x10(%rax),%rax
   46461:	movzbl 0x6(%rax,%rbx,8),%eax
   46466:	cmp    $0x1,%rax
   4646a:	setne  %cl
   4646d:	cmp    %eax,%ebp
   4646f:	setne  %al
   46472:	and    %cl,%al
   46474:	mov    %eax,(%rsp)
   46477:	jmp    46487 <hotaru_core::screen::State::print_ascii+0x797>
   46479:	nopl   0x0(%rax)
   46480:	movl   $0x0,(%rsp)
   46487:	mov    0x58(%rsp),%rax
   4648c:	mov    0x5e(%rsp),%rcx
   46491:	mov    %rcx,0x86(%rsp)
   46499:	mov    %rax,0x80(%rsp)
   464a1:	mov    0x18(%rsp),%rdi
   464a6:	mov    0x14(%rsp),%edx
   464aa:	mov    0x54(%rsp),%r9d
   464af:	lea    0x80(%rsp),%r8
   464b7:	mov    %rbx,%rsi
   464ba:	mov    %rbp,%rcx
   464bd:	call   40ce0 <hotaru_core::row::Row::put>
   464c2:	add    %rbx,%rbp
   464c5:	cmpq   $0x0,0x8(%rsp)
   464cb:	je     464e2 <hotaru_core::screen::State::print_ascii+0x7f2>
   464cd:	mov    0x18(%rsp),%rdi
   464d2:	lea    0x38(%rsp),%rcx
   464d7:	mov    %rbx,%rsi
   464da:	mov    %rbp,%rdx
   464dd:	call   40540 <hotaru_core::row::Row::set_hyperlink_range>
   464e2:	or     (%rsp),%r13b
   464e6:	and    $0x1,%r13b
   464ea:	cmp    0x30(%rsp),%rbp
   464ef:	je     46539 <hotaru_core::screen::State::print_ascii+0x849>
   464f1:	mov    0x14(%rsp),%eax
   464f5:	inc    %r15
   464f8:	mov    %rbp,%rbx
   464fb:	mov    %eax,(%rsp)
   464fe:	cmp    %r15,0x28(%rsp)
   46503:	jne    463c0 <hotaru_core::screen::State::print_ascii+0x6d0>
   46509:	mov    0x28(%rsp),%r15
   4650e:	mov    %rbp,%rbx
   46511:	mov    %eax,(%rsp)
   46514:	mov    %rbx,0x90(%r14)
   4651b:	test   $0x1,%r13b
   4651f:	je     46531 <hotaru_core::screen::State::print_ascii+0x841>
   46521:	mov    %r14,%rdi
   46524:	call   49020 <hotaru_core::screen::Screen::clear_previous_spacer>
   46529:	mov    (%rsp),%ebx
   4652c:	jmp    461d8 <hotaru_core::screen::State::print_ascii+0x4e8>
   46531:	mov    (%rsp),%ebx
   46534:	jmp    461d8 <hotaru_core::screen::State::print_ascii+0x4e8>
   46539:	mov    0x14(%rsp),%eax
   4653d:	inc    %r15
   46540:	mov    %eax,(%rsp)
   46543:	jmp    46396 <hotaru_core::screen::State::print_ascii+0x6a6>
   46548:	nopl   0x0(%rax,%rax,1)
   46550:	movzbl (%r12,%rdx,1),%esi
   46555:	or     %rax,%rsi
   46558:	mov    %rsi,(%rcx,%rdx,8)
   4655c:	inc    %rdx
   4655f:	cmp    %rdx,%r15
   46562:	jne    46550 <hotaru_core::screen::State::print_ascii+0x860>
   46564:	cmpq   $0x0,0x8(%rsp)
   4656a:	je     46587 <hotaru_core::screen::State::print_ascii+0x897>
   4656c:	mov    0x20(%rsp),%rdx
   46571:	lea    0x80(%rsp),%rcx
   46579:	mov    %rbx,%rdi
   4657c:	mov    %rbp,%rsi
   4657f:	vzeroupper
   46582:	call   40540 <hotaru_core::row::Row::set_hyperlink_range>
   46587:	test   %r13b,%r13b
   4658a:	je     46597 <hotaru_core::screen::State::print_ascii+0x8a7>
   4658c:	mov    %r14,%rdi
   4658f:	vzeroupper
   46592:	call   49020 <hotaru_core::screen::Screen::clear_previous_spacer>
   46597:	mov    0x20(%rsp),%rcx
   4659c:	mov    0x18(%rsp),%rax
   465a1:	mov    %rcx,0x90(%r14)
   465a8:	cmp    %rax,%rcx
   465ab:	jne    465bf <hotaru_core::screen::State::print_ascii+0x8cf>
   465ad:	dec    %rax
   465b0:	mov    %rax,0x90(%r14)
   465b7:	movb   $0x1,0x12f(%r14)
   465bf:	mov    %r14,%rdi
   465c2:	vzeroupper
   465c5:	call   48f00 <hotaru_core::screen::Screen::enforce_budget>
   465ca:	lea    -0x1(%r15),%rdi
   465ce:	cmp    0x28(%rsp),%rdi
   465d3:	jae    46688 <hotaru_core::screen::State::print_ascii+0x998>
   465d9:	movzbl (%r12,%rdi,1),%eax
   465de:	mov    0x40(%rsp),%r13
   465e3:	mov    %eax,0x6d0(%r13)
   465ea:	mov    0x8(%rsp),%rax
   465ef:	test   %rax,%rax
   465f2:	je     45db3 <hotaru_core::screen::State::print_ascii+0xc3>
   465f8:	lock decq (%rax)
   465fc:	jne    45db3 <hotaru_core::screen::State::print_ascii+0xc3>
   46602:	lea    0x80(%rsp),%rdi
   4660a:	call   *0x5c8b0(%rip)        # a2ec0 <_DYNAMIC+0x590>
   46610:	jmp    45db3 <hotaru_core::screen::State::print_ascii+0xc3>
   46615:	mov    0x28(%rsp),%rdx
   4661a:	lea    0x59c3f(%rip),%rcx        # a0260 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x640>
   46621:	mov    %r15,%rdi
   46624:	mov    %rdx,%rsi
   46627:	call   *0x5c693(%rip)        # a2cc0 <_DYNAMIC+0x390>
   4662d:	lea    0x59c14(%rip),%rcx        # a0248 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x628>
   46634:	jmp    46642 <hotaru_core::screen::State::print_ascii+0x952>
   46636:	mov    0x20(%rsp),%rsi
   4663b:	lea    0x59bee(%rip),%rcx        # a0230 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x610>
   46642:	mov    0x8(%rsp),%rbx
   46647:	mov    %rbp,%rdi
   4664a:	call   *0x5c670(%rip)        # a2cc0 <_DYNAMIC+0x390>
   46650:	jmp    466e3 <hotaru_core::screen::State::print_ascii+0x9f3>
   46655:	call   *0x5c855(%rip)        # a2eb0 <_DYNAMIC+0x580>
   4665b:	lea    -0x3940d(%rip),%rdi        # d255 <hotaru_core::unicode::BREAKS+0x214d>
   46662:	lea    0x59ce7(%rip),%rdx        # a0350 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x730>
   46669:	mov    $0x14,%esi
   4666e:	call   *0x5c684(%rip)        # a2cf8 <_DYNAMIC+0x3c8>
   46674:	jmp    466e3 <hotaru_core::screen::State::print_ascii+0x9f3>
   46676:	mov    $0x8,%edi
   4667b:	mov    $0x78,%esi
   46680:	call   *0x5c532(%rip)        # a2bb8 <_DYNAMIC+0x288>
   46686:	jmp    466e3 <hotaru_core::screen::State::print_ascii+0x9f3>
   46688:	mov    0x28(%rsp),%rsi
   4668d:	mov    0x8(%rsp),%rbx
   46692:	lea    0x59b7f(%rip),%rdx        # a0218 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x5f8>
   46699:	call   *0x5c4d1(%rip)        # a2b70 <_DYNAMIC+0x240>
   4669f:	jmp    466e3 <hotaru_core::screen::State::print_ascii+0x9f3>
   466a1:	mov    0x8(%rsp),%rbx
   466a6:	lea    0x596d3(%rip),%rax        # 9fd80 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x160>
   466ad:	mov    %rdx,%rsi
   466b0:	mov    %rbp,%rdi
   466b3:	mov    %rax,%rdx
   466b6:	call   *0x5c4b4(%rip)        # a2b70 <_DYNAMIC+0x240>
   466bc:	jmp    466e3 <hotaru_core::screen::State::print_ascii+0x9f3>
   466be:	lea    0x59b3b(%rip),%rdx        # a0200 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x5e0>
   466c5:	mov    $0x4,%esi
   466ca:	call   *0x5c4a0(%rip)        # a2b70 <_DYNAMIC+0x240>
   466d0:	mov    %rbx,%r15
   466d3:	lea    0x59c8e(%rip),%rdx        # a0368 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x748>
   466da:	mov    %r15,%rdi
   466dd:	call   *0x5c48d(%rip)        # a2b70 <_DYNAMIC+0x240>
   466e3:	ud2
   466e5:	mov    0x8(%rsp),%rcx
   466ea:	jmp    46726 <hotaru_core::screen::State::print_ascii+0xa36>
   466ec:	mov    0x8(%rsp),%rcx
   466f1:	jmp    46726 <hotaru_core::screen::State::print_ascii+0xa36>
   466f3:	jmp    4671c <hotaru_core::screen::State::print_ascii+0xa2c>
   466f5:	jmp    4671c <hotaru_core::screen::State::print_ascii+0xa2c>
   466f7:	mov    0x8(%rsp),%rbx
   466fc:	jmp    46733 <hotaru_core::screen::State::print_ascii+0xa43>
   466fe:	jmp    4671c <hotaru_core::screen::State::print_ascii+0xa2c>
   46700:	mov    0x8(%rsp),%rbx
   46705:	jmp    4672e <hotaru_core::screen::State::print_ascii+0xa3e>
   46707:	lea    0x88(%rsp),%rdi
   4670f:	mov    %rax,%rbx
   46712:	call   4f1f0 <core::ptr::drop_in_place<hotaru_core::row::Row>>
   46717:	mov    %rbx,%rax
   4671a:	jmp    4671c <hotaru_core::screen::State::print_ascii+0xa2c>
   4671c:	mov    0x8(%rsp),%rcx
   46721:	test   %rcx,%rcx
   46724:	je     4675c <hotaru_core::screen::State::print_ascii+0xa6c>
   46726:	lock decq (%rcx)
   4672a:	je     46746 <hotaru_core::screen::State::print_ascii+0xa56>
   4672c:	jmp    4675c <hotaru_core::screen::State::print_ascii+0xa6c>
   4672e:	test   %rbx,%rbx
   46731:	je     4675c <hotaru_core::screen::State::print_ascii+0xa6c>
   46733:	lock decq (%rbx)
   46737:	lea    0x80(%rsp),%rcx
   4673f:	mov    %rcx,0x68(%rsp)
   46744:	jne    4675c <hotaru_core::screen::State::print_ascii+0xa6c>
   46746:	mov    0x68(%rsp),%rdi
   4674b:	mov    %rax,%rbx
   4674e:	call   *0x5c76c(%rip)        # a2ec0 <_DYNAMIC+0x590>
   46754:	mov    %rbx,%rdi
   46757:	call   9e790 <_Unwind_Resume@plt>
   4675c:	mov    %rax,%rdi
   4675f:	call   9e790 <_Unwind_Resume@plt>
