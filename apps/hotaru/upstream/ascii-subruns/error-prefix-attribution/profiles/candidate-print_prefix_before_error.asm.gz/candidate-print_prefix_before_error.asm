
/home/callen/work/hotaru-error-ascii-prefix-20261028/target/release/hotaru-replay:     file format elf64-x86-64


Disassembly of section .text:

000000000003f620 <hotaru_core::print_prefix_before_error>:
   3f620:	push   %rbp
   3f621:	push   %r15
   3f623:	push   %r14
   3f625:	push   %r13
   3f627:	push   %r12
   3f629:	push   %rbx
   3f62a:	push   %rax
   3f62b:	vpbroadcastb -0x35533(%rip),%xmm1        # a101 <anon.58baeeae7d5fe476157d296c9f08f803.334.llvm.5844774155465566772+0x134>
   3f634:	vpbroadcastb -0x3553b(%rip),%xmm2        # a102 <anon.58baeeae7d5fe476157d296c9f08f803.334.llvm.5844774155465566772+0x135>
   3f63d:	movabs $0x7ffffffffffffff0,%r15
   3f647:	mov    %rdx,%rbx
   3f64a:	mov    %rsi,%r14
   3f64d:	mov    %rdi,(%rsp)
   3f651:	xor    %r13d,%r13d
   3f654:	xor    %r12d,%r12d
   3f657:	mov    %rbx,%rax
   3f65a:	sub    %r13,%rax
   3f65d:	lea    (%r14,%r13,1),%rcx
   3f661:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   3f670:	cmpb   $0x0,(%r14,%r13,1)
   3f675:	jns    3f690 <hotaru_core::print_prefix_before_error+0x70>
   3f677:	inc    %r13
   3f67a:	dec    %rax
   3f67d:	inc    %rcx
   3f680:	cmp    %rbx,%r13
   3f683:	jb     3f670 <hotaru_core::print_prefix_before_error+0x50>
   3f685:	jmp    3f7cc <hotaru_core::print_prefix_before_error+0x1ac>
   3f68a:	nopw   0x0(%rax,%rax,1)
   3f690:	mov    %rbx,%rdx
   3f693:	sub    %r13,%rdx
   3f696:	cmp    $0x10,%rdx
   3f69a:	jb     3f700 <hotaru_core::print_prefix_before_error+0xe0>
   3f69c:	and    %r15,%rdx
   3f69f:	mov    %rcx,%rsi
   3f6a2:	xor    %edi,%edi
   3f6a4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   3f6b0:	vpaddb (%rsi),%xmm1,%xmm0
   3f6b4:	vpcmpltub %xmm2,%xmm0,%k0
   3f6bb:	kortestw %k0,%k0
   3f6bf:	jne    3f7a7 <hotaru_core::print_prefix_before_error+0x187>
   3f6c5:	lea    -0x10(%rax,%rdi,1),%r8
   3f6ca:	add    $0xfffffffffffffff0,%rdi
   3f6ce:	add    $0x10,%rsi
   3f6d2:	cmp    $0xf,%r8
   3f6d6:	ja     3f6b0 <hotaru_core::print_prefix_before_error+0x90>
   3f6d8:	add    %rax,%rdi
   3f6db:	mov    %rdx,%rsi
   3f6de:	mov    %rdi,%rdx
   3f6e1:	test   %rdx,%rdx
   3f6e4:	jne    3f707 <hotaru_core::print_prefix_before_error+0xe7>
   3f6e6:	xor    %ebp,%ebp
   3f6e8:	add    %rsi,%rbp
   3f6eb:	cmp    $0xf,%rbp
   3f6ef:	ja     3f736 <hotaru_core::print_prefix_before_error+0x116>
   3f6f1:	jmp    3f7bc <hotaru_core::print_prefix_before_error+0x19c>
   3f6f6:	cs nopw 0x0(%rax,%rax,1)
   3f700:	xor    %esi,%esi
   3f702:	test   %rdx,%rdx
   3f705:	je     3f6e6 <hotaru_core::print_prefix_before_error+0xc6>
   3f707:	sub    %rsi,%rax
   3f70a:	add    %rsi,%rcx
   3f70d:	xor    %ebp,%ebp
   3f70f:	nop
   3f710:	movzbl (%rcx,%rbp,1),%edi
   3f714:	add    $0x81,%dil
   3f718:	cmp    $0xa1,%dil
   3f71c:	jb     3f729 <hotaru_core::print_prefix_before_error+0x109>
   3f71e:	inc    %rbp
   3f721:	cmp    %rbp,%rax
   3f724:	jne    3f710 <hotaru_core::print_prefix_before_error+0xf0>
   3f726:	mov    %rdx,%rbp
   3f729:	add    %rsi,%rbp
   3f72c:	cmp    $0xf,%rbp
   3f730:	jbe    3f7bc <hotaru_core::print_prefix_before_error+0x19c>
   3f736:	cmp    %r13,%r12
   3f739:	jae    3f760 <hotaru_core::print_prefix_before_error+0x140>
   3f73b:	test   %r12,%r12
   3f73e:	je     3f74b <hotaru_core::print_prefix_before_error+0x12b>
   3f740:	cmpb   $0xbf,(%r14,%r12,1)
   3f745:	jle    3f83e <hotaru_core::print_prefix_before_error+0x21e>
   3f74b:	mov    (%rsp),%rdi
   3f74f:	mov    %r13,%rdx
   3f752:	sub    %r12,%rdx
   3f755:	add    %r14,%r12
   3f758:	mov    %r12,%rsi
   3f75b:	call   44490 <hotaru_core::screen::State::print_utf8>
   3f760:	mov    %rbp,%r12
   3f763:	add    %r13,%r12
   3f766:	jb     3f80c <hotaru_core::print_prefix_before_error+0x1ec>
   3f76c:	cmp    %rbx,%r12
   3f76f:	ja     3f80c <hotaru_core::print_prefix_before_error+0x1ec>
   3f775:	mov    (%rsp),%rdi
   3f779:	add    %r14,%r13
   3f77c:	mov    %rbp,%rdx
   3f77f:	mov    %r13,%rsi
   3f782:	call   45fa0 <hotaru_core::screen::State::print_ascii>
   3f787:	vpbroadcastb -0x3568e(%rip),%xmm2        # a102 <anon.58baeeae7d5fe476157d296c9f08f803.334.llvm.5844774155465566772+0x135>
   3f790:	vpbroadcastb -0x35698(%rip),%xmm1        # a101 <anon.58baeeae7d5fe476157d296c9f08f803.334.llvm.5844774155465566772+0x134>
   3f799:	mov    %r12,%r13
   3f79c:	cmp    %rbx,%r13
   3f79f:	jb     3f657 <hotaru_core::print_prefix_before_error+0x37>
   3f7a5:	jmp    3f7cc <hotaru_core::print_prefix_before_error+0x1ac>
   3f7a7:	kmovd  %k0,%eax
   3f7ab:	tzcnt  %eax,%ebp
   3f7af:	sub    %rdi,%rbp
   3f7b2:	cmp    $0xf,%rbp
   3f7b6:	ja     3f736 <hotaru_core::print_prefix_before_error+0x116>
   3f7bc:	cmp    $0x1,%rbp
   3f7c0:	adc    %rbp,%r13
   3f7c3:	cmp    %rbx,%r13
   3f7c6:	jb     3f657 <hotaru_core::print_prefix_before_error+0x37>
   3f7cc:	mov    %rbx,%rdx
   3f7cf:	sub    %r12,%rdx
   3f7d2:	jbe    3f7fd <hotaru_core::print_prefix_before_error+0x1dd>
   3f7d4:	test   %r12,%r12
   3f7d7:	je     3f7e0 <hotaru_core::print_prefix_before_error+0x1c0>
   3f7d9:	cmpb   $0xbf,(%r14,%r12,1)
   3f7de:	jle    3f825 <hotaru_core::print_prefix_before_error+0x205>
   3f7e0:	mov    (%rsp),%rdi
   3f7e4:	add    %r12,%r14
   3f7e7:	mov    %r14,%rsi
   3f7ea:	add    $0x8,%rsp
   3f7ee:	pop    %rbx
   3f7ef:	pop    %r12
   3f7f1:	pop    %r13
   3f7f3:	pop    %r14
   3f7f5:	pop    %r15
   3f7f7:	pop    %rbp
   3f7f8:	jmp    44490 <hotaru_core::screen::State::print_utf8>
   3f7fd:	add    $0x8,%rsp
   3f801:	pop    %rbx
   3f802:	pop    %r12
   3f804:	pop    %r13
   3f806:	pop    %r14
   3f808:	pop    %r15
   3f80a:	pop    %rbp
   3f80b:	ret
   3f80c:	add    %r13,%rbp
   3f80f:	lea    0x607c2(%rip),%rcx        # 9ffd8 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0xe8>
   3f816:	mov    %r13,%rdi
   3f819:	mov    %rbx,%rdx
   3f81c:	mov    %rbp,%rsi
   3f81f:	call   *0x637cb(%rip)        # a2ff0 <_DYNAMIC+0x390>
   3f825:	lea    0x6077c(%rip),%r8        # 9ffa8 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0xb8>
   3f82c:	mov    %r14,%rdi
   3f82f:	mov    %rbx,%rsi
   3f832:	mov    %r12,%rdx
   3f835:	mov    %rbx,%rcx
   3f838:	call   *0x63722(%rip)        # a2f60 <_DYNAMIC+0x300>
   3f83e:	lea    0x6077b(%rip),%r8        # 9ffc0 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0xd0>
   3f845:	mov    %r14,%rdi
   3f848:	mov    %rbx,%rsi
   3f84b:	mov    %r12,%rdx
   3f84e:	mov    %r13,%rcx
   3f851:	call   *0x63709(%rip)        # a2f60 <_DYNAMIC+0x300>
