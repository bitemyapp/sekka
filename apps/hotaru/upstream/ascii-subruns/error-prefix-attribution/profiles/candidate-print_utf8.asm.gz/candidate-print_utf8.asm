
/home/callen/work/hotaru-error-ascii-prefix-20261028/target/release/hotaru-replay:     file format elf64-x86-64


Disassembly of section .text:

0000000000044490 <hotaru_core::screen::State::print_utf8>:
   44490:	push   %rbp
   44491:	push   %r15
   44493:	push   %r14
   44495:	push   %r13
   44497:	push   %r12
   44499:	push   %rbx
   4449a:	sub    $0x148,%rsp
   444a1:	cmpb   $0x0,0xa02(%rdi)
   444a8:	mov    %rdi,%r15
   444ab:	mov    %rdx,0x38(%rsp)
   444b0:	je     44557 <hotaru_core::screen::State::print_utf8+0xc7>
   444b6:	cmpq   $0x0,0x38(%rsp)
   444bc:	je     45a9f <hotaru_core::screen::State::print_utf8+0x160f>
   444c2:	add    %rsi,0x38(%rsp)
   444c7:	mov    0x5ed62(%rip),%rbx        # a3230 <_DYNAMIC+0x5d0>
   444ce:	mov    %rsi,%r14
   444d1:	jmp    444f3 <hotaru_core::screen::State::print_utf8+0x63>
   444d3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   444e0:	inc    %r14
   444e3:	mov    %r15,%rdi
   444e6:	call   *%rbx
   444e8:	cmp    0x38(%rsp),%r14
   444ed:	je     45a9f <hotaru_core::screen::State::print_utf8+0x160f>
   444f3:	movzbl (%r14),%esi
   444f7:	test   %sil,%sil
   444fa:	jns    444e0 <hotaru_core::screen::State::print_utf8+0x50>
   444fc:	movzbl 0x1(%r14),%edx
   44501:	mov    %esi,%eax
   44503:	and    $0x1f,%eax
   44506:	and    $0x3f,%edx
   44509:	cmp    $0xdf,%sil
   4450d:	jbe    4453d <hotaru_core::screen::State::print_utf8+0xad>
   4450f:	movzbl 0x2(%r14),%ecx
   44514:	shl    $0x6,%edx
   44517:	and    $0x3f,%ecx
   4451a:	or     %edx,%ecx
   4451c:	cmp    $0xf0,%sil
   44520:	jb     4454a <hotaru_core::screen::State::print_utf8+0xba>
   44522:	movzbl 0x3(%r14),%esi
   44527:	and    $0x7,%eax
   4452a:	shl    $0x6,%ecx
   4452d:	add    $0x4,%r14
   44531:	shl    $0x12,%eax
   44534:	and    $0x3f,%esi
   44537:	or     %ecx,%esi
   44539:	or     %eax,%esi
   4453b:	jmp    444e3 <hotaru_core::screen::State::print_utf8+0x53>
   4453d:	shl    $0x6,%eax
   44540:	add    $0x2,%r14
   44544:	or     %edx,%eax
   44546:	mov    %eax,%esi
   44548:	jmp    444e3 <hotaru_core::screen::State::print_utf8+0x53>
   4454a:	shl    $0xc,%eax
   4454d:	add    $0x3,%r14
   44551:	or     %eax,%ecx
   44553:	mov    %ecx,%esi
   44555:	jmp    444e3 <hotaru_core::screen::State::print_utf8+0x53>
   44557:	mov    0x3b8(%r15),%rdi
   4455e:	cmp    $0x4,%rdi
   44562:	jae    45b9c <hotaru_core::screen::State::print_utf8+0x170c>
   44568:	cmpb   $0x0,0x6d8(%r15,%rdi,1)
   44571:	jne    444b6 <hotaru_core::screen::State::print_utf8+0x26>
   44577:	cmpq   $0x0,0x260(%r15)
   4457f:	jne    444b6 <hotaru_core::screen::State::print_utf8+0x26>
   44585:	cmpq   $0x0,0x38(%rsp)
   4458b:	je     45a9f <hotaru_core::screen::State::print_utf8+0x160f>
   44591:	add    %rsi,0x38(%rsp)
   44596:	lea    0x6ea(%r15),%rax
   4459d:	mov    %r15,0x88(%rsp)
   445a5:	mov    %rax,0xb0(%rsp)
   445ad:	lea    0x6f2(%r15),%rax
   445b4:	mov    %rax,0xa8(%rsp)
   445bc:	lea    0x130(%r15),%rax
   445c3:	mov    %rax,0x90(%rsp)
   445cb:	lea    0x78(%rsp),%rax
   445d0:	mov    %rax,0xa0(%rsp)
   445d8:	lea    0x5c2b1(%rip),%rax        # a0890 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x9a0>
   445df:	mov    %rax,0x80(%rsp)
   445e7:	jmp    44608 <hotaru_core::screen::State::print_utf8+0x178>
   445e9:	nopl   0x0(%rax)
   445f0:	mov    0x88(%rsp),%r15
   445f8:	mov    0x10(%rsp),%rsi
   445fd:	cmp    0x38(%rsp),%rsi
   44602:	je     45a9f <hotaru_core::screen::State::print_utf8+0x160f>
   44608:	movzbl (%rsi),%r14d
   4460c:	test   %r14b,%r14b
   4460f:	js     44620 <hotaru_core::screen::State::print_utf8+0x190>
   44611:	inc    %rsi
   44614:	mov    %rsi,0x10(%rsp)
   44619:	jmp    446a0 <hotaru_core::screen::State::print_utf8+0x210>
   4461e:	xchg   %ax,%ax
   44620:	movzbl 0x1(%rsi),%edx
   44624:	mov    %r14d,%eax
   44627:	and    $0x1f,%eax
   4462a:	and    $0x3f,%edx
   4462d:	cmp    $0xdf,%r14b
   44631:	jbe    44670 <hotaru_core::screen::State::print_utf8+0x1e0>
   44633:	movzbl 0x2(%rsi),%ecx
   44637:	shl    $0x6,%edx
   4463a:	and    $0x3f,%ecx
   4463d:	or     %edx,%ecx
   4463f:	cmp    $0xf0,%r14b
   44643:	jb     44683 <hotaru_core::screen::State::print_utf8+0x1f3>
   44645:	movzbl 0x3(%rsi),%r14d
   4464a:	and    $0x7,%eax
   4464d:	shl    $0x6,%ecx
   44650:	shl    $0x12,%eax
   44653:	and    $0x3f,%r14d
   44657:	or     %ecx,%r14d
   4465a:	or     %eax,%r14d
   4465d:	cmp    $0x110000,%r14d
   44664:	je     45a9f <hotaru_core::screen::State::print_utf8+0x160f>
   4466a:	add    $0x4,%rsi
   4466e:	jmp    44614 <hotaru_core::screen::State::print_utf8+0x184>
   44670:	shl    $0x6,%eax
   44673:	add    $0x2,%rsi
   44677:	or     %edx,%eax
   44679:	mov    %rsi,0x10(%rsp)
   4467e:	mov    %eax,%r14d
   44681:	jmp    446a0 <hotaru_core::screen::State::print_utf8+0x210>
   44683:	shl    $0xc,%eax
   44686:	add    $0x3,%rsi
   4468a:	or     %eax,%ecx
   4468c:	mov    %rsi,0x10(%rsp)
   44691:	mov    %ecx,%r14d
   44694:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   446a0:	mov    $0xffffffffffffffff,%rsi
   446a7:	mov    %r15,%rdi
   446aa:	call   47660 <hotaru_core::screen::State::scalar_metadata_writes>
   446af:	test   %al,%al
   446b1:	je     44800 <hotaru_core::screen::State::print_utf8+0x370>
   446b7:	cmpb   $0x0,0x6df(%r15)
   446bf:	mov    %r15,%rbx
   446c2:	mov    0xb0(%rsp),%rcx
   446ca:	cmovne 0x90(%rsp),%rbx
   446d3:	mov    (%rcx),%rax
   446d6:	mov    0x6(%rcx),%rcx
   446da:	cmpb   $0x0,0x12f(%rbx)
   446e1:	mov    %rcx,0x66(%rsp)
   446e6:	mov    %rax,0x60(%rsp)
   446eb:	jne    45520 <hotaru_core::screen::State::print_utf8+0x1090>
   446f1:	movzbl 0x6e6(%r15),%eax
   446f9:	movzbl 0xa01(%r15),%edx
   44701:	movzbl 0xa04(%r15),%ecx
   44709:	mov    0x118(%rbx),%r12
   44710:	mov    %al,0x58(%rsp)
   44714:	mov    %dl,0xf(%rsp)
   44718:	test   %r12,%r12
   4471b:	je     44728 <hotaru_core::screen::State::print_utf8+0x298>
   4471d:	lock incq (%r12)
   44722:	jle    45acf <hotaru_core::screen::State::print_utf8+0x163f>
   44728:	mov    0x98(%rbx),%r15
   4472f:	mov    %r12,0x78(%rsp)
   44734:	cmp    0x38(%rbx),%r15
   44738:	jae    45ad5 <hotaru_core::screen::State::print_utf8+0x1645>
   4473e:	add    0x30(%rbx),%r15
   44742:	mov    0x20(%rbx),%rax
   44746:	mov    %r12,0x30(%rsp)
   4474b:	mov    0x28(%rbx),%r12
   4474f:	mov    %cl,0x48(%rsp)
   44753:	mov    $0x0,%ecx
   44758:	mov    0x90(%rbx),%rbp
   4475f:	cmp    %rax,%r15
   44762:	cmovb  %rcx,%rax
   44766:	sub    %rax,%r15
   44769:	mov    (%r12,%r15,8),%rax
   4476d:	mov    (%rax),%rax
   44770:	mov    (%r12,%r15,8),%r13
   44774:	cmp    $0x1,%rax
   44778:	jne    45288 <hotaru_core::screen::State::print_utf8+0xdf8>
   4477e:	mov    %r13,%r12
   44781:	mov    %rbp,%r15
   44784:	cmp    $0x110001,%r14d
   4478b:	jne    4530d <hotaru_core::screen::State::print_utf8+0xe7d>
   44791:	mov    0x10(%rsp),%rsi
   44796:	cmp    0x38(%rsp),%rsi
   4479b:	je     45362 <hotaru_core::screen::State::print_utf8+0xed2>
   447a1:	movzbl (%rsi),%edi
   447a4:	test   %dil,%dil
   447a7:	js     455b3 <hotaru_core::screen::State::print_utf8+0x1123>
   447ad:	inc    %rsi
   447b0:	mov    %rsi,0x10(%rsp)
   447b5:	cmpb   $0x0,0x58(%rsp)
   447ba:	lea    0x8(%r12),%r14
   447bf:	mov    %rdi,0x20(%rsp)
   447c4:	jne    45338 <hotaru_core::screen::State::print_utf8+0xea8>
   447ca:	vzeroupper
   447cd:	call   43ab0 <hotaru_core::screen::char_width>
   447d2:	mov    %rax,%r13
   447d5:	test   %rax,%rax
   447d8:	je     454c4 <hotaru_core::screen::State::print_utf8+0x1034>
   447de:	mov    0xf0(%rbx),%rcx
   447e5:	mov    %r13,%rax
   447e8:	add    %r15,%rax
   447eb:	mov    %rcx,0x40(%rsp)
   447f0:	cmp    %rcx,%rax
   447f3:	jbe    45489 <hotaru_core::screen::State::print_utf8+0xff9>
   447f9:	jmp    454c4 <hotaru_core::screen::State::print_utf8+0x1034>
   447fe:	xchg   %ax,%ax
   44800:	mov    0xa8(%rsp),%rcx
   44808:	cmpb   $0x0,0x6df(%r15)
   44810:	vmovq  0x6ea(%r15),%xmm0
   44819:	mov    0x6ee(%r15),%eax
   44820:	movzbl 0x6e6(%r15),%edx
   44828:	movzwl 0x4(%rcx),%edi
   4482c:	mov    (%rcx),%esi
   4482e:	movzbl 0xa04(%r15),%ecx
   44836:	mov    %eax,0x9c(%rsp)
   4483d:	mov    %dl,0xf(%rsp)
   44841:	vmovdqa %xmm0,0x130(%rsp)
   4484a:	mov    %cl,0x30(%rsp)
   4484e:	movzbl 0xa01(%r15),%ecx
   44856:	mov    %di,0x74(%rsp)
   4485b:	mov    %esi,0x70(%rsp)
   4485f:	mov    %cl,0x2f(%rsp)
   44863:	mov    %r15,%rcx
   44866:	cmovne 0x90(%rsp),%rcx
   4486f:	mov    0x90(%rcx),%r15
   44876:	mov    0x118(%rcx),%r12
   4487d:	test   %r12,%r12
   44880:	je     4488d <hotaru_core::screen::State::print_utf8+0x3fd>
   44882:	lock incq (%r12)
   44887:	jle    45acf <hotaru_core::screen::State::print_utf8+0x163f>
   4488d:	mov    0x98(%rcx),%rbx
   44894:	mov    %r12,0x60(%rsp)
   44899:	cmp    0x38(%rcx),%rbx
   4489d:	jae    45ab1 <hotaru_core::screen::State::print_utf8+0x1621>
   448a3:	add    0x30(%rcx),%rbx
   448a7:	mov    0x20(%rcx),%rdx
   448ab:	mov    %r12,0x18(%rsp)
   448b0:	movzbl 0x12f(%rcx),%eax
   448b7:	mov    0x28(%rcx),%r12
   448bb:	mov    %rcx,0x58(%rsp)
   448c0:	mov    $0x0,%ecx
   448c5:	cmp    %rdx,%rbx
   448c8:	mov    %eax,0x8(%rsp)
   448cc:	cmovae %rdx,%rcx
   448d0:	sub    %rcx,%rbx
   448d3:	mov    (%r12,%rbx,8),%rax
   448d7:	mov    (%rax),%rax
   448da:	mov    (%r12,%rbx,8),%r13
   448de:	cmp    $0x1,%rax
   448e2:	je     4495c <hotaru_core::screen::State::print_utf8+0x4cc>
   448e4:	lea    0x8(%r13),%rsi
   448e8:	lea    0xc0(%rsp),%rdi
   448f0:	call   *0x5e942(%rip)        # a3238 <_DYNAMIC+0x5d8>
   448f6:	mov    $0x78,%edi
   448fb:	movq   $0x1,0xb8(%rsp)
   44907:	call   *0x5e53b(%rip)        # a2e48 <malloc@GLIBC_2.2.5>
   4490d:	test   %rax,%rax
   44910:	je     45af3 <hotaru_core::screen::State::print_utf8+0x1663>
   44916:	vmovups 0xf0(%rsp),%zmm1
   44921:	vmovdqu64 0xb8(%rsp),%zmm0
   4492c:	lea    (%r12,%rbx,8),%rbx
   44930:	mov    %rax,%r12
   44933:	vmovups %zmm1,0x38(%rax)
   4493d:	vmovdqu64 %zmm0,(%rax)
   44943:	lock decq 0x0(%r13)
   44948:	jne    44956 <hotaru_core::screen::State::print_utf8+0x4c6>
   4494a:	mov    %rbx,%rdi
   4494d:	vzeroupper
   44950:	call   *0x5e8ea(%rip)        # a3240 <_DYNAMIC+0x5e0>
   44956:	mov    %r12,%r13
   44959:	mov    %r12,(%rbx)
   4495c:	lea    0x8(%r13),%rax
   44960:	mov    $0x110000,%r12d
   44966:	mov    %r13,0x20(%rsp)
   4496b:	xor    %r13d,%r13d
   4496e:	mov    %rax,0x48(%rsp)
   44973:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   44980:	cmp    $0x110001,%r14d
   44987:	jne    44a00 <hotaru_core::screen::State::print_utf8+0x570>
   44989:	mov    0x10(%rsp),%rsi
   4498e:	cmp    0x38(%rsp),%rsi
   44993:	je     451f4 <hotaru_core::screen::State::print_utf8+0xd64>
   44999:	movzbl (%rsi),%r14d
   4499d:	test   %r14b,%r14b
   449a0:	js     449ac <hotaru_core::screen::State::print_utf8+0x51c>
   449a2:	inc    %rsi
   449a5:	mov    %rsi,0x10(%rsp)
   449aa:	jmp    44a0d <hotaru_core::screen::State::print_utf8+0x57d>
   449ac:	movzbl 0x1(%rsi),%edx
   449b0:	mov    %r14d,%eax
   449b3:	and    $0x1f,%eax
   449b6:	and    $0x3f,%edx
   449b9:	cmp    $0xdf,%r14b
   449bd:	jbe    451ba <hotaru_core::screen::State::print_utf8+0xd2a>
   449c3:	movzbl 0x2(%rsi),%ecx
   449c7:	shl    $0x6,%edx
   449ca:	and    $0x3f,%ecx
   449cd:	or     %edx,%ecx
   449cf:	cmp    $0xf0,%r14b
   449d3:	jb     451d0 <hotaru_core::screen::State::print_utf8+0xd40>
   449d9:	movzbl 0x3(%rsi),%r14d
   449de:	and    $0x7,%eax
   449e1:	shl    $0x6,%ecx
   449e4:	add    $0x4,%rsi
   449e8:	shl    $0x12,%eax
   449eb:	mov    %rsi,0x10(%rsp)
   449f0:	and    $0x3f,%r14d
   449f4:	or     %ecx,%r14d
   449f7:	or     %eax,%r14d
   449fa:	nopw   0x0(%rax,%rax,1)
   44a00:	cmp    $0x110000,%r14d
   44a07:	je     451f4 <hotaru_core::screen::State::print_utf8+0xd64>
   44a0d:	cmpb   $0x0,0xf(%rsp)
   44a12:	mov    %r15,0x40(%rsp)
   44a17:	je     44a40 <hotaru_core::screen::State::print_utf8+0x5b0>
   44a19:	cmp    $0x100,%r14d
   44a20:	jae    44a90 <hotaru_core::screen::State::print_utf8+0x600>
   44a22:	lea    -0xa0(%r14),%eax
   44a29:	xor    %ebp,%ebp
   44a2b:	cmp    $0xffffffe0,%eax
   44a2e:	setb   %bpl
   44a32:	jmp    44b11 <hotaru_core::screen::State::print_utf8+0x681>
   44a37:	nopw   0x0(%rax,%rax,1)
   44a40:	mov    %r14d,%edi
   44a43:	vzeroupper
   44a46:	call   43ab0 <hotaru_core::screen::char_width>
   44a4b:	mov    %rax,%rbp
   44a4e:	test   %rax,%rax
   44a51:	je     453c0 <hotaru_core::screen::State::print_utf8+0xf30>
   44a57:	testb  $0x1,0x8(%rsp)
   44a5c:	mov    0x40(%rsp),%r15
   44a61:	jne    451fa <hotaru_core::screen::State::print_utf8+0xd6a>
   44a67:	mov    0x58(%rsp),%rcx
   44a6c:	mov    %rbp,%rax
   44a6f:	add    %r15,%rax
   44a72:	cmp    0xf0(%rcx),%rax
   44a79:	jbe    44b61 <hotaru_core::screen::State::print_utf8+0x6d1>
   44a7f:	jmp    451f0 <hotaru_core::screen::State::print_utf8+0xd60>
   44a84:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   44a90:	lea    -0x3400(%r14),%eax
   44a97:	lea    -0x4e00(%r14),%ecx
   44a9e:	mov    $0x2,%ebp
   44aa3:	cmp    $0x19c0,%eax
   44aa8:	setb   %al
   44aab:	cmp    $0x5200,%ecx
   44ab1:	setb   %cl
   44ab4:	or     %al,%cl
   44ab6:	lea    -0xf900(%r14),%eax
   44abd:	cmp    $0x200,%eax
   44ac2:	setb   %al
   44ac5:	or     %cl,%al
   44ac7:	jne    44b11 <hotaru_core::screen::State::print_utf8+0x681>
   44ac9:	mov    %r14d,%eax
   44acc:	shr    $0x8,%eax
   44acf:	lea    -0x37784(%rip),%rcx        # d352 <hotaru_core::unicode::tables::STAGE1>
   44ad6:	movzbl %r14b,%edi
   44ada:	movzwl (%rcx,%rax,2),%eax
   44ade:	add    %rax,%rdi
   44ae1:	cmp    $0x7cff,%rdi
   44ae8:	ja     45b69 <hotaru_core::screen::State::print_utf8+0x16d9>
   44aee:	lea    -0x355a3(%rip),%rax        # f552 <hotaru_core::unicode::tables::STAGE2>
   44af5:	movzwl (%rax,%rdi,2),%edi
   44af9:	cmp    $0x1e,%rdi
   44afd:	ja     45b5b <hotaru_core::screen::State::print_utf8+0x16cb>
   44b03:	lea    -0x377f6(%rip),%rax        # d314 <hotaru_core::unicode::tables::PROPERTIES>
   44b0a:	movzwl (%rax,%rdi,2),%ebp
   44b0e:	and    $0x3,%ebp
   44b11:	test   %rbp,%rbp
   44b14:	je     451fa <hotaru_core::screen::State::print_utf8+0xd6a>
   44b1a:	testb  $0x1,0x8(%rsp)
   44b1f:	jne    451fa <hotaru_core::screen::State::print_utf8+0xd6a>
   44b25:	mov    0x58(%rsp),%rcx
   44b2a:	lea    0x0(%rbp,%r15,1),%rax
   44b2f:	cmp    0xf0(%rcx),%rax
   44b36:	ja     451f0 <hotaru_core::screen::State::print_utf8+0xd60>
   44b3c:	movzbl 0x2f(%rsp),%edx
   44b41:	mov    0x48(%rsp),%rdi
   44b46:	mov    %r15,%rsi
   44b49:	mov    %r14d,%ecx
   44b4c:	vzeroupper
   44b4f:	call   44200 <hotaru_core::screen::unicode_batch_boundary>
   44b54:	mov    0x40(%rsp),%r15
   44b59:	test   %al,%al
   44b5b:	je     451f0 <hotaru_core::screen::State::print_utf8+0xd60>
   44b61:	test   %r15,%r15
   44b64:	je     44b90 <hotaru_core::screen::State::print_utf8+0x700>
   44b66:	mov    0x20(%rsp),%rax
   44b6b:	mov    0x18(%rax),%rsi
   44b6f:	cmp    %rsi,%r15
   44b72:	jae    45b93 <hotaru_core::screen::State::print_utf8+0x1703>
   44b78:	mov    0x10(%rax),%rax
   44b7c:	cmpb   $0x0,0x6(%rax,%r15,8)
   44b82:	sete   %al
   44b85:	mov    %eax,0x54(%rsp)
   44b89:	jmp    44b98 <hotaru_core::screen::State::print_utf8+0x708>
   44b8b:	nopl   0x0(%rax,%rax,1)
   44b90:	movl   $0x0,0x54(%rsp)
   44b98:	vmovdqa 0x130(%rsp),%xmm0
   44ba1:	movzwl 0x74(%rsp),%eax
   44ba6:	lea    0xc0(%rsp),%rcx
   44bae:	vmovq  %xmm0,0xb8(%rsp)
   44bb7:	mov    %ax,0x4(%rcx)
   44bbb:	mov    0x70(%rsp),%eax
   44bbf:	mov    %eax,(%rcx)
   44bc1:	mov    0x48(%rsp),%rdi
   44bc6:	lea    0xb8(%rsp),%rsi
   44bce:	call   41e70 <hotaru_core::row::Row::style_id>
   44bd3:	mov    0x40(%rsp),%r15
   44bd8:	jmp    44c0a <hotaru_core::screen::State::print_utf8+0x77a>
   44bda:	nopw   0x0(%rax,%rax,1)
   44be0:	lea    -0xa0(%r14),%ecx
   44be7:	xor    %ebp,%ebp
   44be9:	cmp    $0xffffffe0,%ecx
   44bec:	setb   %bpl
   44bf0:	test   %rbp,%rbp
   44bf3:	je     45164 <hotaru_core::screen::State::print_utf8+0xcd4>
   44bf9:	lea    0x0(%rbp,%r15,1),%rdx
   44bfe:	mov    %r14d,%ecx
   44c01:	cmp    %rbx,%rdx
   44c04:	ja     45167 <hotaru_core::screen::State::print_utf8+0xcd7>
   44c0a:	mov    %r14d,%r12d
   44c0d:	cmp    $0x110001,%r14d
   44c14:	jne    44c50 <hotaru_core::screen::State::print_utf8+0x7c0>
   44c16:	mov    0x10(%rsp),%rdx
   44c1b:	mov    0x20(%rsp),%rdi
   44c20:	cmp    0x38(%rsp),%rdx
   44c25:	je     44c80 <hotaru_core::screen::State::print_utf8+0x7f0>
   44c27:	movzbl (%rdx),%ecx
   44c2a:	test   %cl,%cl
   44c2c:	js     44c61 <hotaru_core::screen::State::print_utf8+0x7d1>
   44c2e:	inc    %rdx
   44c31:	mov    %rdx,0x10(%rsp)
   44c36:	mov    0x18(%rdi),%rsi
   44c3a:	cmp    $0x2,%r15
   44c3e:	jb     44c8a <hotaru_core::screen::State::print_utf8+0x7fa>
   44c40:	xor    %ecx,%ecx
   44c42:	jmp    44cac <hotaru_core::screen::State::print_utf8+0x81c>
   44c44:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   44c50:	mov    0x20(%rsp),%rdi
   44c55:	mov    0x18(%rdi),%rsi
   44c59:	cmp    $0x2,%r15
   44c5d:	jb     44c8a <hotaru_core::screen::State::print_utf8+0x7fa>
   44c5f:	jmp    44c40 <hotaru_core::screen::State::print_utf8+0x7b0>
   44c61:	cmp    $0xe0,%cl
   44c64:	jb     45077 <hotaru_core::screen::State::print_utf8+0xbe7>
   44c6a:	mov    0x10(%rsp),%rdx
   44c6f:	cmp    $0xf0,%cl
   44c72:	sbb    $0xffffffffffffffff,%rdx
   44c76:	add    $0x3,%rdx
   44c7a:	mov    %rdx,0x10(%rsp)
   44c7f:	nop
   44c80:	mov    0x18(%rdi),%rsi
   44c84:	cmp    $0x2,%r15
   44c88:	jae    44c40 <hotaru_core::screen::State::print_utf8+0x7b0>
   44c8a:	cmp    %rsi,%r15
   44c8d:	jae    45b32 <hotaru_core::screen::State::print_utf8+0x16a2>
   44c93:	mov    0x10(%rdi),%rcx
   44c97:	movzbl 0x6(%rcx,%r15,8),%ecx
   44c9d:	cmp    $0x1,%rcx
   44ca1:	setne  %dl
   44ca4:	cmp    %rcx,%rbp
   44ca7:	setne  %cl
   44caa:	and    %dl,%cl
   44cac:	cmp    %rsi,%r15
   44caf:	jae    45b1d <hotaru_core::screen::State::print_utf8+0x168d>
   44cb5:	mov    0x10(%rdi),%rdx
   44cb9:	movzbl 0x30(%rsp),%esi
   44cbe:	mov    %r12d,(%rdx,%r15,8)
   44cc2:	mov    %ax,0x4(%rdx,%r15,8)
   44cc8:	mov    %bpl,0x6(%rdx,%r15,8)
   44ccd:	mov    %sil,0x7(%rdx,%r15,8)
   44cd2:	cmp    $0x2,%rbp
   44cd6:	jne    44d0c <hotaru_core::screen::State::print_utf8+0x87c>
   44cd8:	mov    0x18(%rdi),%rsi
   44cdc:	lea    0x1(%r15),%rdx
   44ce0:	cmp    %rsi,%rdx
   44ce3:	jae    45b26 <hotaru_core::screen::State::print_utf8+0x1696>
   44ce9:	mov    0x10(%rdi),%rdx
   44ced:	movzbl 0x30(%rsp),%esi
   44cf2:	movl   $0x20,0x8(%rdx,%r15,8)
   44cfb:	mov    %ax,0xc(%rdx,%r15,8)
   44d01:	movb   $0x0,0xe(%rdx,%r15,8)
   44d07:	mov    %sil,0xf(%rdx,%r15,8)
   44d0c:	mov    0x58(%rsp),%rdx
   44d11:	or     %cl,%r13b
   44d14:	add    %rbp,%r15
   44d17:	mov    0xf0(%rdx),%rbx
   44d1e:	cmp    %rbx,%r15
   44d21:	je     45150 <hotaru_core::screen::State::print_utf8+0xcc0>
   44d27:	mov    0x10(%rsp),%r8
   44d2c:	mov    $0x110000,%ecx
   44d31:	cmp    0x38(%rsp),%r8
   44d36:	je     45167 <hotaru_core::screen::State::print_utf8+0xcd7>
   44d3c:	movzbl (%r8),%r14d
   44d40:	test   %r14b,%r14b
   44d43:	js     44e40 <hotaru_core::screen::State::print_utf8+0x9b0>
   44d49:	inc    %r8
   44d4c:	mov    %r8,0x10(%rsp)
   44d51:	cmpb   $0x0,0xf(%rsp)
   44d56:	jne    44ebb <hotaru_core::screen::State::print_utf8+0xa2b>
   44d5c:	cmp    $0x100,%r14d
   44d63:	jb     44be0 <hotaru_core::screen::State::print_utf8+0x750>
   44d69:	vpbroadcastd %r14d,%xmm0
   44d6f:	vpaddd -0x3c037(%rip),%xmm0,%xmm0        # 8d40 <anon.58baeeae7d5fe476157d296c9f08f803.346.llvm.5844774155465566772+0x1d0>
   44d77:	mov    $0x2,%ebp
   44d7c:	vpcmpltud -0x3c227(%rip),%xmm0,%k0        # 8b60 <anon.eb89d4395b0ead844ef0b45b8b54da85.151.llvm.3643936799275306673+0x1f2>
   44d87:	kortestb %k0,%k0
   44d8b:	jne    44bf9 <hotaru_core::screen::State::print_utf8+0x769>
   44d91:	mov    0x5e480(%rip),%rdx        # a3218 <_DYNAMIC+0x5b8>
   44d98:	mov    %r14d,%ecx
   44d9b:	shr    $0xd,%ecx
   44d9e:	movzbl (%rdx,%rcx,1),%ecx
   44da2:	mov    $0x607,%edx
   44da7:	bextr  %edx,%r14d,%edx
   44dac:	shl    $0x6,%ecx
   44daf:	add    0x5e46a(%rip),%rcx        # a3220 <_DYNAMIC+0x5c0>
   44db6:	movzbl (%rdx,%rcx,1),%edi
   44dba:	cmp    $0xbb,%rdi
   44dc1:	ja     45b77 <hotaru_core::screen::State::print_utf8+0x16e7>
   44dc7:	shl    $0x5,%edi
   44dca:	add    0x5e457(%rip),%rdi        # a3228 <_DYNAMIC+0x5c8>
   44dd1:	mov    $0x502,%edx
   44dd6:	mov    %r14d,%ecx
   44dd9:	bextr  %edx,%ecx,%ecx
   44dde:	movzbl (%rcx,%rdi,1),%edx
   44de2:	lea    (%r14,%r14,1),%ecx
   44de6:	and    $0x6,%cl
   44de9:	shr    %cl,%dl
   44deb:	and    $0x3,%dl
   44dee:	cmp    $0x3,%dl
   44df1:	jne    4512e <hotaru_core::screen::State::print_utf8+0xc9e>
   44df7:	mov    $0x1,%dl
   44df9:	cmp    $0xfe00,%r14d
   44e00:	jg     450b1 <hotaru_core::screen::State::print_utf8+0xc21>
   44e06:	cmp    $0x5dc,%r14d
   44e0d:	je     4512e <hotaru_core::screen::State::print_utf8+0xc9e>
   44e13:	cmp    $0x17d8,%r14d
   44e1a:	je     4511e <hotaru_core::screen::State::print_utf8+0xc8e>
   44e20:	cmp    $0x1a10,%r14d
   44e27:	je     4512e <hotaru_core::screen::State::print_utf8+0xc9e>
   44e2d:	jmp    450d2 <hotaru_core::screen::State::print_utf8+0xc42>
   44e32:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   44e40:	movzbl 0x1(%r8),%edi
   44e45:	mov    %r14d,%edx
   44e48:	and    $0x1f,%edx
   44e4b:	and    $0x3f,%edi
   44e4e:	cmp    $0xdf,%r14b
   44e52:	jbe    44e9a <hotaru_core::screen::State::print_utf8+0xa0a>
   44e54:	movzbl 0x2(%r8),%esi
   44e59:	shl    $0x6,%edi
   44e5c:	and    $0x3f,%esi
   44e5f:	or     %edi,%esi
   44e61:	cmp    $0xef,%r14b
   44e65:	jbe    45090 <hotaru_core::screen::State::print_utf8+0xc00>
   44e6b:	movzbl 0x3(%r8),%r14d
   44e70:	and    $0x7,%edx
   44e73:	shl    $0x6,%esi
   44e76:	add    $0x4,%r8
   44e7a:	shl    $0x12,%edx
   44e7d:	mov    %r8,0x10(%rsp)
   44e82:	and    $0x3f,%r14d
   44e86:	or     %esi,%r14d
   44e89:	or     %edx,%r14d
   44e8c:	cmp    $0x110000,%r14d
   44e93:	jne    44eb0 <hotaru_core::screen::State::print_utf8+0xa20>
   44e95:	jmp    45167 <hotaru_core::screen::State::print_utf8+0xcd7>
   44e9a:	shl    $0x6,%edx
   44e9d:	add    $0x2,%r8
   44ea1:	or     %edi,%edx
   44ea3:	mov    %r8,0x10(%rsp)
   44ea8:	mov    %edx,%r14d
   44eab:	nopl   0x0(%rax,%rax,1)
   44eb0:	cmpb   $0x0,0xf(%rsp)
   44eb5:	je     44d5c <hotaru_core::screen::State::print_utf8+0x8cc>
   44ebb:	cmp    $0x100,%r14d
   44ec2:	jb     44be0 <hotaru_core::screen::State::print_utf8+0x750>
   44ec8:	lea    -0x3400(%r12),%ecx
   44ed0:	lea    -0x4e00(%r12),%edx
   44ed8:	cmp    $0x19c0,%ecx
   44ede:	setb   %cl
   44ee1:	cmp    $0x5200,%edx
   44ee7:	setb   %dl
   44eea:	or     %cl,%dl
   44eec:	lea    -0xf900(%r12),%ecx
   44ef4:	cmp    $0x200,%ecx
   44efa:	setb   %cl
   44efd:	or     %dl,%cl
   44eff:	je     44f40 <hotaru_core::screen::State::print_utf8+0xab0>
   44f01:	lea    -0x3400(%r14),%ecx
   44f08:	lea    -0x4e00(%r14),%edx
   44f0f:	cmp    $0x19c0,%ecx
   44f15:	setb   %sil
   44f19:	cmp    $0x5200,%edx
   44f1f:	setb   %dil
   44f23:	or     %sil,%dil
   44f26:	lea    -0xf900(%r14),%esi
   44f2d:	cmp    $0x200,%esi
   44f33:	setb   %r8b
   44f37:	or     %dil,%r8b
   44f3a:	jne    45000 <hotaru_core::screen::State::print_utf8+0xb70>
   44f40:	mov    %r12d,%ecx
   44f43:	shr    $0x8,%ecx
   44f46:	lea    -0x37bfb(%rip),%rdx        # d352 <hotaru_core::unicode::tables::STAGE1>
   44f4d:	movzbl %r12b,%edi
   44f51:	mov    $0x7d00,%esi
   44f56:	movzwl (%rdx,%rcx,2),%ecx
   44f5a:	add    %rcx,%rdi
   44f5d:	cmp    $0x7cff,%rdi
   44f64:	ja     45b4f <hotaru_core::screen::State::print_utf8+0x16bf>
   44f6a:	lea    -0x35a1f(%rip),%rcx        # f552 <hotaru_core::unicode::tables::STAGE2>
   44f71:	movzwl (%rcx,%rdi,2),%edi
   44f75:	cmp    $0x1e,%rdi
   44f79:	ja     45b5b <hotaru_core::screen::State::print_utf8+0x16cb>
   44f7f:	mov    %r14d,%ecx
   44f82:	shr    $0x8,%ecx
   44f85:	lea    -0x37c3a(%rip),%rdx        # d352 <hotaru_core::unicode::tables::STAGE1>
   44f8c:	movzwl (%rdx,%rcx,2),%edx
   44f90:	movzbl %r14b,%ecx
   44f94:	add    %rdx,%rcx
   44f97:	cmp    $0x7cff,%rcx
   44f9e:	ja     45b4c <hotaru_core::screen::State::print_utf8+0x16bc>
   44fa4:	lea    -0x35a59(%rip),%rdx        # f552 <hotaru_core::unicode::tables::STAGE2>
   44fab:	movzwl (%rdx,%rcx,2),%ecx
   44faf:	cmp    $0x1f,%rcx
   44fb3:	jae    45b58 <hotaru_core::screen::State::print_utf8+0x16c8>
   44fb9:	lea    -0x37cac(%rip),%rsi        # d314 <hotaru_core::unicode::tables::PROPERTIES>
   44fc0:	movzwl (%rsi,%rcx,2),%ecx
   44fc4:	movzwl (%rsi,%rdi,2),%edx
   44fc8:	lea    -0x39ec7(%rip),%rsi        # b108 <hotaru_core::unicode::BREAKS>
   44fcf:	shl    $0x5,%ecx
   44fd2:	and    $0xf8,%edx
   44fd8:	and    $0x1f00,%ecx
   44fde:	or     %rcx,%rdx
   44fe1:	testb  $0x1,(%rsi,%rdx,1)
   44fe5:	je     45164 <hotaru_core::screen::State::print_utf8+0xcd4>
   44feb:	lea    -0x3400(%r14),%ecx
   44ff2:	lea    -0x4e00(%r14),%edx
   44ff9:	lea    -0xf900(%r14),%esi
   45000:	cmp    $0x19c0,%ecx
   45006:	mov    $0x2,%ebp
   4500b:	setb   %cl
   4500e:	cmp    $0x5200,%edx
   45014:	setb   %dl
   45017:	or     %cl,%dl
   45019:	cmp    $0x200,%esi
   4501f:	setb   %cl
   45022:	or     %dl,%cl
   45024:	jne    44bf9 <hotaru_core::screen::State::print_utf8+0x769>
   4502a:	mov    %r14d,%ecx
   4502d:	shr    $0x8,%ecx
   45030:	lea    -0x37ce5(%rip),%rdx        # d352 <hotaru_core::unicode::tables::STAGE1>
   45037:	movzbl %r14b,%edi
   4503b:	movzwl (%rdx,%rcx,2),%ecx
   4503f:	add    %rcx,%rdi
   45042:	cmp    $0x7cff,%rdi
   45049:	ja     45b69 <hotaru_core::screen::State::print_utf8+0x16d9>
   4504f:	lea    -0x35b04(%rip),%rcx        # f552 <hotaru_core::unicode::tables::STAGE2>
   45056:	movzwl (%rcx,%rdi,2),%edi
   4505a:	cmp    $0x1f,%rdi
   4505e:	jae    45b5b <hotaru_core::screen::State::print_utf8+0x16cb>
   45064:	lea    -0x37d57(%rip),%rcx        # d314 <hotaru_core::unicode::tables::PROPERTIES>
   4506b:	movzwl (%rcx,%rdi,2),%ebp
   4506f:	and    $0x3,%ebp
   45072:	jmp    44bf0 <hotaru_core::screen::State::print_utf8+0x760>
   45077:	addq   $0x2,0x10(%rsp)
   4507d:	mov    0x18(%rdi),%rsi
   45081:	cmp    $0x2,%r15
   45085:	jb     44c8a <hotaru_core::screen::State::print_utf8+0x7fa>
   4508b:	jmp    44c40 <hotaru_core::screen::State::print_utf8+0x7b0>
   45090:	shl    $0xc,%edx
   45093:	add    $0x3,%r8
   45097:	or     %edx,%esi
   45099:	mov    %r8,0x10(%rsp)
   4509e:	mov    %esi,%r14d
   450a1:	cmpb   $0x0,0xf(%rsp)
   450a6:	jne    44ebb <hotaru_core::screen::State::print_utf8+0xa2b>
   450ac:	jmp    44d5c <hotaru_core::screen::State::print_utf8+0x8cc>
   450b1:	lea    -0xfe01(%r14),%ecx
   450b8:	cmp    $0xe,%ecx
   450bb:	jbe    45122 <hotaru_core::screen::State::print_utf8+0xc92>
   450bd:	lea    -0x16d67(%r14),%ecx
   450c4:	cmp    $0x2,%ecx
   450c7:	jb     4512e <hotaru_core::screen::State::print_utf8+0xc9e>
   450c9:	cmp    $0x10c03,%r14d
   450d0:	je     4512e <hotaru_core::screen::State::print_utf8+0xc9e>
   450d2:	lea    -0x622(%r14),%ecx
   450d9:	lea    -0x1780(%r14),%edx
   450e0:	mov    %r14d,%esi
   450e3:	cmp    $0x261,%ecx
   450e9:	setb   %cl
   450ec:	cmp    $0x30,%edx
   450ef:	setb   %dl
   450f2:	or     %cl,%dl
   450f4:	lea    -0x2d31(%r14),%ecx
   450fb:	cmp    $0x3f,%ecx
   450fe:	setb   %cl
   45101:	and    $0x1ffffe,%esi
   45107:	cmp    $0xa4fc,%esi
   4510d:	sete   %sil
   45111:	or     %cl,%sil
   45114:	or     %dl,%sil
   45117:	mov    $0x2,%dl
   45119:	sub    %sil,%dl
   4511c:	jmp    4512e <hotaru_core::screen::State::print_utf8+0xc9e>
   4511e:	mov    $0x3,%dl
   45120:	jmp    4512e <hotaru_core::screen::State::print_utf8+0xc9e>
   45122:	mov    $0x6001,%esi
   45127:	bt     %ecx,%esi
   4512a:	jae    450bd <hotaru_core::screen::State::print_utf8+0xc2d>
   4512c:	xor    %edx,%edx
   4512e:	movzbl %dl,%ecx
   45131:	mov    $0x2,%edx
   45136:	cmp    $0x2,%cl
   45139:	cmovae %edx,%ecx
   4513c:	movzbl %cl,%ebp
   4513f:	jmp    44bf0 <hotaru_core::screen::State::print_utf8+0x760>
   45144:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   45150:	mov    %r15,%rbx
   45153:	mov    $0x1,%al
   45155:	dec    %r15
   45158:	mov    $0x110001,%r14d
   4515e:	mov    %eax,0x8(%rsp)
   45162:	jmp    45173 <hotaru_core::screen::State::print_utf8+0xce3>
   45164:	mov    %r14d,%ecx
   45167:	testb  $0x1,0x8(%rsp)
   4516c:	mov    %ecx,%r14d
   4516f:	cmove  %r15,%rbx
   45173:	movzbl 0x54(%rsp),%ecx
   45178:	mov    0x48(%rsp),%rdi
   4517d:	mov    0x40(%rsp),%rsi
   45182:	mov    0x9c(%rsp),%r8d
   4518a:	mov    %rbx,%rdx
   4518d:	call   40b10 <hotaru_core::row::Row::prepare_write_with_left>
   45192:	cmpq   $0x0,0x18(%rsp)
   45198:	je     44980 <hotaru_core::screen::State::print_utf8+0x4f0>
   4519e:	mov    0x48(%rsp),%rdi
   451a3:	mov    0x40(%rsp),%rsi
   451a8:	lea    0x60(%rsp),%rcx
   451ad:	mov    %rbx,%rdx
   451b0:	call   407f0 <hotaru_core::row::Row::set_hyperlink_range>
   451b5:	jmp    44980 <hotaru_core::screen::State::print_utf8+0x4f0>
   451ba:	shl    $0x6,%eax
   451bd:	add    $0x2,%rsi
   451c1:	or     %edx,%eax
   451c3:	mov    %rsi,0x10(%rsp)
   451c8:	mov    %eax,%r14d
   451cb:	jmp    44a0d <hotaru_core::screen::State::print_utf8+0x57d>
   451d0:	shl    $0xc,%eax
   451d3:	add    $0x3,%rsi
   451d7:	or     %eax,%ecx
   451d9:	mov    %rsi,0x10(%rsp)
   451de:	mov    %ecx,%r14d
   451e1:	jmp    44a0d <hotaru_core::screen::State::print_utf8+0x57d>
   451e6:	cs nopw 0x0(%rax,%rax,1)
   451f0:	xor    %eax,%eax
   451f2:	jmp    451fe <hotaru_core::screen::State::print_utf8+0xd6e>
   451f4:	mov    $0x110000,%r14d
   451fa:	mov    0x8(%rsp),%eax
   451fe:	mov    0x58(%rsp),%rbx
   45203:	mov    %r15,0x90(%rbx)
   4520a:	mov    %al,0x12f(%rbx)
   45210:	test   $0x1,%r13b
   45214:	je     45221 <hotaru_core::screen::State::print_utf8+0xd91>
   45216:	mov    %rbx,%rdi
   45219:	vzeroupper
   4521c:	call   492d0 <hotaru_core::screen::Screen::clear_previous_spacer>
   45221:	mov    %rbx,%rdi
   45224:	vzeroupper
   45227:	call   491b0 <hotaru_core::screen::Screen::enforce_budget>
   4522c:	mov    0x88(%rsp),%rdi
   45234:	cmp    $0x110000,%r12d
   4523b:	je     45244 <hotaru_core::screen::State::print_utf8+0xdb4>
   4523d:	mov    %r12d,0x6d0(%rdi)
   45244:	cmp    $0x110000,%r14d
   4524b:	je     45a19 <hotaru_core::screen::State::print_utf8+0x1589>
   45251:	cmp    $0x110001,%r14d
   45258:	jne    45a10 <hotaru_core::screen::State::print_utf8+0x1580>
   4525e:	mov    0x10(%rsp),%rsi
   45263:	cmp    0x38(%rsp),%rsi
   45268:	je     45a19 <hotaru_core::screen::State::print_utf8+0x1589>
   4526e:	movzbl (%rsi),%r14d
   45272:	test   %r14b,%r14b
   45275:	js     4536d <hotaru_core::screen::State::print_utf8+0xedd>
   4527b:	inc    %rsi
   4527e:	mov    %rsi,0x10(%rsp)
   45283:	jmp    45a10 <hotaru_core::screen::State::print_utf8+0x1580>
   45288:	lea    0x8(%r13),%rsi
   4528c:	lea    0xc0(%rsp),%rdi
   45294:	call   *0x5df9e(%rip)        # a3238 <_DYNAMIC+0x5d8>
   4529a:	mov    $0x78,%edi
   4529f:	movq   $0x1,0xb8(%rsp)
   452ab:	call   *0x5db97(%rip)        # a2e48 <malloc@GLIBC_2.2.5>
   452b1:	test   %rax,%rax
   452b4:	je     45b08 <hotaru_core::screen::State::print_utf8+0x1678>
   452ba:	vmovups 0xf0(%rsp),%zmm1
   452c5:	vmovdqu64 0xb8(%rsp),%zmm0
   452d0:	lea    (%r12,%r15,8),%r15
   452d4:	mov    %rax,%r12
   452d7:	vmovups %zmm1,0x38(%rax)
   452e1:	vmovdqu64 %zmm0,(%rax)
   452e7:	lock decq 0x0(%r13)
   452ec:	jne    452fa <hotaru_core::screen::State::print_utf8+0xe6a>
   452ee:	mov    %r15,%rdi
   452f1:	vzeroupper
   452f4:	call   *0x5df46(%rip)        # a3240 <_DYNAMIC+0x5e0>
   452fa:	mov    %r12,(%r15)
   452fd:	mov    %rbp,%r15
   45300:	cmp    $0x110001,%r14d
   45307:	je     44791 <hotaru_core::screen::State::print_utf8+0x301>
   4530d:	mov    %r14d,%edi
   45310:	cmp    $0x110000,%r14d
   45317:	mov    $0x110000,%r14d
   4531d:	je     454c9 <hotaru_core::screen::State::print_utf8+0x1039>
   45323:	cmpb   $0x0,0x58(%rsp)
   45328:	lea    0x8(%r12),%r14
   4532d:	mov    %rdi,0x20(%rsp)
   45332:	je     447ca <hotaru_core::screen::State::print_utf8+0x33a>
   45338:	cmp    $0x100,%edi
   4533e:	jae    453ce <hotaru_core::screen::State::print_utf8+0xf3e>
   45344:	lea    -0xa0(%rdi),%eax
   4534a:	xor    %r13d,%r13d
   4534d:	cmp    $0xffffffe0,%eax
   45350:	setb   %r13b
   45354:	test   %r13,%r13
   45357:	jne    45457 <hotaru_core::screen::State::print_utf8+0xfc7>
   4535d:	jmp    454c4 <hotaru_core::screen::State::print_utf8+0x1034>
   45362:	mov    $0x110000,%r14d
   45368:	jmp    454c9 <hotaru_core::screen::State::print_utf8+0x1039>
   4536d:	movzbl 0x1(%rsi),%edx
   45371:	mov    %r14d,%eax
   45374:	and    $0x1f,%eax
   45377:	and    $0x3f,%edx
   4537a:	cmp    $0xdf,%r14b
   4537e:	jbe    45631 <hotaru_core::screen::State::print_utf8+0x11a1>
   45384:	movzbl 0x2(%rsi),%ecx
   45388:	shl    $0x6,%edx
   4538b:	and    $0x3f,%ecx
   4538e:	or     %edx,%ecx
   45390:	cmp    $0xf0,%r14b
   45394:	jb     459fa <hotaru_core::screen::State::print_utf8+0x156a>
   4539a:	movzbl 0x3(%rsi),%r14d
   4539f:	and    $0x7,%eax
   453a2:	shl    $0x6,%ecx
   453a5:	add    $0x4,%rsi
   453a9:	shl    $0x12,%eax
   453ac:	mov    %rsi,0x10(%rsp)
   453b1:	and    $0x3f,%r14d
   453b5:	or     %ecx,%r14d
   453b8:	or     %eax,%r14d
   453bb:	jmp    45a10 <hotaru_core::screen::State::print_utf8+0x1580>
   453c0:	mov    0x8(%rsp),%eax
   453c4:	mov    0x40(%rsp),%r15
   453c9:	jmp    451fe <hotaru_core::screen::State::print_utf8+0xd6e>
   453ce:	lea    -0x3400(%rdi),%eax
   453d4:	lea    -0x4e00(%rdi),%ecx
   453da:	mov    $0x2,%r13d
   453e0:	cmp    $0x19c0,%eax
   453e5:	setb   %al
   453e8:	cmp    $0x5200,%ecx
   453ee:	setb   %cl
   453f1:	or     %al,%cl
   453f3:	lea    -0xf900(%rdi),%eax
   453f9:	cmp    $0x200,%eax
   453fe:	setb   %al
   45401:	or     %cl,%al
   45403:	jne    45457 <hotaru_core::screen::State::print_utf8+0xfc7>
   45405:	mov    0x20(%rsp),%rdx
   4540a:	lea    -0x380bf(%rip),%rcx        # d352 <hotaru_core::unicode::tables::STAGE1>
   45411:	mov    %edx,%eax
   45413:	shr    $0x8,%eax
   45416:	movzbl %dl,%edi
   45419:	movzwl (%rcx,%rax,2),%eax
   4541d:	add    %rax,%rdi
   45420:	cmp    $0x7cff,%rdi
   45427:	ja     45bc8 <hotaru_core::screen::State::print_utf8+0x1738>
   4542d:	lea    -0x35ee2(%rip),%rax        # f552 <hotaru_core::unicode::tables::STAGE2>
   45434:	movzwl (%rax,%rdi,2),%edi
   45438:	cmp    $0x1e,%rdi
   4543c:	ja     45bcf <hotaru_core::screen::State::print_utf8+0x173f>
   45442:	lea    -0x38135(%rip),%rax        # d314 <hotaru_core::unicode::tables::PROPERTIES>
   45449:	movzwl (%rax,%rdi,2),%r13d
   4544e:	and    $0x3,%r13d
   45452:	test   %r13,%r13
   45455:	je     454c4 <hotaru_core::screen::State::print_utf8+0x1034>
   45457:	mov    0xf0(%rbx),%rcx
   4545e:	lea    0x0(%r13,%r15,1),%rax
   45463:	mov    %rcx,0x40(%rsp)
   45468:	cmp    %rcx,%rax
   4546b:	ja     454c4 <hotaru_core::screen::State::print_utf8+0x1034>
   4546d:	movzbl 0xf(%rsp),%edx
   45472:	mov    0x20(%rsp),%rcx
   45477:	mov    %r14,%rdi
   4547a:	mov    %r15,%rsi
   4547d:	vzeroupper
   45480:	call   44200 <hotaru_core::screen::unicode_batch_boundary>
   45485:	test   %al,%al
   45487:	je     454c4 <hotaru_core::screen::State::print_utf8+0x1034>
   45489:	cmp    $0x1,%r15
   4548d:	ja     45647 <hotaru_core::screen::State::print_utf8+0x11b7>
   45493:	mov    0x18(%r12),%rsi
   45498:	cmp    %rsi,%r15
   4549b:	jae    45bb1 <hotaru_core::screen::State::print_utf8+0x1721>
   454a1:	mov    0x10(%r12),%rax
   454a6:	movzbl 0x6(%rax,%r15,8),%eax
   454ac:	cmp    $0x1,%rax
   454b0:	setne  %cl
   454b3:	cmp    %eax,%r13d
   454b6:	setne  %al
   454b9:	and    %cl,%al
   454bb:	mov    %eax,0x8(%rsp)
   454bf:	jmp    4564f <hotaru_core::screen::State::print_utf8+0x11bf>
   454c4:	mov    0x20(%rsp),%r14
   454c9:	mov    %r15,0x90(%rbx)
   454d0:	mov    $0x110000,%r12d
   454d6:	mov    %rbx,%rdi
   454d9:	vzeroupper
   454dc:	call   491b0 <hotaru_core::screen::Screen::enforce_budget>
   454e1:	mov    0x88(%rsp),%r15
   454e9:	cmp    $0x110000,%r12d
   454f0:	je     454f9 <hotaru_core::screen::State::print_utf8+0x1069>
   454f2:	mov    %r12d,0x6d0(%r15)
   454f9:	mov    0x30(%rsp),%rax
   454fe:	test   %rax,%rax
   45501:	je     45520 <hotaru_core::screen::State::print_utf8+0x1090>
   45503:	lock decq (%rax)
   45507:	jne    45520 <hotaru_core::screen::State::print_utf8+0x1090>
   45509:	lea    0x78(%rsp),%rdi
   4550e:	call   *0x5dcdc(%rip)        # a31f0 <_DYNAMIC+0x590>
   45514:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   45520:	cmp    $0x110000,%r14d
   45527:	je     445f8 <hotaru_core::screen::State::print_utf8+0x168>
   4552d:	cmp    $0x110001,%r14d
   45534:	jne    459d0 <hotaru_core::screen::State::print_utf8+0x1540>
   4553a:	mov    0x10(%rsp),%rsi
   4553f:	cmp    0x38(%rsp),%rsi
   45544:	je     445f8 <hotaru_core::screen::State::print_utf8+0x168>
   4554a:	movzbl (%rsi),%r14d
   4554e:	test   %r14b,%r14b
   45551:	js     45560 <hotaru_core::screen::State::print_utf8+0x10d0>
   45553:	inc    %rsi
   45556:	mov    %rsi,0x10(%rsp)
   4555b:	jmp    459d0 <hotaru_core::screen::State::print_utf8+0x1540>
   45560:	movzbl 0x1(%rsi),%edx
   45564:	mov    %r14d,%eax
   45567:	and    $0x1f,%eax
   4556a:	and    $0x3f,%edx
   4556d:	cmp    $0xdf,%r14b
   45571:	jbe    4561b <hotaru_core::screen::State::print_utf8+0x118b>
   45577:	movzbl 0x2(%rsi),%ecx
   4557b:	shl    $0x6,%edx
   4557e:	and    $0x3f,%ecx
   45581:	or     %edx,%ecx
   45583:	cmp    $0xf0,%r14b
   45587:	jb     459b7 <hotaru_core::screen::State::print_utf8+0x1527>
   4558d:	movzbl 0x3(%rsi),%r14d
   45592:	and    $0x7,%eax
   45595:	shl    $0x6,%ecx
   45598:	add    $0x4,%rsi
   4559c:	shl    $0x12,%eax
   4559f:	mov    %rsi,0x10(%rsp)
   455a4:	and    $0x3f,%r14d
   455a8:	or     %ecx,%r14d
   455ab:	or     %eax,%r14d
   455ae:	jmp    459d0 <hotaru_core::screen::State::print_utf8+0x1540>
   455b3:	movzbl 0x1(%rsi),%edx
   455b7:	mov    %edi,%eax
   455b9:	and    $0x1f,%eax
   455bc:	and    $0x3f,%edx
   455bf:	cmp    $0xe0,%dil
   455c3:	jb     4598d <hotaru_core::screen::State::print_utf8+0x14fd>
   455c9:	movzbl 0x2(%rsi),%ecx
   455cd:	shl    $0x6,%edx
   455d0:	and    $0x3f,%ecx
   455d3:	or     %edx,%ecx
   455d5:	cmp    $0xf0,%dil
   455d9:	jb     45a41 <hotaru_core::screen::State::print_utf8+0x15b1>
   455df:	movzbl 0x3(%rsi),%r14d
   455e4:	and    $0x7,%eax
   455e7:	shl    $0x6,%ecx
   455ea:	add    $0x4,%rsi
   455ee:	shl    $0x12,%eax
   455f1:	mov    %rsi,0x10(%rsp)
   455f6:	and    $0x3f,%r14d
   455fa:	or     %ecx,%r14d
   455fd:	or     %eax,%r14d
   45600:	mov    %r14d,%edi
   45603:	cmp    $0x110000,%r14d
   4560a:	mov    $0x110000,%r14d
   45610:	jne    45323 <hotaru_core::screen::State::print_utf8+0xe93>
   45616:	jmp    454c9 <hotaru_core::screen::State::print_utf8+0x1039>
   4561b:	shl    $0x6,%eax
   4561e:	add    $0x2,%rsi
   45622:	or     %edx,%eax
   45624:	mov    %rsi,0x10(%rsp)
   45629:	mov    %eax,%r14d
   4562c:	jmp    459d0 <hotaru_core::screen::State::print_utf8+0x1540>
   45631:	shl    $0x6,%eax
   45634:	add    $0x2,%rsi
   45638:	or     %edx,%eax
   4563a:	mov    %rsi,0x10(%rsp)
   4563f:	mov    %eax,%r14d
   45642:	jmp    45a10 <hotaru_core::screen::State::print_utf8+0x1580>
   45647:	movl   $0x0,0x8(%rsp)
   4564f:	mov    0x60(%rsp),%rax
   45654:	mov    0x66(%rsp),%rcx
   45659:	mov    %rcx,0xbe(%rsp)
   45661:	mov    %rax,0xb8(%rsp)
   45669:	movzbl 0x48(%rsp),%r9d
   4566f:	lea    0xb8(%rsp),%r8
   45677:	mov    0x20(%rsp),%rdx
   4567c:	mov    %r14,%rdi
   4567f:	mov    %r15,%rsi
   45682:	mov    %r13,%rcx
   45685:	mov    %r9d,0x54(%rsp)
   4568a:	call   40f90 <hotaru_core::row::Row::put>
   4568f:	add    %r15,%r13
   45692:	cmpq   $0x0,0x30(%rsp)
   45698:	je     456ad <hotaru_core::screen::State::print_utf8+0x121d>
   4569a:	lea    0x78(%rsp),%rcx
   4569f:	mov    %r14,%rdi
   456a2:	mov    %r15,%rsi
   456a5:	mov    %r13,%rdx
   456a8:	call   407f0 <hotaru_core::row::Row::set_hyperlink_range>
   456ad:	cmp    0x40(%rsp),%r13
   456b2:	jne    456ee <hotaru_core::screen::State::print_utf8+0x125e>
   456b4:	mov    0x40(%rsp),%r13
   456b9:	mov    0x8(%rsp),%eax
   456bd:	movb   $0x1,0x12f(%rbx)
   456c4:	mov    $0x110001,%r14d
   456ca:	dec    %r13
   456cd:	mov    %r13,0x90(%rbx)
   456d4:	test   $0x1,%al
   456d6:	je     45a95 <hotaru_core::screen::State::print_utf8+0x1605>
   456dc:	mov    %rbx,%rdi
   456df:	call   492d0 <hotaru_core::screen::Screen::clear_previous_spacer>
   456e4:	mov    0x20(%rsp),%r12
   456e9:	jmp    454d6 <hotaru_core::screen::State::print_utf8+0x1046>
   456ee:	mov    0x10(%rsp),%rsi
   456f3:	mov    %r14,0x48(%rsp)
   456f8:	mov    $0x110000,%r14d
   456fe:	mov    %r12,0x18(%rsp)
   45703:	cmp    0x38(%rsp),%rsi
   45708:	je     45a82 <hotaru_core::screen::State::print_utf8+0x15f2>
   4570e:	xchg   %ax,%ax
   45710:	movzbl (%rsi),%ebp
   45713:	test   %bpl,%bpl
   45716:	js     45754 <hotaru_core::screen::State::print_utf8+0x12c4>
   45718:	inc    %rsi
   4571b:	mov    %rsi,0x10(%rsp)
   45720:	cmpb   $0x0,0x58(%rsp)
   45725:	jne    457cb <hotaru_core::screen::State::print_utf8+0x133b>
   4572b:	mov    %ebp,%edi
   4572d:	call   43ab0 <hotaru_core::screen::char_width>
   45732:	mov    %rax,%r15
   45735:	test   %rax,%rax
   45738:	je     45a6b <hotaru_core::screen::State::print_utf8+0x15db>
   4573e:	mov    %r15,%rax
   45741:	add    %r13,%rax
   45744:	cmp    0x40(%rsp),%rax
   45749:	jbe    458a5 <hotaru_core::screen::State::print_utf8+0x1415>
   4574f:	jmp    45a6b <hotaru_core::screen::State::print_utf8+0x15db>
   45754:	movzbl 0x1(%rsi),%edx
   45758:	mov    %ebp,%eax
   4575a:	and    $0x1f,%eax
   4575d:	and    $0x3f,%edx
   45760:	cmp    $0xdf,%bpl
   45764:	jbe    457a6 <hotaru_core::screen::State::print_utf8+0x1316>
   45766:	movzbl 0x2(%rsi),%ecx
   4576a:	shl    $0x6,%edx
   4576d:	and    $0x3f,%ecx
   45770:	or     %edx,%ecx
   45772:	cmp    $0xf0,%bpl
   45776:	jb     4596d <hotaru_core::screen::State::print_utf8+0x14dd>
   4577c:	movzbl 0x3(%rsi),%ebp
   45780:	and    $0x7,%eax
   45783:	shl    $0x6,%ecx
   45786:	add    $0x4,%rsi
   4578a:	shl    $0x12,%eax
   4578d:	mov    %rsi,0x10(%rsp)
   45792:	and    $0x3f,%ebp
   45795:	or     %ecx,%ebp
   45797:	or     %eax,%ebp
   45799:	cmp    $0x110000,%ebp
   4579f:	jne    457c0 <hotaru_core::screen::State::print_utf8+0x1330>
   457a1:	jmp    45a82 <hotaru_core::screen::State::print_utf8+0x15f2>
   457a6:	shl    $0x6,%eax
   457a9:	add    $0x2,%rsi
   457ad:	or     %edx,%eax
   457af:	mov    %rsi,0x10(%rsp)
   457b4:	mov    %eax,%ebp
   457b6:	cs nopw 0x0(%rax,%rax,1)
   457c0:	cmpb   $0x0,0x58(%rsp)
   457c5:	je     4572b <hotaru_core::screen::State::print_utf8+0x129b>
   457cb:	cmp    $0x100,%ebp
   457d1:	jae    457f1 <hotaru_core::screen::State::print_utf8+0x1361>
   457d3:	lea    -0xa0(%rbp),%eax
   457d9:	xor    %r15d,%r15d
   457dc:	cmp    $0xffffffe0,%eax
   457df:	setb   %r15b
   457e3:	test   %r15,%r15
   457e6:	jne    4587a <hotaru_core::screen::State::print_utf8+0x13ea>
   457ec:	jmp    45a6b <hotaru_core::screen::State::print_utf8+0x15db>
   457f1:	lea    -0x3400(%rbp),%eax
   457f7:	lea    -0x4e00(%rbp),%ecx
   457fd:	mov    $0x2,%r15d
   45803:	cmp    $0x19c0,%eax
   45808:	setb   %al
   4580b:	cmp    $0x5200,%ecx
   45811:	setb   %cl
   45814:	or     %al,%cl
   45816:	lea    -0xf900(%rbp),%eax
   4581c:	cmp    $0x200,%eax
   45821:	setb   %al
   45824:	or     %cl,%al
   45826:	jne    4587a <hotaru_core::screen::State::print_utf8+0x13ea>
   45828:	mov    %ebp,%eax
   4582a:	shr    $0x8,%eax
   4582d:	lea    -0x384e2(%rip),%rcx        # d352 <hotaru_core::unicode::tables::STAGE1>
   45834:	movzbl %bpl,%edi
   45838:	movzwl (%rcx,%rax,2),%eax
   4583c:	add    %rax,%rdi
   4583f:	cmp    $0x7cff,%rdi
   45846:	ja     45bc8 <hotaru_core::screen::State::print_utf8+0x1738>
   4584c:	lea    -0x36301(%rip),%rax        # f552 <hotaru_core::unicode::tables::STAGE2>
   45853:	movzwl (%rax,%rdi,2),%edi
   45857:	cmp    $0x1f,%rdi
   4585b:	jae    45bcf <hotaru_core::screen::State::print_utf8+0x173f>
   45861:	lea    -0x38554(%rip),%rax        # d314 <hotaru_core::unicode::tables::PROPERTIES>
   45868:	movzwl (%rax,%rdi,2),%r15d
   4586d:	and    $0x3,%r15d
   45871:	test   %r15,%r15
   45874:	je     45a6b <hotaru_core::screen::State::print_utf8+0x15db>
   4587a:	lea    (%r15,%r13,1),%rax
   4587e:	cmp    0x40(%rsp),%rax
   45883:	ja     45a6b <hotaru_core::screen::State::print_utf8+0x15db>
   45889:	movzbl 0xf(%rsp),%edx
   4588e:	mov    0x48(%rsp),%rdi
   45893:	mov    %r13,%rsi
   45896:	mov    %ebp,%ecx
   45898:	call   44200 <hotaru_core::screen::unicode_batch_boundary>
   4589d:	test   %al,%al
   4589f:	je     45a6b <hotaru_core::screen::State::print_utf8+0x15db>
   458a5:	cmp    $0x1,%r13
   458a9:	ja     458da <hotaru_core::screen::State::print_utf8+0x144a>
   458ab:	mov    0x18(%rsp),%rax
   458b0:	mov    0x18(%rax),%rsi
   458b4:	cmp    %rsi,%r13
   458b7:	jae    45bae <hotaru_core::screen::State::print_utf8+0x171e>
   458bd:	mov    0x10(%rax),%rax
   458c1:	movzbl 0x6(%rax,%r13,8),%eax
   458c7:	cmp    $0x1,%rax
   458cb:	setne  %cl
   458ce:	cmp    %eax,%r15d
   458d1:	setne  %r12b
   458d5:	and    %cl,%r12b
   458d8:	jmp    458dd <hotaru_core::screen::State::print_utf8+0x144d>
   458da:	xor    %r12d,%r12d
   458dd:	mov    0x60(%rsp),%rax
   458e2:	mov    0x66(%rsp),%rcx
   458e7:	mov    %rcx,0xbe(%rsp)
   458ef:	mov    %rax,0xb8(%rsp)
   458f7:	mov    0x48(%rsp),%rdi
   458fc:	mov    0x54(%rsp),%r9d
   45901:	lea    0xb8(%rsp),%r8
   45909:	mov    %r13,%rsi
   4590c:	mov    %ebp,%edx
   4590e:	mov    %r15,%rcx
   45911:	call   40f90 <hotaru_core::row::Row::put>
   45916:	add    %r13,%r15
   45919:	cmpq   $0x0,0x30(%rsp)
   4591f:	je     45936 <hotaru_core::screen::State::print_utf8+0x14a6>
   45921:	mov    0x48(%rsp),%rdi
   45926:	lea    0x78(%rsp),%rcx
   4592b:	mov    %r13,%rsi
   4592e:	mov    %r15,%rdx
   45931:	call   407f0 <hotaru_core::row::Row::set_hyperlink_range>
   45936:	mov    0x8(%rsp),%eax
   4593a:	or     %r12b,%al
   4593d:	and    $0x1,%al
   4593f:	mov    %eax,0x8(%rsp)
   45943:	cmp    0x40(%rsp),%r15
   45948:	je     45a70 <hotaru_core::screen::State::print_utf8+0x15e0>
   4594e:	mov    0x10(%rsp),%rsi
   45953:	mov    %ebp,%eax
   45955:	mov    %r15,%r13
   45958:	mov    %rax,0x20(%rsp)
   4595d:	cmp    0x38(%rsp),%rsi
   45962:	jne    45710 <hotaru_core::screen::State::print_utf8+0x1280>
   45968:	jmp    45a7a <hotaru_core::screen::State::print_utf8+0x15ea>
   4596d:	shl    $0xc,%eax
   45970:	add    $0x3,%rsi
   45974:	or     %eax,%ecx
   45976:	mov    %rsi,0x10(%rsp)
   4597b:	mov    %ecx,%ebp
   4597d:	cmpb   $0x0,0x58(%rsp)
   45982:	jne    457cb <hotaru_core::screen::State::print_utf8+0x133b>
   45988:	jmp    4572b <hotaru_core::screen::State::print_utf8+0x129b>
   4598d:	shl    $0x6,%eax
   45990:	add    $0x2,%rsi
   45994:	or     %edx,%eax
   45996:	mov    %rsi,0x10(%rsp)
   4599b:	mov    %eax,%edi
   4599d:	cmpb   $0x0,0x58(%rsp)
   459a2:	lea    0x8(%r12),%r14
   459a7:	mov    %rdi,0x20(%rsp)
   459ac:	je     447ca <hotaru_core::screen::State::print_utf8+0x33a>
   459b2:	jmp    45338 <hotaru_core::screen::State::print_utf8+0xea8>
   459b7:	shl    $0xc,%eax
   459ba:	add    $0x3,%rsi
   459be:	or     %eax,%ecx
   459c0:	mov    %rsi,0x10(%rsp)
   459c5:	mov    %ecx,%r14d
   459c8:	nopl   0x0(%rax,%rax,1)
   459d0:	mov    %r15,%rdi
   459d3:	mov    %r14d,%esi
   459d6:	call   *0x5d854(%rip)        # a3230 <_DYNAMIC+0x5d0>
   459dc:	cmpb   $0x0,0x6df(%r15)
   459e4:	mov    %r15,%rdi
   459e7:	cmovne 0x90(%rsp),%rdi
   459f0:	call   491b0 <hotaru_core::screen::Screen::enforce_budget>
   459f5:	jmp    445f8 <hotaru_core::screen::State::print_utf8+0x168>
   459fa:	shl    $0xc,%eax
   459fd:	add    $0x3,%rsi
   45a01:	or     %eax,%ecx
   45a03:	mov    %rsi,0x10(%rsp)
   45a08:	mov    %ecx,%r14d
   45a0b:	nopl   0x0(%rax,%rax,1)
   45a10:	mov    %r14d,%esi
   45a13:	call   *0x5d817(%rip)        # a3230 <_DYNAMIC+0x5d0>
   45a19:	mov    0x18(%rsp),%rax
   45a1e:	test   %rax,%rax
   45a21:	je     445f0 <hotaru_core::screen::State::print_utf8+0x160>
   45a27:	lock decq (%rax)
   45a2b:	jne    445f0 <hotaru_core::screen::State::print_utf8+0x160>
   45a31:	lea    0x60(%rsp),%rdi
   45a36:	call   *0x5d7b4(%rip)        # a31f0 <_DYNAMIC+0x590>
   45a3c:	jmp    445f0 <hotaru_core::screen::State::print_utf8+0x160>
   45a41:	shl    $0xc,%eax
   45a44:	add    $0x3,%rsi
   45a48:	or     %eax,%ecx
   45a4a:	mov    %rsi,0x10(%rsp)
   45a4f:	mov    %ecx,%edi
   45a51:	cmpb   $0x0,0x58(%rsp)
   45a56:	lea    0x8(%r12),%r14
   45a5b:	mov    %rdi,0x20(%rsp)
   45a60:	jne    45338 <hotaru_core::screen::State::print_utf8+0xea8>
   45a66:	jmp    447ca <hotaru_core::screen::State::print_utf8+0x33a>
   45a6b:	mov    %ebp,%r14d
   45a6e:	jmp    45a82 <hotaru_core::screen::State::print_utf8+0x15f2>
   45a70:	mov    %rbp,0x20(%rsp)
   45a75:	jmp    456b4 <hotaru_core::screen::State::print_utf8+0x1224>
   45a7a:	mov    %rbp,0x20(%rsp)
   45a7f:	mov    %r15,%r13
   45a82:	mov    0x8(%rsp),%eax
   45a86:	mov    %r13,0x90(%rbx)
   45a8d:	test   $0x1,%al
   45a8f:	jne    456dc <hotaru_core::screen::State::print_utf8+0x124c>
   45a95:	mov    0x20(%rsp),%r12
   45a9a:	jmp    454d6 <hotaru_core::screen::State::print_utf8+0x1046>
   45a9f:	add    $0x148,%rsp
   45aa6:	pop    %rbx
   45aa7:	pop    %r12
   45aa9:	pop    %r13
   45aab:	pop    %r14
   45aad:	pop    %r15
   45aaf:	pop    %rbp
   45ab0:	ret
   45ab1:	lea    -0x38863(%rip),%rdi        # d255 <hotaru_core::unicode::BREAKS+0x214d>
   45ab8:	lea    0x5a9e1(%rip),%rdx        # a04a0 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x5b0>
   45abf:	mov    $0x14,%esi
   45ac4:	call   *0x5d55e(%rip)        # a3028 <_DYNAMIC+0x3c8>
   45aca:	jmp    45bf9 <hotaru_core::screen::State::print_utf8+0x1769>
   45acf:	call   *0x5d70b(%rip)        # a31e0 <_DYNAMIC+0x580>
   45ad5:	lea    -0x38887(%rip),%rdi        # d255 <hotaru_core::unicode::BREAKS+0x214d>
   45adc:	lea    0x5ab85(%rip),%rdx        # a0668 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x778>
   45ae3:	mov    $0x14,%esi
   45ae8:	call   *0x5d53a(%rip)        # a3028 <_DYNAMIC+0x3c8>
   45aee:	jmp    45bf9 <hotaru_core::screen::State::print_utf8+0x1769>
   45af3:	mov    $0x8,%edi
   45af8:	mov    $0x78,%esi
   45afd:	call   *0x5d3e5(%rip)        # a2ee8 <_DYNAMIC+0x288>
   45b03:	jmp    45bf9 <hotaru_core::screen::State::print_utf8+0x1769>
   45b08:	mov    $0x8,%edi
   45b0d:	mov    $0x78,%esi
   45b12:	call   *0x5d3d0(%rip)        # a2ee8 <_DYNAMIC+0x288>
   45b18:	jmp    45bf9 <hotaru_core::screen::State::print_utf8+0x1769>
   45b1d:	lea    0x5a9c4(%rip),%rdx        # a04e8 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x5f8>
   45b24:	jmp    45b39 <hotaru_core::screen::State::print_utf8+0x16a9>
   45b26:	mov    %rdx,%r15
   45b29:	lea    0x5a9d0(%rip),%rdx        # a0500 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x610>
   45b30:	jmp    45b39 <hotaru_core::screen::State::print_utf8+0x16a9>
   45b32:	lea    0x5a997(%rip),%rdx        # a04d0 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x5e0>
   45b39:	mov    0x18(%rsp),%r12
   45b3e:	mov    %r15,%rdi
   45b41:	call   *0x5d359(%rip)        # a2ea0 <_DYNAMIC+0x240>
   45b47:	jmp    45bf9 <hotaru_core::screen::State::print_utf8+0x1769>
   45b4c:	mov    %rcx,%rdi
   45b4f:	lea    0x5ad3a(%rip),%rdx        # a0890 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x9a0>
   45b56:	jmp    45b83 <hotaru_core::screen::State::print_utf8+0x16f3>
   45b58:	mov    %rcx,%rdi
   45b5b:	mov    $0x1f,%esi
   45b60:	lea    0x5ad41(%rip),%rdx        # a08a8 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x9b8>
   45b67:	jmp    45b83 <hotaru_core::screen::State::print_utf8+0x16f3>
   45b69:	mov    $0x7d00,%esi
   45b6e:	lea    0x5ad1b(%rip),%rdx        # a0890 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x9a0>
   45b75:	jmp    45b83 <hotaru_core::screen::State::print_utf8+0x16f3>
   45b77:	mov    $0xbc,%esi
   45b7c:	lea    0x5ae45(%rip),%rdx        # a09c8 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0xad8>
   45b83:	mov    0x18(%rsp),%r12
   45b88:	vzeroupper
   45b8b:	call   *0x5d30f(%rip)        # a2ea0 <_DYNAMIC+0x240>
   45b91:	jmp    45bf9 <hotaru_core::screen::State::print_utf8+0x1769>
   45b93:	lea    0x5a91e(%rip),%rdx        # a04b8 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x5c8>
   45b9a:	jmp    45b39 <hotaru_core::screen::State::print_utf8+0x16a9>
   45b9c:	lea    0x5a8e5(%rip),%rdx        # a0488 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x598>
   45ba3:	mov    $0x4,%esi
   45ba8:	call   *0x5d2f2(%rip)        # a2ea0 <_DYNAMIC+0x240>
   45bae:	mov    %r13,%rbp
   45bb1:	mov    0x30(%rsp),%r12
   45bb6:	lea    0x5aac3(%rip),%rdx        # a0680 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x790>
   45bbd:	mov    %rbp,%rdi
   45bc0:	call   *0x5d2da(%rip)        # a2ea0 <_DYNAMIC+0x240>
   45bc6:	jmp    45bf9 <hotaru_core::screen::State::print_utf8+0x1769>
   45bc8:	mov    $0x7d00,%esi
   45bcd:	jmp    45be3 <hotaru_core::screen::State::print_utf8+0x1753>
   45bcf:	mov    $0x1f,%esi
   45bd4:	lea    0x5accd(%rip),%rax        # a08a8 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x9b8>
   45bdb:	mov    %rax,0x80(%rsp)
   45be3:	mov    0x80(%rsp),%rdx
   45beb:	mov    0x30(%rsp),%r12
   45bf0:	vzeroupper
   45bf3:	call   *0x5d2a7(%rip)        # a2ea0 <_DYNAMIC+0x240>
   45bf9:	ud2
   45bfb:	jmp    45bfd <hotaru_core::screen::State::print_utf8+0x176d>
   45bfd:	mov    0x30(%rsp),%r12
   45c02:	mov    %rax,%rbx
   45c05:	jmp    45c59 <hotaru_core::screen::State::print_utf8+0x17c9>
   45c07:	jmp    45c0b <hotaru_core::screen::State::print_utf8+0x177b>
   45c09:	jmp    45c0b <hotaru_core::screen::State::print_utf8+0x177b>
   45c0b:	mov    0x30(%rsp),%r12
   45c10:	jmp    45c51 <hotaru_core::screen::State::print_utf8+0x17c1>
   45c12:	jmp    45c1e <hotaru_core::screen::State::print_utf8+0x178e>
   45c14:	mov    0x18(%rsp),%r12
   45c19:	mov    %rax,%rbx
   45c1c:	jmp    45c6a <hotaru_core::screen::State::print_utf8+0x17da>
   45c1e:	mov    %rax,%rbx
   45c21:	jmp    45c4a <hotaru_core::screen::State::print_utf8+0x17ba>
   45c23:	lea    0xc0(%rsp),%rdi
   45c2b:	mov    %rax,%rbx
   45c2e:	call   4f4c0 <core::ptr::drop_in_place<hotaru_core::row::Row>>
   45c33:	mov    0x30(%rsp),%r12
   45c38:	jmp    45c54 <hotaru_core::screen::State::print_utf8+0x17c4>
   45c3a:	lea    0xc0(%rsp),%rdi
   45c42:	mov    %rax,%rbx
   45c45:	call   4f4c0 <core::ptr::drop_in_place<hotaru_core::row::Row>>
   45c4a:	mov    0x18(%rsp),%r12
   45c4f:	jmp    45c65 <hotaru_core::screen::State::print_utf8+0x17d5>
   45c51:	mov    %rax,%rbx
   45c54:	test   %r12,%r12
   45c57:	je     45c8c <hotaru_core::screen::State::print_utf8+0x17fc>
   45c59:	lock decq (%r12)
   45c5e:	je     45c7e <hotaru_core::screen::State::print_utf8+0x17ee>
   45c60:	jmp    45c8c <hotaru_core::screen::State::print_utf8+0x17fc>
   45c62:	mov    %rax,%rbx
   45c65:	test   %r12,%r12
   45c68:	je     45c8c <hotaru_core::screen::State::print_utf8+0x17fc>
   45c6a:	lock decq (%r12)
   45c6f:	lea    0x60(%rsp),%rax
   45c74:	mov    %rax,0xa0(%rsp)
   45c7c:	jne    45c8c <hotaru_core::screen::State::print_utf8+0x17fc>
   45c7e:	mov    0xa0(%rsp),%rdi
   45c86:	call   *0x5d564(%rip)        # a31f0 <_DYNAMIC+0x590>
   45c8c:	mov    %rbx,%rdi
   45c8f:	call   9ea60 <_Unwind_Resume@plt>
