
/home/callen/work/hotaru-ascii-cell-store-20261028/target/release/hotaru-replay:     file format elf64-x86-64


Disassembly of section .text:

000000000004ba50 <hotaru_core::Terminal::feed_inner>:
   4ba50:	push   %rbp
   4ba51:	push   %r15
   4ba53:	push   %r14
   4ba55:	push   %r13
   4ba57:	push   %r12
   4ba59:	push   %rbx
   4ba5a:	sub    $0x58,%rsp
   4ba5e:	mov    %rcx,0x38(%rsp)
   4ba63:	mov    %rdx,%r15
   4ba66:	mov    %rdi,%r14
   4ba69:	test   %rdx,%rdx
   4ba6c:	je     4c8c8 <hotaru_core::Terminal::feed_inner+0xe78>
   4ba72:	vpbroadcastb -0x4147b(%rip),%xmm1        # a600 <anon.58baeeae7d5fe476157d296c9f08f803.334.llvm.5844774155465566772+0x633>
   4ba7b:	vpbroadcastb -0x41483(%rip),%xmm2        # a601 <anon.58baeeae7d5fe476157d296c9f08f803.334.llvm.5844774155465566772+0x634>
   4ba84:	mov    %rsi,%r13
   4ba87:	mov    %r15,0x30(%rsp)
   4ba8c:	mov    %r15,%rbx
   4ba8f:	xor    %ebp,%ebp
   4ba91:	jmp    4bae6 <hotaru_core::Terminal::feed_inner+0x96>
   4ba93:	movb   $0x0,0xad7(%r14)
   4ba9b:	movq   $0x0,0xa28(%r14)
   4baa6:	mov    %r14,%rdi
   4baa9:	vzeroupper
   4baac:	call   48f00 <hotaru_core::screen::Screen::enforce_budget>
   4bab1:	lea    0x130(%r14),%rdi
   4bab8:	call   48f00 <hotaru_core::screen::Screen::enforce_budget>
   4babd:	dec    %rbx
   4bac0:	inc    %r13
   4bac3:	cmp    $0x1,%rbp
   4bac7:	adc    $0xffffffffffffffff,%rbp
   4bacb:	vpbroadcastb -0x414d4(%rip),%xmm1        # a600 <anon.58baeeae7d5fe476157d296c9f08f803.334.llvm.5844774155465566772+0x633>
   4bad4:	vpbroadcastb -0x414dc(%rip),%xmm2        # a601 <anon.58baeeae7d5fe476157d296c9f08f803.334.llvm.5844774155465566772+0x634>
   4badd:	test   %rbx,%rbx
   4bae0:	je     4c8cc <hotaru_core::Terminal::feed_inner+0xe7c>
   4bae6:	mov    0x38(%rsp),%rax
   4baeb:	cmp    %rax,0x298(%r14)
   4baf2:	jae    4c8ce <hotaru_core::Terminal::feed_inner+0xe7e>
   4baf8:	movzbl 0xad7(%r14),%eax
   4bb00:	movzbl 0xad9(%r14),%ecx
   4bb08:	mov    %eax,%edx
   4bb0a:	or     %cl,%dl
   4bb0c:	jne    4bbd0 <hotaru_core::Terminal::feed_inner+0x180>
   4bb12:	cmp    $0x10,%rbx
   4bb16:	jb     4bc60 <hotaru_core::Terminal::feed_inner+0x210>
   4bb1c:	movabs $0x7ffffffffffffff0,%rax
   4bb26:	mov    %rbx,%r15
   4bb29:	mov    %r13,%rcx
   4bb2c:	and    %rax,%r15
   4bb2f:	xor    %eax,%eax
   4bb31:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   4bb40:	vpaddb (%rcx),%xmm1,%xmm0
   4bb44:	vpcmpltub %xmm2,%xmm0,%k0
   4bb4b:	kortestw %k0,%k0
   4bb4f:	jne    4bd01 <hotaru_core::Terminal::feed_inner+0x2b1>
   4bb55:	lea    -0x10(%rbx,%rax,1),%rdx
   4bb5a:	add    $0xfffffffffffffff0,%rax
   4bb5e:	add    $0x10,%rcx
   4bb62:	cmp    $0xf,%rdx
   4bb66:	ja     4bb40 <hotaru_core::Terminal::feed_inner+0xf0>
   4bb68:	add    %rbx,%rax
   4bb6b:	jne    4bc66 <hotaru_core::Terminal::feed_inner+0x216>
   4bb71:	xor    %ecx,%ecx
   4bb73:	add    %rcx,%r15
   4bb76:	test   %r15,%r15
   4bb79:	je     4bca6 <hotaru_core::Terminal::feed_inner+0x256>
   4bb7f:	cmp    %rbx,%r15
   4bb82:	ja     4c906 <hotaru_core::Terminal::feed_inner+0xeb6>
   4bb88:	mov    %r14,%rdi
   4bb8b:	mov    %r13,%rsi
   4bb8e:	mov    %r15,%rdx
   4bb91:	call   45cf0 <hotaru_core::screen::State::print_ascii>
   4bb96:	sub    %r15,%rbp
   4bb99:	mov    $0x0,%eax
   4bb9e:	cmovb  %rax,%rbp
   4bba2:	add    %r15,%r13
   4bba5:	sub    %r15,%rbx
   4bba8:	vpbroadcastb -0x415b1(%rip),%xmm1        # a600 <anon.58baeeae7d5fe476157d296c9f08f803.334.llvm.5844774155465566772+0x633>
   4bbb1:	vpbroadcastb -0x415b9(%rip),%xmm2        # a601 <anon.58baeeae7d5fe476157d296c9f08f803.334.llvm.5844774155465566772+0x634>
   4bbba:	test   %rbx,%rbx
   4bbbd:	jne    4bae6 <hotaru_core::Terminal::feed_inner+0x96>
   4bbc3:	jmp    4c8cc <hotaru_core::Terminal::feed_inner+0xe7c>
   4bbc8:	nopl   0x0(%rax,%rax,1)
   4bbd0:	movzbl 0x0(%r13),%r12d
   4bbd5:	xor    %esi,%esi
   4bbd7:	cmp    $0x90,%r12b
   4bbdb:	setae  %dil
   4bbdf:	cmp    $0xbf,%r12b
   4bbe3:	jg     4bcb8 <hotaru_core::Terminal::feed_inner+0x268>
   4bbe9:	test   %al,%al
   4bbeb:	setne  %dl
   4bbee:	test   %cl,%cl
   4bbf0:	sete   %r8b
   4bbf4:	or     %dl,%r8b
   4bbf7:	jne    4be91 <hotaru_core::Terminal::feed_inner+0x441>
   4bbfd:	mov    0xacc(%r14),%edx
   4bc04:	cmp    $0x2,%cl
   4bc07:	sete   %al
   4bc0a:	cmp    $0x800,%edx
   4bc10:	sete   %r8b
   4bc14:	test   %r8b,%al
   4bc17:	je     4be49 <hotaru_core::Terminal::feed_inner+0x3f9>
   4bc1d:	mov    0xac8(%r14),%eax
   4bc24:	cmp    $0xa0,%r12b
   4bc28:	setae  %cl
   4bc2b:	setb   %sil
   4bc2f:	test   %eax,%eax
   4bc31:	sete   %dil
   4bc35:	cmp    $0xd,%eax
   4bc38:	sete   %dl
   4bc3b:	test   %dil,%sil
   4bc3e:	jne    4be73 <hotaru_core::Terminal::feed_inner+0x423>
   4bc44:	and    %dl,%cl
   4bc46:	jne    4be73 <hotaru_core::Terminal::feed_inner+0x423>
   4bc4c:	mov    $0x800,%edx
   4bc51:	mov    $0x2,%cl
   4bc53:	jmp    4bf17 <hotaru_core::Terminal::feed_inner+0x4c7>
   4bc58:	nopl   0x0(%rax,%rax,1)
   4bc60:	mov    %rbx,%rax
   4bc63:	xor    %r15d,%r15d
   4bc66:	mov    %rbx,%rsi
   4bc69:	lea    0x0(%r13,%r15,1),%rdx
   4bc6e:	sub    %r15,%rsi
   4bc71:	xor    %ecx,%ecx
   4bc73:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   4bc80:	movzbl (%rdx,%rcx,1),%edi
   4bc84:	add    $0x81,%dil
   4bc88:	cmp    $0xa1,%dil
   4bc8c:	jb     4bb73 <hotaru_core::Terminal::feed_inner+0x123>
   4bc92:	inc    %rcx
   4bc95:	cmp    %rcx,%rsi
   4bc98:	jne    4bc80 <hotaru_core::Terminal::feed_inner+0x230>
   4bc9a:	add    %rax,%r15
   4bc9d:	test   %r15,%r15
   4bca0:	jne    4bb7f <hotaru_core::Terminal::feed_inner+0x12f>
   4bca6:	movzbl 0x0(%r13),%r12d
   4bcab:	test   %r12b,%r12b
   4bcae:	js     4bdcd <hotaru_core::Terminal::feed_inner+0x37d>
   4bcb4:	xor    %ecx,%ecx
   4bcb6:	xor    %eax,%eax
   4bcb8:	test   %al,%al
   4bcba:	setne  %dl
   4bcbd:	test   %cl,%cl
   4bcbf:	sete   %cl
   4bcc2:	or     %dl,%cl
   4bcc4:	cmp    $0x18,%r12b
   4bcc8:	je     4bcde <hotaru_core::Terminal::feed_inner+0x28e>
   4bcca:	movzbl %r12b,%r15d
   4bcce:	cmp    $0x5c,%r15d
   4bcd2:	je     4bd18 <hotaru_core::Terminal::feed_inner+0x2c8>
   4bcd4:	cmp    $0x1a,%r15d
   4bcd8:	jne    4bd7f <hotaru_core::Terminal::feed_inner+0x32f>
   4bcde:	test   %cl,%cl
   4bce0:	jne    4ba93 <hotaru_core::Terminal::feed_inner+0x43>
   4bce6:	mov    $0xfffd,%esi
   4bceb:	mov    %r14,%rdi
   4bcee:	movb   $0x0,0xad9(%r14)
   4bcf6:	call   *0x57204(%rip)        # a2f00 <_DYNAMIC+0x5d0>
   4bcfc:	jmp    4ba93 <hotaru_core::Terminal::feed_inner+0x43>
   4bd01:	kmovd  %k0,%ecx
   4bd05:	tzcnt  %ecx,%r15d
   4bd0a:	sub    %rax,%r15
   4bd0d:	test   %r15,%r15
   4bd10:	jne    4bb7f <hotaru_core::Terminal::feed_inner+0x12f>
   4bd16:	jmp    4bca6 <hotaru_core::Terminal::feed_inner+0x256>
   4bd18:	test   %cl,%cl
   4bd1a:	jne    4bd3a <hotaru_core::Terminal::feed_inner+0x2ea>
   4bd1c:	mov    $0xfffd,%esi
   4bd21:	mov    %r14,%rdi
   4bd24:	movb   $0x0,0xad9(%r14)
   4bd2c:	call   *0x571ce(%rip)        # a2f00 <_DYNAMIC+0x5d0>
   4bd32:	movzbl 0xad7(%r14),%eax
   4bd3a:	movzbl %al,%ecx
   4bd3d:	lea    -0x410c4(%rip),%rdx        # ac80 <anon.58baeeae7d5fe476157d296c9f08f803.334.llvm.5844774155465566772+0xcb3>
   4bd44:	mov    $0x5c,%r12b
   4bd47:	movslq (%rdx,%rcx,4),%rcx
   4bd4b:	add    %rdx,%rcx
   4bd4e:	jmp    *%rcx
   4bd50:	cmp    $0x3,%al
   4bd52:	jne    4c239 <hotaru_core::Terminal::feed_inner+0x7e9>
   4bd58:	mov    %r12b,0xad8(%r14)
   4bd5f:	movq   $0x0,0xa28(%r14)
   4bd6a:	movb   $0x0,0xad5(%r14)
   4bd72:	movb   $0x4,0xad7(%r14)
   4bd7a:	jmp    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4bd7f:	test   %cl,%cl
   4bd81:	jne    4bda1 <hotaru_core::Terminal::feed_inner+0x351>
   4bd83:	mov    $0xfffd,%esi
   4bd88:	mov    %r14,%rdi
   4bd8b:	movb   $0x0,0xad9(%r14)
   4bd93:	call   *0x57167(%rip)        # a2f00 <_DYNAMIC+0x5d0>
   4bd99:	movzbl 0xad7(%r14),%eax
   4bda1:	movzbl %al,%ecx
   4bda4:	lea    -0x410ff(%rip),%rdx        # acac <anon.58baeeae7d5fe476157d296c9f08f803.334.llvm.5844774155465566772+0xcdf>
   4bdab:	movslq (%rdx,%rcx,4),%rcx
   4bdaf:	add    %rdx,%rcx
   4bdb2:	jmp    *%rcx
   4bdb4:	cmp    $0x1b,%r12b
   4bdb8:	je     4c3ba <hotaru_core::Terminal::feed_inner+0x96a>
   4bdbe:	cmp    $0x1f,%r12b
   4bdc2:	jbe    4c642 <hotaru_core::Terminal::feed_inner+0xbf2>
   4bdc8:	jmp    4bea4 <hotaru_core::Terminal::feed_inner+0x454>
   4bdcd:	test   %rbp,%rbp
   4bdd0:	jne    4c50a <hotaru_core::Terminal::feed_inner+0xaba>
   4bdd6:	cmp    $0x10,%rbx
   4bdda:	jb     4c095 <hotaru_core::Terminal::feed_inner+0x645>
   4bde0:	movabs $0x7ffffffffffffff0,%rax
   4bdea:	mov    %rbx,%rbp
   4bded:	mov    %r13,%rcx
   4bdf0:	and    %rax,%rbp
   4bdf3:	xor    %eax,%eax
   4bdf5:	data16 cs nopw 0x0(%rax,%rax,1)
   4be00:	vmovdqu (%rcx),%xmm0
   4be04:	vpcmpltub -0x4300f(%rip),%xmm0,%k0        # 8e00 <anon.58baeeae7d5fe476157d296c9f08f803.1.llvm.5844774155465566772+0x30>
   4be0f:	vpcmpeqb -0x43339(%rip),%xmm0,%k1        # 8ae0 <anon.eb89d4395b0ead844ef0b45b8b54da85.151.llvm.3643936799275306673+0x172>
   4be19:	kortestw %k1,%k0
   4be1d:	jne    4c4fb <hotaru_core::Terminal::feed_inner+0xaab>
   4be23:	lea    -0x10(%rbx,%rax,1),%rdx
   4be28:	add    $0xfffffffffffffff0,%rax
   4be2c:	add    $0x10,%rcx
   4be30:	cmp    $0xf,%rdx
   4be34:	ja     4be00 <hotaru_core::Terminal::feed_inner+0x3b0>
   4be36:	add    %rbx,%rax
   4be39:	jne    4c09a <hotaru_core::Terminal::feed_inner+0x64a>
   4be3f:	xor    %ecx,%ecx
   4be41:	add    %rcx,%rbp
   4be44:	jmp    4c50a <hotaru_core::Terminal::feed_inner+0xaba>
   4be49:	mov    0xac8(%r14),%eax
   4be50:	cmp    $0x3,%cl
   4be53:	jne    4bf17 <hotaru_core::Terminal::feed_inner+0x4c7>
   4be59:	cmp    $0x10000,%edx
   4be5f:	jne    4bf17 <hotaru_core::Terminal::feed_inner+0x4c7>
   4be65:	mov    %dil,%sil
   4be68:	shl    $0x2,%esi
   4be6b:	cmp    %esi,%eax
   4be6d:	jne    4bf17 <hotaru_core::Terminal::feed_inner+0x4c7>
   4be73:	mov    $0xfffd,%esi
   4be78:	mov    %r14,%rdi
   4be7b:	movb   $0x0,0xad9(%r14)
   4be83:	call   *0x57077(%rip)        # a2f00 <_DYNAMIC+0x5d0>
   4be89:	movzbl 0xad7(%r14),%eax
   4be91:	movzbl %al,%ecx
   4be94:	lea    -0x411c3(%rip),%rdx        # acd8 <anon.58baeeae7d5fe476157d296c9f08f803.334.llvm.5844774155465566772+0xd0b>
   4be9b:	movslq (%rdx,%rcx,4),%rcx
   4be9f:	add    %rdx,%rcx
   4bea2:	jmp    *%rcx
   4bea4:	lea    -0x30(%r12),%ecx
   4bea9:	cmp    $0xa,%cl
   4beac:	jae    4bfe2 <hotaru_core::Terminal::feed_inner+0x592>
   4beb2:	cmpq   $0x0,0xab8(%r14)
   4beba:	jne    4c765 <hotaru_core::Terminal::feed_inner+0xd15>
   4bec0:	movb   $0x1,0xad4(%r14)
   4bec8:	mov    0xab0(%r14),%rsi
   4becf:	lea    -0x1(%rsi),%rdi
   4bed3:	cmp    $0x1f,%rdi
   4bed7:	ja     4c9c8 <hotaru_core::Terminal::feed_inner+0xf78>
   4bedd:	lea    0xa30(%r14),%rdx
   4bee4:	mov    $0xa,%ax
   4bee8:	movb   $0x1,-0x1(%rdx,%rsi,4)
   4beed:	mulw   -0x4(%rdx,%rsi,4)
   4bef2:	jo     4c8bf <hotaru_core::Terminal::feed_inner+0xe6f>
   4bef8:	movzbl %cl,%ecx
   4befb:	mov    $0xffff,%edi
   4bf00:	lea    0xa30(%r14),%rdx
   4bf07:	add    %ax,%cx
   4bf0a:	cmovb  %edi,%ecx
   4bf0d:	mov    %cx,-0x4(%rdx,%rsi,4)
   4bf12:	jmp    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4bf17:	and    $0x3f,%r12b
   4bf1b:	shl    $0x6,%eax
   4bf1e:	movzbl %r12b,%edi
   4bf22:	or     %eax,%edi
   4bf24:	dec    %cl
   4bf26:	mov    %edi,0xac8(%r14)
   4bf2d:	mov    %cl,0xad9(%r14)
   4bf34:	jne    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4bf3a:	xor    $0xd800,%eax
   4bf3f:	mov    $0xfffd,%ecx
   4bf44:	mov    %edi,%esi
   4bf46:	add    $0xffef0000,%eax
   4bf4b:	cmp    $0xffef0800,%eax
   4bf50:	cmovb  %ecx,%esi
   4bf53:	cmp    %edx,%edi
   4bf55:	mov    %r14,%rdi
   4bf58:	cmovb  %ecx,%esi
   4bf5b:	call   *0x56f9f(%rip)        # a2f00 <_DYNAMIC+0x5d0>
   4bf61:	jmp    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4bf66:	movq   $0x0,0xa28(%r14)
   4bf71:	movb   $0x1,0xad7(%r14)
   4bf79:	movq   $0x0,0xab8(%r14)
   4bf84:	movzbl %r12b,%eax
   4bf88:	add    $0xffffffb0,%eax
   4bf8b:	cmp    $0xf,%eax
   4bf8e:	ja     4c144 <hotaru_core::Terminal::feed_inner+0x6f4>
   4bf94:	lea    -0x41297(%rip),%rcx        # ad04 <anon.58baeeae7d5fe476157d296c9f08f803.334.llvm.5844774155465566772+0xd37>
   4bf9b:	movslq (%rcx,%rax,4),%rax
   4bf9f:	add    %rcx,%rax
   4bfa2:	jmp    *%rax
   4bfa4:	mov    0xab8(%r14),%rdx
   4bfab:	mov    $0x50,%r12b
   4bfae:	test   %rdx,%rdx
   4bfb1:	jne    4c5a9 <hotaru_core::Terminal::feed_inner+0xb59>
   4bfb7:	mov    $0x3,%al
   4bfb9:	jmp    4c0ed <hotaru_core::Terminal::feed_inner+0x69d>
   4bfbe:	cmp    $0x7,%r12b
   4bfc2:	je     4c269 <hotaru_core::Terminal::feed_inner+0x819>
   4bfc8:	movzbl %r12b,%eax
   4bfcc:	cmp    $0x1b,%eax
   4bfcf:	jne    4c298 <hotaru_core::Terminal::feed_inner+0x848>
   4bfd5:	movb   $0x8,0xad7(%r14)
   4bfdd:	jmp    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4bfe2:	cmp    $0x3a,%r12b
   4bfe6:	je     4c1eb <hotaru_core::Terminal::feed_inner+0x79b>
   4bfec:	movzbl %r12b,%ecx
   4bff0:	cmp    $0x3b,%ecx
   4bff3:	je     4c1eb <hotaru_core::Terminal::feed_inner+0x79b>
   4bff9:	cmp    $0x7f,%ecx
   4bffc:	je     4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c002:	mov    %r12d,%ecx
   4c005:	and    $0xfc,%cl
   4c008:	cmp    $0x3c,%cl
   4c00b:	jne    4c660 <hotaru_core::Terminal::feed_inner+0xc10>
   4c011:	cmpq   $0x1,0xab0(%r14)
   4c019:	jne    4c765 <hotaru_core::Terminal::feed_inner+0xd15>
   4c01f:	cmpw   $0x0,0xa30(%r14)
   4c028:	jne    4c765 <hotaru_core::Terminal::feed_inner+0xd15>
   4c02e:	cmpb   $0x0,0xad0(%r14)
   4c036:	jne    4c765 <hotaru_core::Terminal::feed_inner+0xd15>
   4c03c:	cmpq   $0x0,0xab8(%r14)
   4c044:	jne    4c765 <hotaru_core::Terminal::feed_inner+0xd15>
   4c04a:	movb   $0x1,0xad0(%r14)
   4c052:	mov    %r12b,0xad1(%r14)
   4c059:	jmp    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c05e:	movq   $0x0,0xa28(%r14)
   4c069:	movb   $0x1,0xad7(%r14)
   4c071:	movq   $0x0,0xab8(%r14)
   4c07c:	cmp    $0x1b,%r12b
   4c080:	je     4c3ba <hotaru_core::Terminal::feed_inner+0x96a>
   4c086:	cmp    $0x1f,%r12b
   4c08a:	ja     4bf84 <hotaru_core::Terminal::feed_inner+0x534>
   4c090:	jmp    4c642 <hotaru_core::Terminal::feed_inner+0xbf2>
   4c095:	mov    %rbx,%rax
   4c098:	xor    %ebp,%ebp
   4c09a:	mov    %rbx,%rsi
   4c09d:	lea    0x0(%r13,%rbp,1),%rdx
   4c0a2:	sub    %rbp,%rsi
   4c0a5:	xor    %ecx,%ecx
   4c0a7:	nopw   0x0(%rax,%rax,1)
   4c0b0:	movzbl (%rdx,%rcx,1),%edi
   4c0b4:	cmp    $0x20,%dil
   4c0b8:	jb     4be41 <hotaru_core::Terminal::feed_inner+0x3f1>
   4c0be:	cmp    $0x7f,%dil
   4c0c2:	je     4be41 <hotaru_core::Terminal::feed_inner+0x3f1>
   4c0c8:	inc    %rcx
   4c0cb:	cmp    %rcx,%rsi
   4c0ce:	jne    4c0b0 <hotaru_core::Terminal::feed_inner+0x660>
   4c0d0:	add    %rax,%rbp
   4c0d3:	jmp    4c50a <hotaru_core::Terminal::feed_inner+0xaba>
   4c0d8:	mov    0xab8(%r14),%rdx
   4c0df:	mov    $0x5b,%r12b
   4c0e2:	test   %rdx,%rdx
   4c0e5:	jne    4c5a9 <hotaru_core::Terminal::feed_inner+0xb59>
   4c0eb:	mov    $0x2,%al
   4c0ed:	lea    0xa30(%r14),%rcx
   4c0f4:	mov    %al,0xad7(%r14)
   4c0fb:	vpxor  %xmm0,%xmm0,%xmm0
   4c0ff:	vmovdqu64 %zmm0,0x40(%rcx)
   4c106:	vmovdqu64 %zmm0,(%rcx)
   4c10c:	movq   $0x1,0xab0(%r14)
   4c117:	movb   $0x0,0xad4(%r14)
   4c11f:	movb   $0x0,0xad0(%r14)
   4c127:	jmp    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c12c:	mov    0xab8(%r14),%rdx
   4c133:	mov    $0x5f,%r12b
   4c136:	test   %rdx,%rdx
   4c139:	jne    4c5a9 <hotaru_core::Terminal::feed_inner+0xb59>
   4c13f:	jmp    4c1de <hotaru_core::Terminal::feed_inner+0x78e>
   4c144:	cmp    $0x30,%r12b
   4c148:	jae    4c598 <hotaru_core::Terminal::feed_inner+0xb48>
   4c14e:	mov    0xab8(%r14),%rax
   4c155:	cmp    $0x2,%rax
   4c159:	jae    4c653 <hotaru_core::Terminal::feed_inner+0xc03>
   4c15f:	mov    %r12b,0xad2(%r14,%rax,1)
   4c167:	inc    %rax
   4c16a:	mov    %rax,0xab8(%r14)
   4c171:	jmp    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c176:	mov    0xab8(%r14),%rdx
   4c17d:	mov    $0x58,%r12b
   4c180:	test   %rdx,%rdx
   4c183:	jne    4c5a9 <hotaru_core::Terminal::feed_inner+0xb59>
   4c189:	jmp    4c1de <hotaru_core::Terminal::feed_inner+0x78e>
   4c18b:	mov    0xab8(%r14),%rdx
   4c192:	mov    $0x5d,%r12b
   4c195:	test   %rdx,%rdx
   4c198:	jne    4c5a9 <hotaru_core::Terminal::feed_inner+0xb59>
   4c19e:	movb   $0x7,0xad7(%r14)
   4c1a6:	movq   $0x0,0xa28(%r14)
   4c1b1:	movw   $0x0,0xad5(%r14)
   4c1bb:	movq   $0x800,0xac0(%r14)
   4c1c6:	jmp    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c1cb:	mov    0xab8(%r14),%rdx
   4c1d2:	mov    $0x5e,%r12b
   4c1d5:	test   %rdx,%rdx
   4c1d8:	jne    4c5a9 <hotaru_core::Terminal::feed_inner+0xb59>
   4c1de:	movb   $0x9,0xad7(%r14)
   4c1e6:	jmp    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c1eb:	cmpq   $0x0,0xab8(%r14)
   4c1f3:	jne    4c765 <hotaru_core::Terminal::feed_inner+0xd15>
   4c1f9:	movb   $0x1,0xad4(%r14)
   4c201:	mov    0xab0(%r14),%rcx
   4c208:	cmp    $0x20,%rcx
   4c20c:	je     4c765 <hotaru_core::Terminal::feed_inner+0xd15>
   4c212:	lea    -0x1(%rcx),%rdi
   4c216:	cmp    $0x1f,%rdi
   4c21a:	ja     4c9f2 <hotaru_core::Terminal::feed_inner+0xfa2>
   4c220:	cmp    $0x3a,%r12b
   4c224:	sete   0xa2e(%r14,%rcx,4)
   4c22d:	incq   0xab0(%r14)
   4c234:	jmp    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c239:	mov    0xab0(%r14),%rsi
   4c240:	cmp    $0x2,%rsi
   4c244:	jb     4c5cc <hotaru_core::Terminal::feed_inner+0xb7c>
   4c24a:	cmp    $0x21,%rsi
   4c24e:	jae    4c9da <hotaru_core::Terminal::feed_inner+0xf8a>
   4c254:	lea    0xa30(%r14),%rax
   4c25b:	movzbl -0x1(%rax,%rsi,4),%eax
   4c260:	xor    $0x1,%rax
   4c264:	jmp    4c5ce <hotaru_core::Terminal::feed_inner+0xb7e>
   4c269:	cmpb   $0x0,0xad5(%r14)
   4c271:	jne    4c73f <hotaru_core::Terminal::feed_inner+0xcef>
   4c277:	mov    0xa20(%r14),%rsi
   4c27e:	mov    0xa28(%r14),%rdx
   4c285:	mov    $0x1,%ecx
   4c28a:	mov    %r14,%rdi
   4c28d:	call   *0x56cc5(%rip)        # a2f58 <_DYNAMIC+0x628>
   4c293:	jmp    4c73f <hotaru_core::Terminal::feed_inner+0xcef>
   4c298:	cmp    $0x7,%r12b
   4c29c:	jb     4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c2a2:	setne  %al
   4c2a5:	cmp    $0x20,%r12b
   4c2a9:	setb   %cl
   4c2ac:	test   %cl,%al
   4c2ae:	jne    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c2b4:	movzbl 0xad5(%r14),%eax
   4c2bc:	cmp    $0x3b,%r12b
   4c2c0:	jne    4c311 <hotaru_core::Terminal::feed_inner+0x8c1>
   4c2c2:	cmpb   $0x0,0xad6(%r14)
   4c2ca:	jne    4c311 <hotaru_core::Terminal::feed_inner+0x8c1>
   4c2cc:	test   %al,%al
   4c2ce:	jne    4c311 <hotaru_core::Terminal::feed_inner+0x8c1>
   4c2d0:	mov    0xa28(%r14),%r15
   4c2d7:	cmp    $0x1,%r15
   4c2db:	je     4c871 <hotaru_core::Terminal::feed_inner+0xe21>
   4c2e1:	mov    $0x800,%eax
   4c2e6:	cmp    $0x2,%r15
   4c2ea:	jne    4c889 <hotaru_core::Terminal::feed_inner+0xe39>
   4c2f0:	mov    0xa20(%r14),%rax
   4c2f7:	mov    $0x800000,%ecx
   4c2fc:	cmpw   $0x3235,(%rax)
   4c301:	jmp    4c880 <hotaru_core::Terminal::feed_inner+0xe30>
   4c306:	movzbl 0xad5(%r14),%eax
   4c30e:	mov    $0x5c,%r12b
   4c311:	test   %al,%al
   4c313:	jne    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c319:	mov    0xac0(%r14),%rax
   4c320:	mov    0xa28(%r14),%r15
   4c327:	cmp    %rax,%r15
   4c32a:	jae    4c8a9 <hotaru_core::Terminal::feed_inner+0xe59>
   4c330:	lea    0xa18(%r14),%rcx
   4c337:	cmp    (%rcx),%r15
   4c33a:	jne    4c4ca <hotaru_core::Terminal::feed_inner+0xa7a>
   4c340:	lea    (%r15,%r15,1),%r10
   4c344:	mov    $0x40,%ecx
   4c349:	cmp    $0x41,%r10
   4c34d:	cmovb  %rcx,%r10
   4c351:	cmp    %r10,%rax
   4c354:	cmovb  %rax,%r10
   4c358:	cmp    %r15,%r10
   4c35b:	je     4c4bd <hotaru_core::Terminal::feed_inner+0xa6d>
   4c361:	jb     4c8a9 <hotaru_core::Terminal::feed_inner+0xe59>
   4c367:	mov    0xa20(%r14),%rdx
   4c36e:	mov    $0x1,%r8d
   4c374:	mov    $0x1,%r9d
   4c37a:	mov    %rsp,%rdi
   4c37d:	mov    %r15,%rsi
   4c380:	mov    %r10,%rcx
   4c383:	mov    %r10,0x28(%rsp)
   4c388:	jmp    4c849 <hotaru_core::Terminal::feed_inner+0xdf9>
   4c38d:	cmp    $0x1b,%r12b
   4c391:	je     4c3ba <hotaru_core::Terminal::feed_inner+0x96a>
   4c393:	cmp    $0x1f,%r12b
   4c397:	jbe    4c642 <hotaru_core::Terminal::feed_inner+0xbf2>
   4c39d:	add    $0xc0,%r12b
   4c3a1:	cmp    $0x3f,%r12b
   4c3a5:	jae    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c3ab:	jmp    4c74a <hotaru_core::Terminal::feed_inner+0xcfa>
   4c3b0:	cmp    $0x1b,%r12b
   4c3b4:	jne    4c63c <hotaru_core::Terminal::feed_inner+0xbec>
   4c3ba:	movb   $0x1,0xad7(%r14)
   4c3c2:	movq   $0x0,0xab8(%r14)
   4c3cd:	jmp    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c3d2:	cmpb   $0x0,0xad5(%r14)
   4c3da:	jne    4c73f <hotaru_core::Terminal::feed_inner+0xcef>
   4c3e0:	mov    0xa20(%r14),%rsi
   4c3e7:	mov    0xa28(%r14),%rdx
   4c3ee:	mov    %r14,%rdi
   4c3f1:	xor    %ecx,%ecx
   4c3f3:	call   *0x56b5f(%rip)        # a2f58 <_DYNAMIC+0x628>
   4c3f9:	jmp    4c73f <hotaru_core::Terminal::feed_inner+0xcef>
   4c3fe:	cmpb   $0x0,0xad5(%r14)
   4c406:	jne    4c73f <hotaru_core::Terminal::feed_inner+0xcef>
   4c40c:	mov    0xab0(%r14),%rsi
   4c413:	cmp    $0x1,%rsi
   4c417:	jbe    4c6b3 <hotaru_core::Terminal::feed_inner+0xc63>
   4c41d:	cmp    $0x21,%rsi
   4c421:	jae    4c9da <hotaru_core::Terminal::feed_inner+0xf8a>
   4c427:	lea    0xa30(%r14),%rax
   4c42e:	movzbl -0x1(%rax,%rsi,4),%eax
   4c433:	xor    $0x1,%rax
   4c437:	jmp    4c6b5 <hotaru_core::Terminal::feed_inner+0xc65>
   4c43c:	cmp    $0x1b,%r12b
   4c440:	jne    4c44f <hotaru_core::Terminal::feed_inner+0x9ff>
   4c442:	movb   $0x5,0xad7(%r14)
   4c44a:	jmp    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c44f:	cmp    $0x20,%r12b
   4c453:	setb   %al
   4c456:	cmp    $0x7f,%r12b
   4c45a:	sete   %cl
   4c45d:	or     %al,%cl
   4c45f:	jne    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c465:	cmpb   $0x0,0xad5(%r14)
   4c46d:	jne    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c473:	mov    0xa28(%r14),%r15
   4c47a:	cmp    $0x1fff,%r15
   4c481:	ja     4c8a9 <hotaru_core::Terminal::feed_inner+0xe59>
   4c487:	lea    0xa18(%r14),%rax
   4c48e:	cmp    (%rax),%r15
   4c491:	jne    4c4ca <hotaru_core::Terminal::feed_inner+0xa7a>
   4c493:	lea    (%r15,%r15,1),%rcx
   4c497:	mov    $0x40,%eax
   4c49c:	cmp    $0x41,%rcx
   4c4a0:	cmovb  %rax,%rcx
   4c4a4:	mov    $0x2000,%eax
   4c4a9:	cmp    $0x2000,%rcx
   4c4b0:	cmovae %rax,%rcx
   4c4b4:	cmp    %r15,%rcx
   4c4b7:	jne    4c829 <hotaru_core::Terminal::feed_inner+0xdd9>
   4c4bd:	lea    0xa18(%r14),%rdi
   4c4c4:	call   *0x566de(%rip)        # a2ba8 <_DYNAMIC+0x278>
   4c4ca:	mov    0xa20(%r14),%rax
   4c4d1:	mov    %r12b,(%rax,%r15,1)
   4c4d5:	inc    %r15
   4c4d8:	mov    %r15,0xa28(%r14)
   4c4df:	jmp    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c4e4:	cmp    $0x1b,%r12b
   4c4e8:	jne    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c4ee:	movb   $0xa,0xad7(%r14)
   4c4f6:	jmp    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c4fb:	korw   %k1,%k0,%k0
   4c4ff:	kmovd  %k0,%ecx
   4c503:	tzcnt  %ecx,%ebp
   4c507:	sub    %rax,%rbp
   4c50a:	cmp    %rbx,%rbp
   4c50d:	ja     4c91b <hotaru_core::Terminal::feed_inner+0xecb>
   4c513:	lea    0x40(%rsp),%rdi
   4c518:	mov    %r13,%rsi
   4c51b:	mov    %rbp,%rdx
   4c51e:	call   3f510 <hotaru_core::validate_utf8_run>
   4c523:	cmpb   $0x0,0x40(%rsp)
   4c528:	je     4c56b <hotaru_core::Terminal::feed_inner+0xb1b>
   4c52a:	mov    0x48(%rsp),%rdx
   4c52f:	cmp    %rbx,%rdx
   4c532:	ja     4c947 <hotaru_core::Terminal::feed_inner+0xef7>
   4c538:	mov    %rsp,%rdi
   4c53b:	mov    %r13,%rsi
   4c53e:	call   *0x567fc(%rip)        # a2d40 <_DYNAMIC+0x410>
   4c544:	mov    0x10(%rsp),%r15
   4c549:	test   %r15,%r15
   4c54c:	sete   %al
   4c54f:	or     (%rsp),%al
   4c552:	cmp    $0x1,%al
   4c554:	jne    4c577 <hotaru_core::Terminal::feed_inner+0xb27>
   4c556:	movzbl 0xad7(%r14),%eax
   4c55e:	movzbl 0xad9(%r14),%ecx
   4c566:	jmp    4bbd5 <hotaru_core::Terminal::feed_inner+0x185>
   4c56b:	mov    0x48(%rsp),%rsi
   4c570:	mov    0x50(%rsp),%r15
   4c575:	jmp    4c57c <hotaru_core::Terminal::feed_inner+0xb2c>
   4c577:	mov    0x8(%rsp),%rsi
   4c57c:	mov    %r14,%rdi
   4c57f:	mov    %r15,%rdx
   4c582:	call   441e0 <hotaru_core::screen::State::print_utf8>
   4c587:	cmp    %rbx,%r15
   4c58a:	ja     4c95c <hotaru_core::Terminal::feed_inner+0xf0c>
   4c590:	sub    %r15,%rbp
   4c593:	jmp    4bba2 <hotaru_core::Terminal::feed_inner+0x152>
   4c598:	cmp    $0x7e,%r12b
   4c59c:	ja     4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c5a2:	mov    0xab8(%r14),%rdx
   4c5a9:	cmp    $0x3,%rdx
   4c5ad:	jae    4c930 <hotaru_core::Terminal::feed_inner+0xee0>
   4c5b3:	movzbl %r12b,%ecx
   4c5b7:	lea    0xad2(%r14),%rsi
   4c5be:	mov    %r14,%rdi
   4c5c1:	call   *0x56999(%rip)        # a2f60 <_DYNAMIC+0x630>
   4c5c7:	jmp    4c74a <hotaru_core::Terminal::feed_inner+0xcfa>
   4c5cc:	xor    %eax,%eax
   4c5ce:	sub    %rax,%rsi
   4c5d1:	cmp    $0x21,%rsi
   4c5d5:	jae    4c972 <hotaru_core::Terminal::feed_inner+0xf22>
   4c5db:	mov    0xab8(%r14),%rax
   4c5e2:	cmp    $0x3,%rax
   4c5e6:	jae    4c986 <hotaru_core::Terminal::feed_inner+0xf36>
   4c5ec:	movzbl 0xad4(%r14),%edx
   4c5f4:	movzwl 0xad0(%r14),%ecx
   4c5fc:	lea    0xa30(%r14),%rdi
   4c603:	mov    %rdi,(%rsp)
   4c607:	mov    %rsi,0x8(%rsp)
   4c60c:	mov    %r14,%rdi
   4c60f:	mov    %rsp,%rsi
   4c612:	mov    %dl,0x23(%rsp)
   4c616:	lea    0xad2(%r14),%rdx
   4c61d:	mov    %cx,0x21(%rsp)
   4c622:	mov    %rdx,0x10(%rsp)
   4c627:	mov    %rax,0x18(%rsp)
   4c62c:	mov    %r12b,0x20(%rsp)
   4c631:	call   *0x56931(%rip)        # a2f68 <_DYNAMIC+0x638>
   4c637:	jmp    4c74a <hotaru_core::Terminal::feed_inner+0xcfa>
   4c63c:	cmp    $0x1f,%r12b
   4c640:	ja     4c698 <hotaru_core::Terminal::feed_inner+0xc48>
   4c642:	mov    %r14,%rdi
   4c645:	mov    %r15d,%esi
   4c648:	call   *0x56922(%rip)        # a2f70 <_DYNAMIC+0x640>
   4c64e:	jmp    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c653:	movb   $0x6,0xad7(%r14)
   4c65b:	jmp    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c660:	cmp    $0x30,%r12b
   4c664:	jae    4c757 <hotaru_core::Terminal::feed_inner+0xd07>
   4c66a:	mov    0xab8(%r14),%rdi
   4c671:	cmp    $0x2,%rdi
   4c675:	je     4c765 <hotaru_core::Terminal::feed_inner+0xd15>
   4c67b:	jae    4ca04 <hotaru_core::Terminal::feed_inner+0xfb4>
   4c681:	mov    %r12b,0xad2(%r14,%rdi,1)
   4c689:	inc    %rdi
   4c68c:	mov    %rdi,0xab8(%r14)
   4c693:	jmp    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c698:	cmp    $0x7e,%r12b
   4c69c:	ja     4c77c <hotaru_core::Terminal::feed_inner+0xd2c>
   4c6a2:	mov    %r14,%rdi
   4c6a5:	mov    %r15d,%esi
   4c6a8:	call   *0x56852(%rip)        # a2f00 <_DYNAMIC+0x5d0>
   4c6ae:	jmp    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c6b3:	xor    %eax,%eax
   4c6b5:	sub    %rax,%rsi
   4c6b8:	cmp    $0x21,%rsi
   4c6bc:	jae    4c99d <hotaru_core::Terminal::feed_inner+0xf4d>
   4c6c2:	mov    0xab8(%r14),%rax
   4c6c9:	cmp    $0x3,%rax
   4c6cd:	jae    4c9b1 <hotaru_core::Terminal::feed_inner+0xf61>
   4c6d3:	vmovd  0xad8(%r14),%xmm0
   4c6dc:	lea    0xa30(%r14),%rcx
   4c6e3:	mov    0xa20(%r14),%rdx
   4c6ea:	mov    %r14,%rdi
   4c6ed:	mov    %rcx,(%rsp)
   4c6f1:	lea    0xad2(%r14),%rcx
   4c6f8:	mov    %rsi,0x8(%rsp)
   4c6fd:	mov    %rsp,%rsi
   4c700:	mov    %rcx,0x10(%rsp)
   4c705:	mov    %rax,0x18(%rsp)
   4c70a:	mov    0xad0(%r14),%rax
   4c711:	mov    %eax,%ecx
   4c713:	shr    $0x8,%ecx
   4c716:	vpinsrb $0x1,%eax,%xmm0,%xmm0
   4c71c:	shr    $0x20,%rax
   4c720:	vpinsrb $0x2,%ecx,%xmm0,%xmm0
   4c726:	mov    0xa28(%r14),%rcx
   4c72d:	vpinsrb $0x3,%eax,%xmm0,%xmm0
   4c733:	vmovd  %xmm0,0x20(%rsp)
   4c739:	call   *0x56839(%rip)        # a2f78 <_DYNAMIC+0x648>
   4c73f:	movq   $0x0,0xa28(%r14)
   4c74a:	movb   $0x0,0xad7(%r14)
   4c752:	jmp    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c757:	lea    -0x40(%r12),%ecx
   4c75c:	cmp    $0x3f,%cl
   4c75f:	jb     4bd50 <hotaru_core::Terminal::feed_inner+0x300>
   4c765:	xor    %ecx,%ecx
   4c767:	cmp    $0x3,%al
   4c769:	sete   %cl
   4c76c:	lea    0x6(%rcx,%rcx,2),%eax
   4c770:	mov    %al,0xad7(%r14)
   4c777:	jmp    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c77c:	cmp    $0x7f,%r12b
   4c780:	je     4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c786:	lea    0x3e(%r12),%eax
   4c78b:	cmp    $0x1e,%al
   4c78d:	jae    4c7b6 <hotaru_core::Terminal::feed_inner+0xd66>
   4c78f:	and    $0x1f,%r12b
   4c793:	movzbl %r12b,%eax
   4c797:	mov    %eax,0xac8(%r14)
   4c79e:	movb   $0x1,0xad9(%r14)
   4c7a6:	movl   $0x80,0xacc(%r14)
   4c7b1:	jmp    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c7b6:	mov    %r12d,%eax
   4c7b9:	and    $0xf0,%al
   4c7bb:	cmp    $0xe0,%al
   4c7bd:	jne    4c7e6 <hotaru_core::Terminal::feed_inner+0xd96>
   4c7bf:	and    $0xf,%r12b
   4c7c3:	movzbl %r12b,%eax
   4c7c7:	mov    %eax,0xac8(%r14)
   4c7ce:	movb   $0x2,0xad9(%r14)
   4c7d6:	movl   $0x800,0xacc(%r14)
   4c7e1:	jmp    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c7e6:	lea    0x10(%r12),%eax
   4c7eb:	cmp    $0x5,%al
   4c7ed:	jae    4c816 <hotaru_core::Terminal::feed_inner+0xdc6>
   4c7ef:	and    $0x7,%r12b
   4c7f3:	movzbl %r12b,%eax
   4c7f7:	mov    %eax,0xac8(%r14)
   4c7fe:	movb   $0x3,0xad9(%r14)
   4c806:	movl   $0x10000,0xacc(%r14)
   4c811:	jmp    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c816:	mov    $0xfffd,%esi
   4c81b:	mov    %r14,%rdi
   4c81e:	call   *0x566dc(%rip)        # a2f00 <_DYNAMIC+0x5d0>
   4c824:	jmp    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c829:	jb     4c8a9 <hotaru_core::Terminal::feed_inner+0xe59>
   4c82b:	mov    0xa20(%r14),%rdx
   4c832:	mov    $0x1,%r8d
   4c838:	mov    $0x1,%r9d
   4c83e:	mov    %rsp,%rdi
   4c841:	mov    %r15,%rsi
   4c844:	mov    %rcx,0x28(%rsp)
   4c849:	call   50900 <alloc::raw_vec::RawVecInner<A>::finish_grow>
   4c84e:	cmpl   $0x1,(%rsp)
   4c852:	je     4c8a9 <hotaru_core::Terminal::feed_inner+0xe59>
   4c854:	mov    0x8(%rsp),%rax
   4c859:	mov    0x28(%rsp),%rcx
   4c85e:	mov    %rax,0xa20(%r14)
   4c865:	mov    %rcx,0xa18(%r14)
   4c86c:	jmp    4c4ca <hotaru_core::Terminal::feed_inner+0xa7a>
   4c871:	mov    0xa20(%r14),%rax
   4c878:	mov    $0x4000,%ecx
   4c87d:	cmpb   $0x37,(%rax)
   4c880:	mov    $0x800,%eax
   4c885:	cmove  %rcx,%rax
   4c889:	lea    0x1(%r15,%rax,1),%rax
   4c88e:	mov    $0x3b,%r12b
   4c891:	mov    %rax,0xac0(%r14)
   4c898:	movb   $0x1,0xad6(%r14)
   4c8a0:	cmp    %rax,%r15
   4c8a3:	jb     4c330 <hotaru_core::Terminal::feed_inner+0x8e0>
   4c8a9:	movb   $0x1,0xad5(%r14)
   4c8b1:	xor    %eax,%eax
   4c8b3:	mov    %rax,0xa28(%r14)
   4c8ba:	jmp    4baa6 <hotaru_core::Terminal::feed_inner+0x56>
   4c8bf:	mov    $0xffff,%ax
   4c8c3:	jmp    4bef8 <hotaru_core::Terminal::feed_inner+0x4a8>
   4c8c8:	xor    %ebx,%ebx
   4c8ca:	jmp    4c8d3 <hotaru_core::Terminal::feed_inner+0xe83>
   4c8cc:	xor    %ebx,%ebx
   4c8ce:	mov    0x30(%rsp),%r15
   4c8d3:	incq   0x6c8(%r14)
   4c8da:	mov    %r14,%rdi
   4c8dd:	call   48f00 <hotaru_core::screen::Screen::enforce_budget>
   4c8e2:	add    $0x130,%r14
   4c8e9:	mov    %r14,%rdi
   4c8ec:	call   48f00 <hotaru_core::screen::Screen::enforce_budget>
   4c8f1:	sub    %rbx,%r15
   4c8f4:	mov    %r15,%rax
   4c8f7:	add    $0x58,%rsp
   4c8fb:	pop    %rbx
   4c8fc:	pop    %r12
   4c8fe:	pop    %r13
   4c900:	pop    %r14
   4c902:	pop    %r15
   4c904:	pop    %rbp
   4c905:	ret
   4c906:	lea    0x53cfb(%rip),%rcx        # a0608 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x9e8>
   4c90d:	xor    %edi,%edi
   4c90f:	mov    %r15,%rsi
   4c912:	mov    %rbx,%rdx
   4c915:	call   *0x563a5(%rip)        # a2cc0 <_DYNAMIC+0x390>
   4c91b:	lea    0x53cce(%rip),%rcx        # a05f0 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x9d0>
   4c922:	xor    %edi,%edi
   4c924:	mov    %rbp,%rsi
   4c927:	mov    %rbx,%rdx
   4c92a:	call   *0x56390(%rip)        # a2cc0 <_DYNAMIC+0x390>
   4c930:	mov    %rdx,%rsi
   4c933:	lea    0x53716(%rip),%rcx        # a0050 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x430>
   4c93a:	mov    $0x2,%edx
   4c93f:	xor    %edi,%edi
   4c941:	call   *0x56379(%rip)        # a2cc0 <_DYNAMIC+0x390>
   4c947:	lea    0x53c8a(%rip),%rcx        # a05d8 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x9b8>
   4c94e:	mov    %rdx,%rsi
   4c951:	xor    %edi,%edi
   4c953:	mov    %rbx,%rdx
   4c956:	call   *0x56364(%rip)        # a2cc0 <_DYNAMIC+0x390>
   4c95c:	lea    0x53c5d(%rip),%rcx        # a05c0 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x9a0>
   4c963:	mov    %r15,%rdi
   4c966:	mov    %rbx,%rsi
   4c969:	mov    %rbx,%rdx
   4c96c:	call   *0x5634e(%rip)        # a2cc0 <_DYNAMIC+0x390>
   4c972:	lea    0x53737(%rip),%rcx        # a00b0 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x490>
   4c979:	mov    $0x20,%edx
   4c97e:	xor    %edi,%edi
   4c980:	call   *0x5633a(%rip)        # a2cc0 <_DYNAMIC+0x390>
   4c986:	lea    0x5370b(%rip),%rcx        # a0098 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x478>
   4c98d:	mov    $0x2,%edx
   4c992:	xor    %edi,%edi
   4c994:	mov    %rax,%rsi
   4c997:	call   *0x56323(%rip)        # a2cc0 <_DYNAMIC+0x390>
   4c99d:	lea    0x5376c(%rip),%rcx        # a0110 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x4f0>
   4c9a4:	mov    $0x20,%edx
   4c9a9:	xor    %edi,%edi
   4c9ab:	call   *0x5630f(%rip)        # a2cc0 <_DYNAMIC+0x390>
   4c9b1:	lea    0x53740(%rip),%rcx        # a00f8 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x4d8>
   4c9b8:	mov    $0x2,%edx
   4c9bd:	xor    %edi,%edi
   4c9bf:	mov    %rax,%rsi
   4c9c2:	call   *0x562f8(%rip)        # a2cc0 <_DYNAMIC+0x390>
   4c9c8:	lea    0x53711(%rip),%rdx        # a00e0 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x4c0>
   4c9cf:	mov    $0x20,%esi
   4c9d4:	call   *0x56196(%rip)        # a2b70 <_DYNAMIC+0x240>
   4c9da:	dec    %rsi
   4c9dd:	lea    0x5369c(%rip),%rdx        # a0080 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x460>
   4c9e4:	mov    %rsi,%rdi
   4c9e7:	mov    $0x20,%esi
   4c9ec:	call   *0x5617e(%rip)        # a2b70 <_DYNAMIC+0x240>
   4c9f2:	lea    0x5366f(%rip),%rdx        # a0068 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x448>
   4c9f9:	mov    $0x20,%esi
   4c9fe:	call   *0x5616c(%rip)        # a2b70 <_DYNAMIC+0x240>
   4ca04:	lea    0x536bd(%rip),%rdx        # a00c8 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x4a8>
   4ca0b:	mov    $0x2,%esi
   4ca10:	call   *0x5615a(%rip)        # a2b70 <_DYNAMIC+0x240>
