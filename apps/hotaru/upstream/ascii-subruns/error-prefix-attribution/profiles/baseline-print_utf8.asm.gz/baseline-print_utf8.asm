
/home/callen/work/hotaru-ascii-cell-store-20261028/target/release/hotaru-replay:     file format elf64-x86-64


Disassembly of section .text:

00000000000441e0 <hotaru_core::screen::State::print_utf8>:
   441e0:	push   %rbp
   441e1:	push   %r15
   441e3:	push   %r14
   441e5:	push   %r13
   441e7:	push   %r12
   441e9:	push   %rbx
   441ea:	sub    $0x148,%rsp
   441f1:	cmpb   $0x0,0xa02(%rdi)
   441f8:	mov    %rdi,%r15
   441fb:	mov    %rdx,0x38(%rsp)
   44200:	je     442a7 <hotaru_core::screen::State::print_utf8+0xc7>
   44206:	cmpq   $0x0,0x38(%rsp)
   4420c:	je     457ef <hotaru_core::screen::State::print_utf8+0x160f>
   44212:	add    %rsi,0x38(%rsp)
   44217:	mov    0x5ece2(%rip),%rbx        # a2f00 <_DYNAMIC+0x5d0>
   4421e:	mov    %rsi,%r14
   44221:	jmp    44243 <hotaru_core::screen::State::print_utf8+0x63>
   44223:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   44230:	inc    %r14
   44233:	mov    %r15,%rdi
   44236:	call   *%rbx
   44238:	cmp    0x38(%rsp),%r14
   4423d:	je     457ef <hotaru_core::screen::State::print_utf8+0x160f>
   44243:	movzbl (%r14),%esi
   44247:	test   %sil,%sil
   4424a:	jns    44230 <hotaru_core::screen::State::print_utf8+0x50>
   4424c:	movzbl 0x1(%r14),%edx
   44251:	mov    %esi,%eax
   44253:	and    $0x1f,%eax
   44256:	and    $0x3f,%edx
   44259:	cmp    $0xdf,%sil
   4425d:	jbe    4428d <hotaru_core::screen::State::print_utf8+0xad>
   4425f:	movzbl 0x2(%r14),%ecx
   44264:	shl    $0x6,%edx
   44267:	and    $0x3f,%ecx
   4426a:	or     %edx,%ecx
   4426c:	cmp    $0xf0,%sil
   44270:	jb     4429a <hotaru_core::screen::State::print_utf8+0xba>
   44272:	movzbl 0x3(%r14),%esi
   44277:	and    $0x7,%eax
   4427a:	shl    $0x6,%ecx
   4427d:	add    $0x4,%r14
   44281:	shl    $0x12,%eax
   44284:	and    $0x3f,%esi
   44287:	or     %ecx,%esi
   44289:	or     %eax,%esi
   4428b:	jmp    44233 <hotaru_core::screen::State::print_utf8+0x53>
   4428d:	shl    $0x6,%eax
   44290:	add    $0x2,%r14
   44294:	or     %edx,%eax
   44296:	mov    %eax,%esi
   44298:	jmp    44233 <hotaru_core::screen::State::print_utf8+0x53>
   4429a:	shl    $0xc,%eax
   4429d:	add    $0x3,%r14
   442a1:	or     %eax,%ecx
   442a3:	mov    %ecx,%esi
   442a5:	jmp    44233 <hotaru_core::screen::State::print_utf8+0x53>
   442a7:	mov    0x3b8(%r15),%rdi
   442ae:	cmp    $0x4,%rdi
   442b2:	jae    458ec <hotaru_core::screen::State::print_utf8+0x170c>
   442b8:	cmpb   $0x0,0x6d8(%r15,%rdi,1)
   442c1:	jne    44206 <hotaru_core::screen::State::print_utf8+0x26>
   442c7:	cmpq   $0x0,0x260(%r15)
   442cf:	jne    44206 <hotaru_core::screen::State::print_utf8+0x26>
   442d5:	cmpq   $0x0,0x38(%rsp)
   442db:	je     457ef <hotaru_core::screen::State::print_utf8+0x160f>
   442e1:	add    %rsi,0x38(%rsp)
   442e6:	lea    0x6ea(%r15),%rax
   442ed:	mov    %r15,0x88(%rsp)
   442f5:	mov    %rax,0xb0(%rsp)
   442fd:	lea    0x6f2(%r15),%rax
   44304:	mov    %rax,0xa8(%rsp)
   4430c:	lea    0x130(%r15),%rax
   44313:	mov    %rax,0x90(%rsp)
   4431b:	lea    0x78(%rsp),%rax
   44320:	mov    %rax,0xa0(%rsp)
   44328:	lea    0x5c249(%rip),%rax        # a0578 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x958>
   4432f:	mov    %rax,0x80(%rsp)
   44337:	jmp    44358 <hotaru_core::screen::State::print_utf8+0x178>
   44339:	nopl   0x0(%rax)
   44340:	mov    0x88(%rsp),%r15
   44348:	mov    0x10(%rsp),%rsi
   4434d:	cmp    0x38(%rsp),%rsi
   44352:	je     457ef <hotaru_core::screen::State::print_utf8+0x160f>
   44358:	movzbl (%rsi),%r14d
   4435c:	test   %r14b,%r14b
   4435f:	js     44370 <hotaru_core::screen::State::print_utf8+0x190>
   44361:	inc    %rsi
   44364:	mov    %rsi,0x10(%rsp)
   44369:	jmp    443f0 <hotaru_core::screen::State::print_utf8+0x210>
   4436e:	xchg   %ax,%ax
   44370:	movzbl 0x1(%rsi),%edx
   44374:	mov    %r14d,%eax
   44377:	and    $0x1f,%eax
   4437a:	and    $0x3f,%edx
   4437d:	cmp    $0xdf,%r14b
   44381:	jbe    443c0 <hotaru_core::screen::State::print_utf8+0x1e0>
   44383:	movzbl 0x2(%rsi),%ecx
   44387:	shl    $0x6,%edx
   4438a:	and    $0x3f,%ecx
   4438d:	or     %edx,%ecx
   4438f:	cmp    $0xf0,%r14b
   44393:	jb     443d3 <hotaru_core::screen::State::print_utf8+0x1f3>
   44395:	movzbl 0x3(%rsi),%r14d
   4439a:	and    $0x7,%eax
   4439d:	shl    $0x6,%ecx
   443a0:	shl    $0x12,%eax
   443a3:	and    $0x3f,%r14d
   443a7:	or     %ecx,%r14d
   443aa:	or     %eax,%r14d
   443ad:	cmp    $0x110000,%r14d
   443b4:	je     457ef <hotaru_core::screen::State::print_utf8+0x160f>
   443ba:	add    $0x4,%rsi
   443be:	jmp    44364 <hotaru_core::screen::State::print_utf8+0x184>
   443c0:	shl    $0x6,%eax
   443c3:	add    $0x2,%rsi
   443c7:	or     %edx,%eax
   443c9:	mov    %rsi,0x10(%rsp)
   443ce:	mov    %eax,%r14d
   443d1:	jmp    443f0 <hotaru_core::screen::State::print_utf8+0x210>
   443d3:	shl    $0xc,%eax
   443d6:	add    $0x3,%rsi
   443da:	or     %eax,%ecx
   443dc:	mov    %rsi,0x10(%rsp)
   443e1:	mov    %ecx,%r14d
   443e4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   443f0:	mov    $0xffffffffffffffff,%rsi
   443f7:	mov    %r15,%rdi
   443fa:	call   473b0 <hotaru_core::screen::State::scalar_metadata_writes>
   443ff:	test   %al,%al
   44401:	je     44550 <hotaru_core::screen::State::print_utf8+0x370>
   44407:	cmpb   $0x0,0x6df(%r15)
   4440f:	mov    %r15,%rbx
   44412:	mov    0xb0(%rsp),%rcx
   4441a:	cmovne 0x90(%rsp),%rbx
   44423:	mov    (%rcx),%rax
   44426:	mov    0x6(%rcx),%rcx
   4442a:	cmpb   $0x0,0x12f(%rbx)
   44431:	mov    %rcx,0x66(%rsp)
   44436:	mov    %rax,0x60(%rsp)
   4443b:	jne    45270 <hotaru_core::screen::State::print_utf8+0x1090>
   44441:	movzbl 0x6e6(%r15),%eax
   44449:	movzbl 0xa01(%r15),%edx
   44451:	movzbl 0xa04(%r15),%ecx
   44459:	mov    0x118(%rbx),%r12
   44460:	mov    %al,0x58(%rsp)
   44464:	mov    %dl,0xf(%rsp)
   44468:	test   %r12,%r12
   4446b:	je     44478 <hotaru_core::screen::State::print_utf8+0x298>
   4446d:	lock incq (%r12)
   44472:	jle    4581f <hotaru_core::screen::State::print_utf8+0x163f>
   44478:	mov    0x98(%rbx),%r15
   4447f:	mov    %r12,0x78(%rsp)
   44484:	cmp    0x38(%rbx),%r15
   44488:	jae    45825 <hotaru_core::screen::State::print_utf8+0x1645>
   4448e:	add    0x30(%rbx),%r15
   44492:	mov    0x20(%rbx),%rax
   44496:	mov    %r12,0x30(%rsp)
   4449b:	mov    0x28(%rbx),%r12
   4449f:	mov    %cl,0x48(%rsp)
   444a3:	mov    $0x0,%ecx
   444a8:	mov    0x90(%rbx),%rbp
   444af:	cmp    %rax,%r15
   444b2:	cmovb  %rcx,%rax
   444b6:	sub    %rax,%r15
   444b9:	mov    (%r12,%r15,8),%rax
   444bd:	mov    (%rax),%rax
   444c0:	mov    (%r12,%r15,8),%r13
   444c4:	cmp    $0x1,%rax
   444c8:	jne    44fd8 <hotaru_core::screen::State::print_utf8+0xdf8>
   444ce:	mov    %r13,%r12
   444d1:	mov    %rbp,%r15
   444d4:	cmp    $0x110001,%r14d
   444db:	jne    4505d <hotaru_core::screen::State::print_utf8+0xe7d>
   444e1:	mov    0x10(%rsp),%rsi
   444e6:	cmp    0x38(%rsp),%rsi
   444eb:	je     450b2 <hotaru_core::screen::State::print_utf8+0xed2>
   444f1:	movzbl (%rsi),%edi
   444f4:	test   %dil,%dil
   444f7:	js     45303 <hotaru_core::screen::State::print_utf8+0x1123>
   444fd:	inc    %rsi
   44500:	mov    %rsi,0x10(%rsp)
   44505:	cmpb   $0x0,0x58(%rsp)
   4450a:	lea    0x8(%r12),%r14
   4450f:	mov    %rdi,0x20(%rsp)
   44514:	jne    45088 <hotaru_core::screen::State::print_utf8+0xea8>
   4451a:	vzeroupper
   4451d:	call   43800 <hotaru_core::screen::char_width>
   44522:	mov    %rax,%r13
   44525:	test   %rax,%rax
   44528:	je     45214 <hotaru_core::screen::State::print_utf8+0x1034>
   4452e:	mov    0xf0(%rbx),%rcx
   44535:	mov    %r13,%rax
   44538:	add    %r15,%rax
   4453b:	mov    %rcx,0x40(%rsp)
   44540:	cmp    %rcx,%rax
   44543:	jbe    451d9 <hotaru_core::screen::State::print_utf8+0xff9>
   44549:	jmp    45214 <hotaru_core::screen::State::print_utf8+0x1034>
   4454e:	xchg   %ax,%ax
   44550:	mov    0xa8(%rsp),%rcx
   44558:	cmpb   $0x0,0x6df(%r15)
   44560:	vmovq  0x6ea(%r15),%xmm0
   44569:	mov    0x6ee(%r15),%eax
   44570:	movzbl 0x6e6(%r15),%edx
   44578:	movzwl 0x4(%rcx),%edi
   4457c:	mov    (%rcx),%esi
   4457e:	movzbl 0xa04(%r15),%ecx
   44586:	mov    %eax,0x9c(%rsp)
   4458d:	mov    %dl,0xf(%rsp)
   44591:	vmovdqa %xmm0,0x130(%rsp)
   4459a:	mov    %cl,0x30(%rsp)
   4459e:	movzbl 0xa01(%r15),%ecx
   445a6:	mov    %di,0x74(%rsp)
   445ab:	mov    %esi,0x70(%rsp)
   445af:	mov    %cl,0x2f(%rsp)
   445b3:	mov    %r15,%rcx
   445b6:	cmovne 0x90(%rsp),%rcx
   445bf:	mov    0x90(%rcx),%r15
   445c6:	mov    0x118(%rcx),%r12
   445cd:	test   %r12,%r12
   445d0:	je     445dd <hotaru_core::screen::State::print_utf8+0x3fd>
   445d2:	lock incq (%r12)
   445d7:	jle    4581f <hotaru_core::screen::State::print_utf8+0x163f>
   445dd:	mov    0x98(%rcx),%rbx
   445e4:	mov    %r12,0x60(%rsp)
   445e9:	cmp    0x38(%rcx),%rbx
   445ed:	jae    45801 <hotaru_core::screen::State::print_utf8+0x1621>
   445f3:	add    0x30(%rcx),%rbx
   445f7:	mov    0x20(%rcx),%rdx
   445fb:	mov    %r12,0x18(%rsp)
   44600:	movzbl 0x12f(%rcx),%eax
   44607:	mov    0x28(%rcx),%r12
   4460b:	mov    %rcx,0x58(%rsp)
   44610:	mov    $0x0,%ecx
   44615:	cmp    %rdx,%rbx
   44618:	mov    %eax,0x8(%rsp)
   4461c:	cmovae %rdx,%rcx
   44620:	sub    %rcx,%rbx
   44623:	mov    (%r12,%rbx,8),%rax
   44627:	mov    (%rax),%rax
   4462a:	mov    (%r12,%rbx,8),%r13
   4462e:	cmp    $0x1,%rax
   44632:	je     446ac <hotaru_core::screen::State::print_utf8+0x4cc>
   44634:	lea    0x8(%r13),%rsi
   44638:	lea    0xc0(%rsp),%rdi
   44640:	call   *0x5e8c2(%rip)        # a2f08 <_DYNAMIC+0x5d8>
   44646:	mov    $0x78,%edi
   4464b:	movq   $0x1,0xb8(%rsp)
   44657:	call   *0x5e4bb(%rip)        # a2b18 <malloc@GLIBC_2.2.5>
   4465d:	test   %rax,%rax
   44660:	je     45843 <hotaru_core::screen::State::print_utf8+0x1663>
   44666:	vmovups 0xf0(%rsp),%zmm1
   44671:	vmovdqu64 0xb8(%rsp),%zmm0
   4467c:	lea    (%r12,%rbx,8),%rbx
   44680:	mov    %rax,%r12
   44683:	vmovups %zmm1,0x38(%rax)
   4468d:	vmovdqu64 %zmm0,(%rax)
   44693:	lock decq 0x0(%r13)
   44698:	jne    446a6 <hotaru_core::screen::State::print_utf8+0x4c6>
   4469a:	mov    %rbx,%rdi
   4469d:	vzeroupper
   446a0:	call   *0x5e86a(%rip)        # a2f10 <_DYNAMIC+0x5e0>
   446a6:	mov    %r12,%r13
   446a9:	mov    %r12,(%rbx)
   446ac:	lea    0x8(%r13),%rax
   446b0:	mov    $0x110000,%r12d
   446b6:	mov    %r13,0x20(%rsp)
   446bb:	xor    %r13d,%r13d
   446be:	mov    %rax,0x48(%rsp)
   446c3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   446d0:	cmp    $0x110001,%r14d
   446d7:	jne    44750 <hotaru_core::screen::State::print_utf8+0x570>
   446d9:	mov    0x10(%rsp),%rsi
   446de:	cmp    0x38(%rsp),%rsi
   446e3:	je     44f44 <hotaru_core::screen::State::print_utf8+0xd64>
   446e9:	movzbl (%rsi),%r14d
   446ed:	test   %r14b,%r14b
   446f0:	js     446fc <hotaru_core::screen::State::print_utf8+0x51c>
   446f2:	inc    %rsi
   446f5:	mov    %rsi,0x10(%rsp)
   446fa:	jmp    4475d <hotaru_core::screen::State::print_utf8+0x57d>
   446fc:	movzbl 0x1(%rsi),%edx
   44700:	mov    %r14d,%eax
   44703:	and    $0x1f,%eax
   44706:	and    $0x3f,%edx
   44709:	cmp    $0xdf,%r14b
   4470d:	jbe    44f0a <hotaru_core::screen::State::print_utf8+0xd2a>
   44713:	movzbl 0x2(%rsi),%ecx
   44717:	shl    $0x6,%edx
   4471a:	and    $0x3f,%ecx
   4471d:	or     %edx,%ecx
   4471f:	cmp    $0xf0,%r14b
   44723:	jb     44f20 <hotaru_core::screen::State::print_utf8+0xd40>
   44729:	movzbl 0x3(%rsi),%r14d
   4472e:	and    $0x7,%eax
   44731:	shl    $0x6,%ecx
   44734:	add    $0x4,%rsi
   44738:	shl    $0x12,%eax
   4473b:	mov    %rsi,0x10(%rsp)
   44740:	and    $0x3f,%r14d
   44744:	or     %ecx,%r14d
   44747:	or     %eax,%r14d
   4474a:	nopw   0x0(%rax,%rax,1)
   44750:	cmp    $0x110000,%r14d
   44757:	je     44f44 <hotaru_core::screen::State::print_utf8+0xd64>
   4475d:	cmpb   $0x0,0xf(%rsp)
   44762:	mov    %r15,0x40(%rsp)
   44767:	je     44790 <hotaru_core::screen::State::print_utf8+0x5b0>
   44769:	cmp    $0x100,%r14d
   44770:	jae    447e0 <hotaru_core::screen::State::print_utf8+0x600>
   44772:	lea    -0xa0(%r14),%eax
   44779:	xor    %ebp,%ebp
   4477b:	cmp    $0xffffffe0,%eax
   4477e:	setb   %bpl
   44782:	jmp    44861 <hotaru_core::screen::State::print_utf8+0x681>
   44787:	nopw   0x0(%rax,%rax,1)
   44790:	mov    %r14d,%edi
   44793:	vzeroupper
   44796:	call   43800 <hotaru_core::screen::char_width>
   4479b:	mov    %rax,%rbp
   4479e:	test   %rax,%rax
   447a1:	je     45110 <hotaru_core::screen::State::print_utf8+0xf30>
   447a7:	testb  $0x1,0x8(%rsp)
   447ac:	mov    0x40(%rsp),%r15
   447b1:	jne    44f4a <hotaru_core::screen::State::print_utf8+0xd6a>
   447b7:	mov    0x58(%rsp),%rcx
   447bc:	mov    %rbp,%rax
   447bf:	add    %r15,%rax
   447c2:	cmp    0xf0(%rcx),%rax
   447c9:	jbe    448b1 <hotaru_core::screen::State::print_utf8+0x6d1>
   447cf:	jmp    44f40 <hotaru_core::screen::State::print_utf8+0xd60>
   447d4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   447e0:	lea    -0x3400(%r14),%eax
   447e7:	lea    -0x4e00(%r14),%ecx
   447ee:	mov    $0x2,%ebp
   447f3:	cmp    $0x19c0,%eax
   447f8:	setb   %al
   447fb:	cmp    $0x5200,%ecx
   44801:	setb   %cl
   44804:	or     %al,%cl
   44806:	lea    -0xf900(%r14),%eax
   4480d:	cmp    $0x200,%eax
   44812:	setb   %al
   44815:	or     %cl,%al
   44817:	jne    44861 <hotaru_core::screen::State::print_utf8+0x681>
   44819:	mov    %r14d,%eax
   4481c:	shr    $0x8,%eax
   4481f:	lea    -0x374d4(%rip),%rcx        # d352 <hotaru_core::unicode::tables::STAGE1>
   44826:	movzbl %r14b,%edi
   4482a:	movzwl (%rcx,%rax,2),%eax
   4482e:	add    %rax,%rdi
   44831:	cmp    $0x7cff,%rdi
   44838:	ja     458b9 <hotaru_core::screen::State::print_utf8+0x16d9>
   4483e:	lea    -0x352f3(%rip),%rax        # f552 <hotaru_core::unicode::tables::STAGE2>
   44845:	movzwl (%rax,%rdi,2),%edi
   44849:	cmp    $0x1e,%rdi
   4484d:	ja     458ab <hotaru_core::screen::State::print_utf8+0x16cb>
   44853:	lea    -0x37546(%rip),%rax        # d314 <hotaru_core::unicode::tables::PROPERTIES>
   4485a:	movzwl (%rax,%rdi,2),%ebp
   4485e:	and    $0x3,%ebp
   44861:	test   %rbp,%rbp
   44864:	je     44f4a <hotaru_core::screen::State::print_utf8+0xd6a>
   4486a:	testb  $0x1,0x8(%rsp)
   4486f:	jne    44f4a <hotaru_core::screen::State::print_utf8+0xd6a>
   44875:	mov    0x58(%rsp),%rcx
   4487a:	lea    0x0(%rbp,%r15,1),%rax
   4487f:	cmp    0xf0(%rcx),%rax
   44886:	ja     44f40 <hotaru_core::screen::State::print_utf8+0xd60>
   4488c:	movzbl 0x2f(%rsp),%edx
   44891:	mov    0x48(%rsp),%rdi
   44896:	mov    %r15,%rsi
   44899:	mov    %r14d,%ecx
   4489c:	vzeroupper
   4489f:	call   43f50 <hotaru_core::screen::unicode_batch_boundary>
   448a4:	mov    0x40(%rsp),%r15
   448a9:	test   %al,%al
   448ab:	je     44f40 <hotaru_core::screen::State::print_utf8+0xd60>
   448b1:	test   %r15,%r15
   448b4:	je     448e0 <hotaru_core::screen::State::print_utf8+0x700>
   448b6:	mov    0x20(%rsp),%rax
   448bb:	mov    0x18(%rax),%rsi
   448bf:	cmp    %rsi,%r15
   448c2:	jae    458e3 <hotaru_core::screen::State::print_utf8+0x1703>
   448c8:	mov    0x10(%rax),%rax
   448cc:	cmpb   $0x0,0x6(%rax,%r15,8)
   448d2:	sete   %al
   448d5:	mov    %eax,0x54(%rsp)
   448d9:	jmp    448e8 <hotaru_core::screen::State::print_utf8+0x708>
   448db:	nopl   0x0(%rax,%rax,1)
   448e0:	movl   $0x0,0x54(%rsp)
   448e8:	vmovdqa 0x130(%rsp),%xmm0
   448f1:	movzwl 0x74(%rsp),%eax
   448f6:	lea    0xc0(%rsp),%rcx
   448fe:	vmovq  %xmm0,0xb8(%rsp)
   44907:	mov    %ax,0x4(%rcx)
   4490b:	mov    0x70(%rsp),%eax
   4490f:	mov    %eax,(%rcx)
   44911:	mov    0x48(%rsp),%rdi
   44916:	lea    0xb8(%rsp),%rsi
   4491e:	call   41bc0 <hotaru_core::row::Row::style_id>
   44923:	mov    0x40(%rsp),%r15
   44928:	jmp    4495a <hotaru_core::screen::State::print_utf8+0x77a>
   4492a:	nopw   0x0(%rax,%rax,1)
   44930:	lea    -0xa0(%r14),%ecx
   44937:	xor    %ebp,%ebp
   44939:	cmp    $0xffffffe0,%ecx
   4493c:	setb   %bpl
   44940:	test   %rbp,%rbp
   44943:	je     44eb4 <hotaru_core::screen::State::print_utf8+0xcd4>
   44949:	lea    0x0(%rbp,%r15,1),%rdx
   4494e:	mov    %r14d,%ecx
   44951:	cmp    %rbx,%rdx
   44954:	ja     44eb7 <hotaru_core::screen::State::print_utf8+0xcd7>
   4495a:	mov    %r14d,%r12d
   4495d:	cmp    $0x110001,%r14d
   44964:	jne    449a0 <hotaru_core::screen::State::print_utf8+0x7c0>
   44966:	mov    0x10(%rsp),%rdx
   4496b:	mov    0x20(%rsp),%rdi
   44970:	cmp    0x38(%rsp),%rdx
   44975:	je     449d0 <hotaru_core::screen::State::print_utf8+0x7f0>
   44977:	movzbl (%rdx),%ecx
   4497a:	test   %cl,%cl
   4497c:	js     449b1 <hotaru_core::screen::State::print_utf8+0x7d1>
   4497e:	inc    %rdx
   44981:	mov    %rdx,0x10(%rsp)
   44986:	mov    0x18(%rdi),%rsi
   4498a:	cmp    $0x2,%r15
   4498e:	jb     449da <hotaru_core::screen::State::print_utf8+0x7fa>
   44990:	xor    %ecx,%ecx
   44992:	jmp    449fc <hotaru_core::screen::State::print_utf8+0x81c>
   44994:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   449a0:	mov    0x20(%rsp),%rdi
   449a5:	mov    0x18(%rdi),%rsi
   449a9:	cmp    $0x2,%r15
   449ad:	jb     449da <hotaru_core::screen::State::print_utf8+0x7fa>
   449af:	jmp    44990 <hotaru_core::screen::State::print_utf8+0x7b0>
   449b1:	cmp    $0xe0,%cl
   449b4:	jb     44dc7 <hotaru_core::screen::State::print_utf8+0xbe7>
   449ba:	mov    0x10(%rsp),%rdx
   449bf:	cmp    $0xf0,%cl
   449c2:	sbb    $0xffffffffffffffff,%rdx
   449c6:	add    $0x3,%rdx
   449ca:	mov    %rdx,0x10(%rsp)
   449cf:	nop
   449d0:	mov    0x18(%rdi),%rsi
   449d4:	cmp    $0x2,%r15
   449d8:	jae    44990 <hotaru_core::screen::State::print_utf8+0x7b0>
   449da:	cmp    %rsi,%r15
   449dd:	jae    45882 <hotaru_core::screen::State::print_utf8+0x16a2>
   449e3:	mov    0x10(%rdi),%rcx
   449e7:	movzbl 0x6(%rcx,%r15,8),%ecx
   449ed:	cmp    $0x1,%rcx
   449f1:	setne  %dl
   449f4:	cmp    %rcx,%rbp
   449f7:	setne  %cl
   449fa:	and    %dl,%cl
   449fc:	cmp    %rsi,%r15
   449ff:	jae    4586d <hotaru_core::screen::State::print_utf8+0x168d>
   44a05:	mov    0x10(%rdi),%rdx
   44a09:	movzbl 0x30(%rsp),%esi
   44a0e:	mov    %r12d,(%rdx,%r15,8)
   44a12:	mov    %ax,0x4(%rdx,%r15,8)
   44a18:	mov    %bpl,0x6(%rdx,%r15,8)
   44a1d:	mov    %sil,0x7(%rdx,%r15,8)
   44a22:	cmp    $0x2,%rbp
   44a26:	jne    44a5c <hotaru_core::screen::State::print_utf8+0x87c>
   44a28:	mov    0x18(%rdi),%rsi
   44a2c:	lea    0x1(%r15),%rdx
   44a30:	cmp    %rsi,%rdx
   44a33:	jae    45876 <hotaru_core::screen::State::print_utf8+0x1696>
   44a39:	mov    0x10(%rdi),%rdx
   44a3d:	movzbl 0x30(%rsp),%esi
   44a42:	movl   $0x20,0x8(%rdx,%r15,8)
   44a4b:	mov    %ax,0xc(%rdx,%r15,8)
   44a51:	movb   $0x0,0xe(%rdx,%r15,8)
   44a57:	mov    %sil,0xf(%rdx,%r15,8)
   44a5c:	mov    0x58(%rsp),%rdx
   44a61:	or     %cl,%r13b
   44a64:	add    %rbp,%r15
   44a67:	mov    0xf0(%rdx),%rbx
   44a6e:	cmp    %rbx,%r15
   44a71:	je     44ea0 <hotaru_core::screen::State::print_utf8+0xcc0>
   44a77:	mov    0x10(%rsp),%r8
   44a7c:	mov    $0x110000,%ecx
   44a81:	cmp    0x38(%rsp),%r8
   44a86:	je     44eb7 <hotaru_core::screen::State::print_utf8+0xcd7>
   44a8c:	movzbl (%r8),%r14d
   44a90:	test   %r14b,%r14b
   44a93:	js     44b90 <hotaru_core::screen::State::print_utf8+0x9b0>
   44a99:	inc    %r8
   44a9c:	mov    %r8,0x10(%rsp)
   44aa1:	cmpb   $0x0,0xf(%rsp)
   44aa6:	jne    44c0b <hotaru_core::screen::State::print_utf8+0xa2b>
   44aac:	cmp    $0x100,%r14d
   44ab3:	jb     44930 <hotaru_core::screen::State::print_utf8+0x750>
   44ab9:	vpbroadcastd %r14d,%xmm0
   44abf:	vpaddd -0x3bd87(%rip),%xmm0,%xmm0        # 8d40 <anon.58baeeae7d5fe476157d296c9f08f803.346.llvm.5844774155465566772+0x1d0>
   44ac7:	mov    $0x2,%ebp
   44acc:	vpcmpltud -0x3bf77(%rip),%xmm0,%k0        # 8b60 <anon.eb89d4395b0ead844ef0b45b8b54da85.151.llvm.3643936799275306673+0x1f2>
   44ad7:	kortestb %k0,%k0
   44adb:	jne    44949 <hotaru_core::screen::State::print_utf8+0x769>
   44ae1:	mov    0x5e400(%rip),%rdx        # a2ee8 <_DYNAMIC+0x5b8>
   44ae8:	mov    %r14d,%ecx
   44aeb:	shr    $0xd,%ecx
   44aee:	movzbl (%rdx,%rcx,1),%ecx
   44af2:	mov    $0x607,%edx
   44af7:	bextr  %edx,%r14d,%edx
   44afc:	shl    $0x6,%ecx
   44aff:	add    0x5e3ea(%rip),%rcx        # a2ef0 <_DYNAMIC+0x5c0>
   44b06:	movzbl (%rdx,%rcx,1),%edi
   44b0a:	cmp    $0xbb,%rdi
   44b11:	ja     458c7 <hotaru_core::screen::State::print_utf8+0x16e7>
   44b17:	shl    $0x5,%edi
   44b1a:	add    0x5e3d7(%rip),%rdi        # a2ef8 <_DYNAMIC+0x5c8>
   44b21:	mov    $0x502,%edx
   44b26:	mov    %r14d,%ecx
   44b29:	bextr  %edx,%ecx,%ecx
   44b2e:	movzbl (%rcx,%rdi,1),%edx
   44b32:	lea    (%r14,%r14,1),%ecx
   44b36:	and    $0x6,%cl
   44b39:	shr    %cl,%dl
   44b3b:	and    $0x3,%dl
   44b3e:	cmp    $0x3,%dl
   44b41:	jne    44e7e <hotaru_core::screen::State::print_utf8+0xc9e>
   44b47:	mov    $0x1,%dl
   44b49:	cmp    $0xfe00,%r14d
   44b50:	jg     44e01 <hotaru_core::screen::State::print_utf8+0xc21>
   44b56:	cmp    $0x5dc,%r14d
   44b5d:	je     44e7e <hotaru_core::screen::State::print_utf8+0xc9e>
   44b63:	cmp    $0x17d8,%r14d
   44b6a:	je     44e6e <hotaru_core::screen::State::print_utf8+0xc8e>
   44b70:	cmp    $0x1a10,%r14d
   44b77:	je     44e7e <hotaru_core::screen::State::print_utf8+0xc9e>
   44b7d:	jmp    44e22 <hotaru_core::screen::State::print_utf8+0xc42>
   44b82:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   44b90:	movzbl 0x1(%r8),%edi
   44b95:	mov    %r14d,%edx
   44b98:	and    $0x1f,%edx
   44b9b:	and    $0x3f,%edi
   44b9e:	cmp    $0xdf,%r14b
   44ba2:	jbe    44bea <hotaru_core::screen::State::print_utf8+0xa0a>
   44ba4:	movzbl 0x2(%r8),%esi
   44ba9:	shl    $0x6,%edi
   44bac:	and    $0x3f,%esi
   44baf:	or     %edi,%esi
   44bb1:	cmp    $0xef,%r14b
   44bb5:	jbe    44de0 <hotaru_core::screen::State::print_utf8+0xc00>
   44bbb:	movzbl 0x3(%r8),%r14d
   44bc0:	and    $0x7,%edx
   44bc3:	shl    $0x6,%esi
   44bc6:	add    $0x4,%r8
   44bca:	shl    $0x12,%edx
   44bcd:	mov    %r8,0x10(%rsp)
   44bd2:	and    $0x3f,%r14d
   44bd6:	or     %esi,%r14d
   44bd9:	or     %edx,%r14d
   44bdc:	cmp    $0x110000,%r14d
   44be3:	jne    44c00 <hotaru_core::screen::State::print_utf8+0xa20>
   44be5:	jmp    44eb7 <hotaru_core::screen::State::print_utf8+0xcd7>
   44bea:	shl    $0x6,%edx
   44bed:	add    $0x2,%r8
   44bf1:	or     %edi,%edx
   44bf3:	mov    %r8,0x10(%rsp)
   44bf8:	mov    %edx,%r14d
   44bfb:	nopl   0x0(%rax,%rax,1)
   44c00:	cmpb   $0x0,0xf(%rsp)
   44c05:	je     44aac <hotaru_core::screen::State::print_utf8+0x8cc>
   44c0b:	cmp    $0x100,%r14d
   44c12:	jb     44930 <hotaru_core::screen::State::print_utf8+0x750>
   44c18:	lea    -0x3400(%r12),%ecx
   44c20:	lea    -0x4e00(%r12),%edx
   44c28:	cmp    $0x19c0,%ecx
   44c2e:	setb   %cl
   44c31:	cmp    $0x5200,%edx
   44c37:	setb   %dl
   44c3a:	or     %cl,%dl
   44c3c:	lea    -0xf900(%r12),%ecx
   44c44:	cmp    $0x200,%ecx
   44c4a:	setb   %cl
   44c4d:	or     %dl,%cl
   44c4f:	je     44c90 <hotaru_core::screen::State::print_utf8+0xab0>
   44c51:	lea    -0x3400(%r14),%ecx
   44c58:	lea    -0x4e00(%r14),%edx
   44c5f:	cmp    $0x19c0,%ecx
   44c65:	setb   %sil
   44c69:	cmp    $0x5200,%edx
   44c6f:	setb   %dil
   44c73:	or     %sil,%dil
   44c76:	lea    -0xf900(%r14),%esi
   44c7d:	cmp    $0x200,%esi
   44c83:	setb   %r8b
   44c87:	or     %dil,%r8b
   44c8a:	jne    44d50 <hotaru_core::screen::State::print_utf8+0xb70>
   44c90:	mov    %r12d,%ecx
   44c93:	shr    $0x8,%ecx
   44c96:	lea    -0x3794b(%rip),%rdx        # d352 <hotaru_core::unicode::tables::STAGE1>
   44c9d:	movzbl %r12b,%edi
   44ca1:	mov    $0x7d00,%esi
   44ca6:	movzwl (%rdx,%rcx,2),%ecx
   44caa:	add    %rcx,%rdi
   44cad:	cmp    $0x7cff,%rdi
   44cb4:	ja     4589f <hotaru_core::screen::State::print_utf8+0x16bf>
   44cba:	lea    -0x3576f(%rip),%rcx        # f552 <hotaru_core::unicode::tables::STAGE2>
   44cc1:	movzwl (%rcx,%rdi,2),%edi
   44cc5:	cmp    $0x1e,%rdi
   44cc9:	ja     458ab <hotaru_core::screen::State::print_utf8+0x16cb>
   44ccf:	mov    %r14d,%ecx
   44cd2:	shr    $0x8,%ecx
   44cd5:	lea    -0x3798a(%rip),%rdx        # d352 <hotaru_core::unicode::tables::STAGE1>
   44cdc:	movzwl (%rdx,%rcx,2),%edx
   44ce0:	movzbl %r14b,%ecx
   44ce4:	add    %rdx,%rcx
   44ce7:	cmp    $0x7cff,%rcx
   44cee:	ja     4589c <hotaru_core::screen::State::print_utf8+0x16bc>
   44cf4:	lea    -0x357a9(%rip),%rdx        # f552 <hotaru_core::unicode::tables::STAGE2>
   44cfb:	movzwl (%rdx,%rcx,2),%ecx
   44cff:	cmp    $0x1f,%rcx
   44d03:	jae    458a8 <hotaru_core::screen::State::print_utf8+0x16c8>
   44d09:	lea    -0x379fc(%rip),%rsi        # d314 <hotaru_core::unicode::tables::PROPERTIES>
   44d10:	movzwl (%rsi,%rcx,2),%ecx
   44d14:	movzwl (%rsi,%rdi,2),%edx
   44d18:	lea    -0x39c17(%rip),%rsi        # b108 <hotaru_core::unicode::BREAKS>
   44d1f:	shl    $0x5,%ecx
   44d22:	and    $0xf8,%edx
   44d28:	and    $0x1f00,%ecx
   44d2e:	or     %rcx,%rdx
   44d31:	testb  $0x1,(%rsi,%rdx,1)
   44d35:	je     44eb4 <hotaru_core::screen::State::print_utf8+0xcd4>
   44d3b:	lea    -0x3400(%r14),%ecx
   44d42:	lea    -0x4e00(%r14),%edx
   44d49:	lea    -0xf900(%r14),%esi
   44d50:	cmp    $0x19c0,%ecx
   44d56:	mov    $0x2,%ebp
   44d5b:	setb   %cl
   44d5e:	cmp    $0x5200,%edx
   44d64:	setb   %dl
   44d67:	or     %cl,%dl
   44d69:	cmp    $0x200,%esi
   44d6f:	setb   %cl
   44d72:	or     %dl,%cl
   44d74:	jne    44949 <hotaru_core::screen::State::print_utf8+0x769>
   44d7a:	mov    %r14d,%ecx
   44d7d:	shr    $0x8,%ecx
   44d80:	lea    -0x37a35(%rip),%rdx        # d352 <hotaru_core::unicode::tables::STAGE1>
   44d87:	movzbl %r14b,%edi
   44d8b:	movzwl (%rdx,%rcx,2),%ecx
   44d8f:	add    %rcx,%rdi
   44d92:	cmp    $0x7cff,%rdi
   44d99:	ja     458b9 <hotaru_core::screen::State::print_utf8+0x16d9>
   44d9f:	lea    -0x35854(%rip),%rcx        # f552 <hotaru_core::unicode::tables::STAGE2>
   44da6:	movzwl (%rcx,%rdi,2),%edi
   44daa:	cmp    $0x1f,%rdi
   44dae:	jae    458ab <hotaru_core::screen::State::print_utf8+0x16cb>
   44db4:	lea    -0x37aa7(%rip),%rcx        # d314 <hotaru_core::unicode::tables::PROPERTIES>
   44dbb:	movzwl (%rcx,%rdi,2),%ebp
   44dbf:	and    $0x3,%ebp
   44dc2:	jmp    44940 <hotaru_core::screen::State::print_utf8+0x760>
   44dc7:	addq   $0x2,0x10(%rsp)
   44dcd:	mov    0x18(%rdi),%rsi
   44dd1:	cmp    $0x2,%r15
   44dd5:	jb     449da <hotaru_core::screen::State::print_utf8+0x7fa>
   44ddb:	jmp    44990 <hotaru_core::screen::State::print_utf8+0x7b0>
   44de0:	shl    $0xc,%edx
   44de3:	add    $0x3,%r8
   44de7:	or     %edx,%esi
   44de9:	mov    %r8,0x10(%rsp)
   44dee:	mov    %esi,%r14d
   44df1:	cmpb   $0x0,0xf(%rsp)
   44df6:	jne    44c0b <hotaru_core::screen::State::print_utf8+0xa2b>
   44dfc:	jmp    44aac <hotaru_core::screen::State::print_utf8+0x8cc>
   44e01:	lea    -0xfe01(%r14),%ecx
   44e08:	cmp    $0xe,%ecx
   44e0b:	jbe    44e72 <hotaru_core::screen::State::print_utf8+0xc92>
   44e0d:	lea    -0x16d67(%r14),%ecx
   44e14:	cmp    $0x2,%ecx
   44e17:	jb     44e7e <hotaru_core::screen::State::print_utf8+0xc9e>
   44e19:	cmp    $0x10c03,%r14d
   44e20:	je     44e7e <hotaru_core::screen::State::print_utf8+0xc9e>
   44e22:	lea    -0x622(%r14),%ecx
   44e29:	lea    -0x1780(%r14),%edx
   44e30:	mov    %r14d,%esi
   44e33:	cmp    $0x261,%ecx
   44e39:	setb   %cl
   44e3c:	cmp    $0x30,%edx
   44e3f:	setb   %dl
   44e42:	or     %cl,%dl
   44e44:	lea    -0x2d31(%r14),%ecx
   44e4b:	cmp    $0x3f,%ecx
   44e4e:	setb   %cl
   44e51:	and    $0x1ffffe,%esi
   44e57:	cmp    $0xa4fc,%esi
   44e5d:	sete   %sil
   44e61:	or     %cl,%sil
   44e64:	or     %dl,%sil
   44e67:	mov    $0x2,%dl
   44e69:	sub    %sil,%dl
   44e6c:	jmp    44e7e <hotaru_core::screen::State::print_utf8+0xc9e>
   44e6e:	mov    $0x3,%dl
   44e70:	jmp    44e7e <hotaru_core::screen::State::print_utf8+0xc9e>
   44e72:	mov    $0x6001,%esi
   44e77:	bt     %ecx,%esi
   44e7a:	jae    44e0d <hotaru_core::screen::State::print_utf8+0xc2d>
   44e7c:	xor    %edx,%edx
   44e7e:	movzbl %dl,%ecx
   44e81:	mov    $0x2,%edx
   44e86:	cmp    $0x2,%cl
   44e89:	cmovae %edx,%ecx
   44e8c:	movzbl %cl,%ebp
   44e8f:	jmp    44940 <hotaru_core::screen::State::print_utf8+0x760>
   44e94:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   44ea0:	mov    %r15,%rbx
   44ea3:	mov    $0x1,%al
   44ea5:	dec    %r15
   44ea8:	mov    $0x110001,%r14d
   44eae:	mov    %eax,0x8(%rsp)
   44eb2:	jmp    44ec3 <hotaru_core::screen::State::print_utf8+0xce3>
   44eb4:	mov    %r14d,%ecx
   44eb7:	testb  $0x1,0x8(%rsp)
   44ebc:	mov    %ecx,%r14d
   44ebf:	cmove  %r15,%rbx
   44ec3:	movzbl 0x54(%rsp),%ecx
   44ec8:	mov    0x48(%rsp),%rdi
   44ecd:	mov    0x40(%rsp),%rsi
   44ed2:	mov    0x9c(%rsp),%r8d
   44eda:	mov    %rbx,%rdx
   44edd:	call   40860 <hotaru_core::row::Row::prepare_write_with_left>
   44ee2:	cmpq   $0x0,0x18(%rsp)
   44ee8:	je     446d0 <hotaru_core::screen::State::print_utf8+0x4f0>
   44eee:	mov    0x48(%rsp),%rdi
   44ef3:	mov    0x40(%rsp),%rsi
   44ef8:	lea    0x60(%rsp),%rcx
   44efd:	mov    %rbx,%rdx
   44f00:	call   40540 <hotaru_core::row::Row::set_hyperlink_range>
   44f05:	jmp    446d0 <hotaru_core::screen::State::print_utf8+0x4f0>
   44f0a:	shl    $0x6,%eax
   44f0d:	add    $0x2,%rsi
   44f11:	or     %edx,%eax
   44f13:	mov    %rsi,0x10(%rsp)
   44f18:	mov    %eax,%r14d
   44f1b:	jmp    4475d <hotaru_core::screen::State::print_utf8+0x57d>
   44f20:	shl    $0xc,%eax
   44f23:	add    $0x3,%rsi
   44f27:	or     %eax,%ecx
   44f29:	mov    %rsi,0x10(%rsp)
   44f2e:	mov    %ecx,%r14d
   44f31:	jmp    4475d <hotaru_core::screen::State::print_utf8+0x57d>
   44f36:	cs nopw 0x0(%rax,%rax,1)
   44f40:	xor    %eax,%eax
   44f42:	jmp    44f4e <hotaru_core::screen::State::print_utf8+0xd6e>
   44f44:	mov    $0x110000,%r14d
   44f4a:	mov    0x8(%rsp),%eax
   44f4e:	mov    0x58(%rsp),%rbx
   44f53:	mov    %r15,0x90(%rbx)
   44f5a:	mov    %al,0x12f(%rbx)
   44f60:	test   $0x1,%r13b
   44f64:	je     44f71 <hotaru_core::screen::State::print_utf8+0xd91>
   44f66:	mov    %rbx,%rdi
   44f69:	vzeroupper
   44f6c:	call   49020 <hotaru_core::screen::Screen::clear_previous_spacer>
   44f71:	mov    %rbx,%rdi
   44f74:	vzeroupper
   44f77:	call   48f00 <hotaru_core::screen::Screen::enforce_budget>
   44f7c:	mov    0x88(%rsp),%rdi
   44f84:	cmp    $0x110000,%r12d
   44f8b:	je     44f94 <hotaru_core::screen::State::print_utf8+0xdb4>
   44f8d:	mov    %r12d,0x6d0(%rdi)
   44f94:	cmp    $0x110000,%r14d
   44f9b:	je     45769 <hotaru_core::screen::State::print_utf8+0x1589>
   44fa1:	cmp    $0x110001,%r14d
   44fa8:	jne    45760 <hotaru_core::screen::State::print_utf8+0x1580>
   44fae:	mov    0x10(%rsp),%rsi
   44fb3:	cmp    0x38(%rsp),%rsi
   44fb8:	je     45769 <hotaru_core::screen::State::print_utf8+0x1589>
   44fbe:	movzbl (%rsi),%r14d
   44fc2:	test   %r14b,%r14b
   44fc5:	js     450bd <hotaru_core::screen::State::print_utf8+0xedd>
   44fcb:	inc    %rsi
   44fce:	mov    %rsi,0x10(%rsp)
   44fd3:	jmp    45760 <hotaru_core::screen::State::print_utf8+0x1580>
   44fd8:	lea    0x8(%r13),%rsi
   44fdc:	lea    0xc0(%rsp),%rdi
   44fe4:	call   *0x5df1e(%rip)        # a2f08 <_DYNAMIC+0x5d8>
   44fea:	mov    $0x78,%edi
   44fef:	movq   $0x1,0xb8(%rsp)
   44ffb:	call   *0x5db17(%rip)        # a2b18 <malloc@GLIBC_2.2.5>
   45001:	test   %rax,%rax
   45004:	je     45858 <hotaru_core::screen::State::print_utf8+0x1678>
   4500a:	vmovups 0xf0(%rsp),%zmm1
   45015:	vmovdqu64 0xb8(%rsp),%zmm0
   45020:	lea    (%r12,%r15,8),%r15
   45024:	mov    %rax,%r12
   45027:	vmovups %zmm1,0x38(%rax)
   45031:	vmovdqu64 %zmm0,(%rax)
   45037:	lock decq 0x0(%r13)
   4503c:	jne    4504a <hotaru_core::screen::State::print_utf8+0xe6a>
   4503e:	mov    %r15,%rdi
   45041:	vzeroupper
   45044:	call   *0x5dec6(%rip)        # a2f10 <_DYNAMIC+0x5e0>
   4504a:	mov    %r12,(%r15)
   4504d:	mov    %rbp,%r15
   45050:	cmp    $0x110001,%r14d
   45057:	je     444e1 <hotaru_core::screen::State::print_utf8+0x301>
   4505d:	mov    %r14d,%edi
   45060:	cmp    $0x110000,%r14d
   45067:	mov    $0x110000,%r14d
   4506d:	je     45219 <hotaru_core::screen::State::print_utf8+0x1039>
   45073:	cmpb   $0x0,0x58(%rsp)
   45078:	lea    0x8(%r12),%r14
   4507d:	mov    %rdi,0x20(%rsp)
   45082:	je     4451a <hotaru_core::screen::State::print_utf8+0x33a>
   45088:	cmp    $0x100,%edi
   4508e:	jae    4511e <hotaru_core::screen::State::print_utf8+0xf3e>
   45094:	lea    -0xa0(%rdi),%eax
   4509a:	xor    %r13d,%r13d
   4509d:	cmp    $0xffffffe0,%eax
   450a0:	setb   %r13b
   450a4:	test   %r13,%r13
   450a7:	jne    451a7 <hotaru_core::screen::State::print_utf8+0xfc7>
   450ad:	jmp    45214 <hotaru_core::screen::State::print_utf8+0x1034>
   450b2:	mov    $0x110000,%r14d
   450b8:	jmp    45219 <hotaru_core::screen::State::print_utf8+0x1039>
   450bd:	movzbl 0x1(%rsi),%edx
   450c1:	mov    %r14d,%eax
   450c4:	and    $0x1f,%eax
   450c7:	and    $0x3f,%edx
   450ca:	cmp    $0xdf,%r14b
   450ce:	jbe    45381 <hotaru_core::screen::State::print_utf8+0x11a1>
   450d4:	movzbl 0x2(%rsi),%ecx
   450d8:	shl    $0x6,%edx
   450db:	and    $0x3f,%ecx
   450de:	or     %edx,%ecx
   450e0:	cmp    $0xf0,%r14b
   450e4:	jb     4574a <hotaru_core::screen::State::print_utf8+0x156a>
   450ea:	movzbl 0x3(%rsi),%r14d
   450ef:	and    $0x7,%eax
   450f2:	shl    $0x6,%ecx
   450f5:	add    $0x4,%rsi
   450f9:	shl    $0x12,%eax
   450fc:	mov    %rsi,0x10(%rsp)
   45101:	and    $0x3f,%r14d
   45105:	or     %ecx,%r14d
   45108:	or     %eax,%r14d
   4510b:	jmp    45760 <hotaru_core::screen::State::print_utf8+0x1580>
   45110:	mov    0x8(%rsp),%eax
   45114:	mov    0x40(%rsp),%r15
   45119:	jmp    44f4e <hotaru_core::screen::State::print_utf8+0xd6e>
   4511e:	lea    -0x3400(%rdi),%eax
   45124:	lea    -0x4e00(%rdi),%ecx
   4512a:	mov    $0x2,%r13d
   45130:	cmp    $0x19c0,%eax
   45135:	setb   %al
   45138:	cmp    $0x5200,%ecx
   4513e:	setb   %cl
   45141:	or     %al,%cl
   45143:	lea    -0xf900(%rdi),%eax
   45149:	cmp    $0x200,%eax
   4514e:	setb   %al
   45151:	or     %cl,%al
   45153:	jne    451a7 <hotaru_core::screen::State::print_utf8+0xfc7>
   45155:	mov    0x20(%rsp),%rdx
   4515a:	lea    -0x37e0f(%rip),%rcx        # d352 <hotaru_core::unicode::tables::STAGE1>
   45161:	mov    %edx,%eax
   45163:	shr    $0x8,%eax
   45166:	movzbl %dl,%edi
   45169:	movzwl (%rcx,%rax,2),%eax
   4516d:	add    %rax,%rdi
   45170:	cmp    $0x7cff,%rdi
   45177:	ja     45918 <hotaru_core::screen::State::print_utf8+0x1738>
   4517d:	lea    -0x35c32(%rip),%rax        # f552 <hotaru_core::unicode::tables::STAGE2>
   45184:	movzwl (%rax,%rdi,2),%edi
   45188:	cmp    $0x1e,%rdi
   4518c:	ja     4591f <hotaru_core::screen::State::print_utf8+0x173f>
   45192:	lea    -0x37e85(%rip),%rax        # d314 <hotaru_core::unicode::tables::PROPERTIES>
   45199:	movzwl (%rax,%rdi,2),%r13d
   4519e:	and    $0x3,%r13d
   451a2:	test   %r13,%r13
   451a5:	je     45214 <hotaru_core::screen::State::print_utf8+0x1034>
   451a7:	mov    0xf0(%rbx),%rcx
   451ae:	lea    0x0(%r13,%r15,1),%rax
   451b3:	mov    %rcx,0x40(%rsp)
   451b8:	cmp    %rcx,%rax
   451bb:	ja     45214 <hotaru_core::screen::State::print_utf8+0x1034>
   451bd:	movzbl 0xf(%rsp),%edx
   451c2:	mov    0x20(%rsp),%rcx
   451c7:	mov    %r14,%rdi
   451ca:	mov    %r15,%rsi
   451cd:	vzeroupper
   451d0:	call   43f50 <hotaru_core::screen::unicode_batch_boundary>
   451d5:	test   %al,%al
   451d7:	je     45214 <hotaru_core::screen::State::print_utf8+0x1034>
   451d9:	cmp    $0x1,%r15
   451dd:	ja     45397 <hotaru_core::screen::State::print_utf8+0x11b7>
   451e3:	mov    0x18(%r12),%rsi
   451e8:	cmp    %rsi,%r15
   451eb:	jae    45901 <hotaru_core::screen::State::print_utf8+0x1721>
   451f1:	mov    0x10(%r12),%rax
   451f6:	movzbl 0x6(%rax,%r15,8),%eax
   451fc:	cmp    $0x1,%rax
   45200:	setne  %cl
   45203:	cmp    %eax,%r13d
   45206:	setne  %al
   45209:	and    %cl,%al
   4520b:	mov    %eax,0x8(%rsp)
   4520f:	jmp    4539f <hotaru_core::screen::State::print_utf8+0x11bf>
   45214:	mov    0x20(%rsp),%r14
   45219:	mov    %r15,0x90(%rbx)
   45220:	mov    $0x110000,%r12d
   45226:	mov    %rbx,%rdi
   45229:	vzeroupper
   4522c:	call   48f00 <hotaru_core::screen::Screen::enforce_budget>
   45231:	mov    0x88(%rsp),%r15
   45239:	cmp    $0x110000,%r12d
   45240:	je     45249 <hotaru_core::screen::State::print_utf8+0x1069>
   45242:	mov    %r12d,0x6d0(%r15)
   45249:	mov    0x30(%rsp),%rax
   4524e:	test   %rax,%rax
   45251:	je     45270 <hotaru_core::screen::State::print_utf8+0x1090>
   45253:	lock decq (%rax)
   45257:	jne    45270 <hotaru_core::screen::State::print_utf8+0x1090>
   45259:	lea    0x78(%rsp),%rdi
   4525e:	call   *0x5dc5c(%rip)        # a2ec0 <_DYNAMIC+0x590>
   45264:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   45270:	cmp    $0x110000,%r14d
   45277:	je     44348 <hotaru_core::screen::State::print_utf8+0x168>
   4527d:	cmp    $0x110001,%r14d
   45284:	jne    45720 <hotaru_core::screen::State::print_utf8+0x1540>
   4528a:	mov    0x10(%rsp),%rsi
   4528f:	cmp    0x38(%rsp),%rsi
   45294:	je     44348 <hotaru_core::screen::State::print_utf8+0x168>
   4529a:	movzbl (%rsi),%r14d
   4529e:	test   %r14b,%r14b
   452a1:	js     452b0 <hotaru_core::screen::State::print_utf8+0x10d0>
   452a3:	inc    %rsi
   452a6:	mov    %rsi,0x10(%rsp)
   452ab:	jmp    45720 <hotaru_core::screen::State::print_utf8+0x1540>
   452b0:	movzbl 0x1(%rsi),%edx
   452b4:	mov    %r14d,%eax
   452b7:	and    $0x1f,%eax
   452ba:	and    $0x3f,%edx
   452bd:	cmp    $0xdf,%r14b
   452c1:	jbe    4536b <hotaru_core::screen::State::print_utf8+0x118b>
   452c7:	movzbl 0x2(%rsi),%ecx
   452cb:	shl    $0x6,%edx
   452ce:	and    $0x3f,%ecx
   452d1:	or     %edx,%ecx
   452d3:	cmp    $0xf0,%r14b
   452d7:	jb     45707 <hotaru_core::screen::State::print_utf8+0x1527>
   452dd:	movzbl 0x3(%rsi),%r14d
   452e2:	and    $0x7,%eax
   452e5:	shl    $0x6,%ecx
   452e8:	add    $0x4,%rsi
   452ec:	shl    $0x12,%eax
   452ef:	mov    %rsi,0x10(%rsp)
   452f4:	and    $0x3f,%r14d
   452f8:	or     %ecx,%r14d
   452fb:	or     %eax,%r14d
   452fe:	jmp    45720 <hotaru_core::screen::State::print_utf8+0x1540>
   45303:	movzbl 0x1(%rsi),%edx
   45307:	mov    %edi,%eax
   45309:	and    $0x1f,%eax
   4530c:	and    $0x3f,%edx
   4530f:	cmp    $0xe0,%dil
   45313:	jb     456dd <hotaru_core::screen::State::print_utf8+0x14fd>
   45319:	movzbl 0x2(%rsi),%ecx
   4531d:	shl    $0x6,%edx
   45320:	and    $0x3f,%ecx
   45323:	or     %edx,%ecx
   45325:	cmp    $0xf0,%dil
   45329:	jb     45791 <hotaru_core::screen::State::print_utf8+0x15b1>
   4532f:	movzbl 0x3(%rsi),%r14d
   45334:	and    $0x7,%eax
   45337:	shl    $0x6,%ecx
   4533a:	add    $0x4,%rsi
   4533e:	shl    $0x12,%eax
   45341:	mov    %rsi,0x10(%rsp)
   45346:	and    $0x3f,%r14d
   4534a:	or     %ecx,%r14d
   4534d:	or     %eax,%r14d
   45350:	mov    %r14d,%edi
   45353:	cmp    $0x110000,%r14d
   4535a:	mov    $0x110000,%r14d
   45360:	jne    45073 <hotaru_core::screen::State::print_utf8+0xe93>
   45366:	jmp    45219 <hotaru_core::screen::State::print_utf8+0x1039>
   4536b:	shl    $0x6,%eax
   4536e:	add    $0x2,%rsi
   45372:	or     %edx,%eax
   45374:	mov    %rsi,0x10(%rsp)
   45379:	mov    %eax,%r14d
   4537c:	jmp    45720 <hotaru_core::screen::State::print_utf8+0x1540>
   45381:	shl    $0x6,%eax
   45384:	add    $0x2,%rsi
   45388:	or     %edx,%eax
   4538a:	mov    %rsi,0x10(%rsp)
   4538f:	mov    %eax,%r14d
   45392:	jmp    45760 <hotaru_core::screen::State::print_utf8+0x1580>
   45397:	movl   $0x0,0x8(%rsp)
   4539f:	mov    0x60(%rsp),%rax
   453a4:	mov    0x66(%rsp),%rcx
   453a9:	mov    %rcx,0xbe(%rsp)
   453b1:	mov    %rax,0xb8(%rsp)
   453b9:	movzbl 0x48(%rsp),%r9d
   453bf:	lea    0xb8(%rsp),%r8
   453c7:	mov    0x20(%rsp),%rdx
   453cc:	mov    %r14,%rdi
   453cf:	mov    %r15,%rsi
   453d2:	mov    %r13,%rcx
   453d5:	mov    %r9d,0x54(%rsp)
   453da:	call   40ce0 <hotaru_core::row::Row::put>
   453df:	add    %r15,%r13
   453e2:	cmpq   $0x0,0x30(%rsp)
   453e8:	je     453fd <hotaru_core::screen::State::print_utf8+0x121d>
   453ea:	lea    0x78(%rsp),%rcx
   453ef:	mov    %r14,%rdi
   453f2:	mov    %r15,%rsi
   453f5:	mov    %r13,%rdx
   453f8:	call   40540 <hotaru_core::row::Row::set_hyperlink_range>
   453fd:	cmp    0x40(%rsp),%r13
   45402:	jne    4543e <hotaru_core::screen::State::print_utf8+0x125e>
   45404:	mov    0x40(%rsp),%r13
   45409:	mov    0x8(%rsp),%eax
   4540d:	movb   $0x1,0x12f(%rbx)
   45414:	mov    $0x110001,%r14d
   4541a:	dec    %r13
   4541d:	mov    %r13,0x90(%rbx)
   45424:	test   $0x1,%al
   45426:	je     457e5 <hotaru_core::screen::State::print_utf8+0x1605>
   4542c:	mov    %rbx,%rdi
   4542f:	call   49020 <hotaru_core::screen::Screen::clear_previous_spacer>
   45434:	mov    0x20(%rsp),%r12
   45439:	jmp    45226 <hotaru_core::screen::State::print_utf8+0x1046>
   4543e:	mov    0x10(%rsp),%rsi
   45443:	mov    %r14,0x48(%rsp)
   45448:	mov    $0x110000,%r14d
   4544e:	mov    %r12,0x18(%rsp)
   45453:	cmp    0x38(%rsp),%rsi
   45458:	je     457d2 <hotaru_core::screen::State::print_utf8+0x15f2>
   4545e:	xchg   %ax,%ax
   45460:	movzbl (%rsi),%ebp
   45463:	test   %bpl,%bpl
   45466:	js     454a4 <hotaru_core::screen::State::print_utf8+0x12c4>
   45468:	inc    %rsi
   4546b:	mov    %rsi,0x10(%rsp)
   45470:	cmpb   $0x0,0x58(%rsp)
   45475:	jne    4551b <hotaru_core::screen::State::print_utf8+0x133b>
   4547b:	mov    %ebp,%edi
   4547d:	call   43800 <hotaru_core::screen::char_width>
   45482:	mov    %rax,%r15
   45485:	test   %rax,%rax
   45488:	je     457bb <hotaru_core::screen::State::print_utf8+0x15db>
   4548e:	mov    %r15,%rax
   45491:	add    %r13,%rax
   45494:	cmp    0x40(%rsp),%rax
   45499:	jbe    455f5 <hotaru_core::screen::State::print_utf8+0x1415>
   4549f:	jmp    457bb <hotaru_core::screen::State::print_utf8+0x15db>
   454a4:	movzbl 0x1(%rsi),%edx
   454a8:	mov    %ebp,%eax
   454aa:	and    $0x1f,%eax
   454ad:	and    $0x3f,%edx
   454b0:	cmp    $0xdf,%bpl
   454b4:	jbe    454f6 <hotaru_core::screen::State::print_utf8+0x1316>
   454b6:	movzbl 0x2(%rsi),%ecx
   454ba:	shl    $0x6,%edx
   454bd:	and    $0x3f,%ecx
   454c0:	or     %edx,%ecx
   454c2:	cmp    $0xf0,%bpl
   454c6:	jb     456bd <hotaru_core::screen::State::print_utf8+0x14dd>
   454cc:	movzbl 0x3(%rsi),%ebp
   454d0:	and    $0x7,%eax
   454d3:	shl    $0x6,%ecx
   454d6:	add    $0x4,%rsi
   454da:	shl    $0x12,%eax
   454dd:	mov    %rsi,0x10(%rsp)
   454e2:	and    $0x3f,%ebp
   454e5:	or     %ecx,%ebp
   454e7:	or     %eax,%ebp
   454e9:	cmp    $0x110000,%ebp
   454ef:	jne    45510 <hotaru_core::screen::State::print_utf8+0x1330>
   454f1:	jmp    457d2 <hotaru_core::screen::State::print_utf8+0x15f2>
   454f6:	shl    $0x6,%eax
   454f9:	add    $0x2,%rsi
   454fd:	or     %edx,%eax
   454ff:	mov    %rsi,0x10(%rsp)
   45504:	mov    %eax,%ebp
   45506:	cs nopw 0x0(%rax,%rax,1)
   45510:	cmpb   $0x0,0x58(%rsp)
   45515:	je     4547b <hotaru_core::screen::State::print_utf8+0x129b>
   4551b:	cmp    $0x100,%ebp
   45521:	jae    45541 <hotaru_core::screen::State::print_utf8+0x1361>
   45523:	lea    -0xa0(%rbp),%eax
   45529:	xor    %r15d,%r15d
   4552c:	cmp    $0xffffffe0,%eax
   4552f:	setb   %r15b
   45533:	test   %r15,%r15
   45536:	jne    455ca <hotaru_core::screen::State::print_utf8+0x13ea>
   4553c:	jmp    457bb <hotaru_core::screen::State::print_utf8+0x15db>
   45541:	lea    -0x3400(%rbp),%eax
   45547:	lea    -0x4e00(%rbp),%ecx
   4554d:	mov    $0x2,%r15d
   45553:	cmp    $0x19c0,%eax
   45558:	setb   %al
   4555b:	cmp    $0x5200,%ecx
   45561:	setb   %cl
   45564:	or     %al,%cl
   45566:	lea    -0xf900(%rbp),%eax
   4556c:	cmp    $0x200,%eax
   45571:	setb   %al
   45574:	or     %cl,%al
   45576:	jne    455ca <hotaru_core::screen::State::print_utf8+0x13ea>
   45578:	mov    %ebp,%eax
   4557a:	shr    $0x8,%eax
   4557d:	lea    -0x38232(%rip),%rcx        # d352 <hotaru_core::unicode::tables::STAGE1>
   45584:	movzbl %bpl,%edi
   45588:	movzwl (%rcx,%rax,2),%eax
   4558c:	add    %rax,%rdi
   4558f:	cmp    $0x7cff,%rdi
   45596:	ja     45918 <hotaru_core::screen::State::print_utf8+0x1738>
   4559c:	lea    -0x36051(%rip),%rax        # f552 <hotaru_core::unicode::tables::STAGE2>
   455a3:	movzwl (%rax,%rdi,2),%edi
   455a7:	cmp    $0x1f,%rdi
   455ab:	jae    4591f <hotaru_core::screen::State::print_utf8+0x173f>
   455b1:	lea    -0x382a4(%rip),%rax        # d314 <hotaru_core::unicode::tables::PROPERTIES>
   455b8:	movzwl (%rax,%rdi,2),%r15d
   455bd:	and    $0x3,%r15d
   455c1:	test   %r15,%r15
   455c4:	je     457bb <hotaru_core::screen::State::print_utf8+0x15db>
   455ca:	lea    (%r15,%r13,1),%rax
   455ce:	cmp    0x40(%rsp),%rax
   455d3:	ja     457bb <hotaru_core::screen::State::print_utf8+0x15db>
   455d9:	movzbl 0xf(%rsp),%edx
   455de:	mov    0x48(%rsp),%rdi
   455e3:	mov    %r13,%rsi
   455e6:	mov    %ebp,%ecx
   455e8:	call   43f50 <hotaru_core::screen::unicode_batch_boundary>
   455ed:	test   %al,%al
   455ef:	je     457bb <hotaru_core::screen::State::print_utf8+0x15db>
   455f5:	cmp    $0x1,%r13
   455f9:	ja     4562a <hotaru_core::screen::State::print_utf8+0x144a>
   455fb:	mov    0x18(%rsp),%rax
   45600:	mov    0x18(%rax),%rsi
   45604:	cmp    %rsi,%r13
   45607:	jae    458fe <hotaru_core::screen::State::print_utf8+0x171e>
   4560d:	mov    0x10(%rax),%rax
   45611:	movzbl 0x6(%rax,%r13,8),%eax
   45617:	cmp    $0x1,%rax
   4561b:	setne  %cl
   4561e:	cmp    %eax,%r15d
   45621:	setne  %r12b
   45625:	and    %cl,%r12b
   45628:	jmp    4562d <hotaru_core::screen::State::print_utf8+0x144d>
   4562a:	xor    %r12d,%r12d
   4562d:	mov    0x60(%rsp),%rax
   45632:	mov    0x66(%rsp),%rcx
   45637:	mov    %rcx,0xbe(%rsp)
   4563f:	mov    %rax,0xb8(%rsp)
   45647:	mov    0x48(%rsp),%rdi
   4564c:	mov    0x54(%rsp),%r9d
   45651:	lea    0xb8(%rsp),%r8
   45659:	mov    %r13,%rsi
   4565c:	mov    %ebp,%edx
   4565e:	mov    %r15,%rcx
   45661:	call   40ce0 <hotaru_core::row::Row::put>
   45666:	add    %r13,%r15
   45669:	cmpq   $0x0,0x30(%rsp)
   4566f:	je     45686 <hotaru_core::screen::State::print_utf8+0x14a6>
   45671:	mov    0x48(%rsp),%rdi
   45676:	lea    0x78(%rsp),%rcx
   4567b:	mov    %r13,%rsi
   4567e:	mov    %r15,%rdx
   45681:	call   40540 <hotaru_core::row::Row::set_hyperlink_range>
   45686:	mov    0x8(%rsp),%eax
   4568a:	or     %r12b,%al
   4568d:	and    $0x1,%al
   4568f:	mov    %eax,0x8(%rsp)
   45693:	cmp    0x40(%rsp),%r15
   45698:	je     457c0 <hotaru_core::screen::State::print_utf8+0x15e0>
   4569e:	mov    0x10(%rsp),%rsi
   456a3:	mov    %ebp,%eax
   456a5:	mov    %r15,%r13
   456a8:	mov    %rax,0x20(%rsp)
   456ad:	cmp    0x38(%rsp),%rsi
   456b2:	jne    45460 <hotaru_core::screen::State::print_utf8+0x1280>
   456b8:	jmp    457ca <hotaru_core::screen::State::print_utf8+0x15ea>
   456bd:	shl    $0xc,%eax
   456c0:	add    $0x3,%rsi
   456c4:	or     %eax,%ecx
   456c6:	mov    %rsi,0x10(%rsp)
   456cb:	mov    %ecx,%ebp
   456cd:	cmpb   $0x0,0x58(%rsp)
   456d2:	jne    4551b <hotaru_core::screen::State::print_utf8+0x133b>
   456d8:	jmp    4547b <hotaru_core::screen::State::print_utf8+0x129b>
   456dd:	shl    $0x6,%eax
   456e0:	add    $0x2,%rsi
   456e4:	or     %edx,%eax
   456e6:	mov    %rsi,0x10(%rsp)
   456eb:	mov    %eax,%edi
   456ed:	cmpb   $0x0,0x58(%rsp)
   456f2:	lea    0x8(%r12),%r14
   456f7:	mov    %rdi,0x20(%rsp)
   456fc:	je     4451a <hotaru_core::screen::State::print_utf8+0x33a>
   45702:	jmp    45088 <hotaru_core::screen::State::print_utf8+0xea8>
   45707:	shl    $0xc,%eax
   4570a:	add    $0x3,%rsi
   4570e:	or     %eax,%ecx
   45710:	mov    %rsi,0x10(%rsp)
   45715:	mov    %ecx,%r14d
   45718:	nopl   0x0(%rax,%rax,1)
   45720:	mov    %r15,%rdi
   45723:	mov    %r14d,%esi
   45726:	call   *0x5d7d4(%rip)        # a2f00 <_DYNAMIC+0x5d0>
   4572c:	cmpb   $0x0,0x6df(%r15)
   45734:	mov    %r15,%rdi
   45737:	cmovne 0x90(%rsp),%rdi
   45740:	call   48f00 <hotaru_core::screen::Screen::enforce_budget>
   45745:	jmp    44348 <hotaru_core::screen::State::print_utf8+0x168>
   4574a:	shl    $0xc,%eax
   4574d:	add    $0x3,%rsi
   45751:	or     %eax,%ecx
   45753:	mov    %rsi,0x10(%rsp)
   45758:	mov    %ecx,%r14d
   4575b:	nopl   0x0(%rax,%rax,1)
   45760:	mov    %r14d,%esi
   45763:	call   *0x5d797(%rip)        # a2f00 <_DYNAMIC+0x5d0>
   45769:	mov    0x18(%rsp),%rax
   4576e:	test   %rax,%rax
   45771:	je     44340 <hotaru_core::screen::State::print_utf8+0x160>
   45777:	lock decq (%rax)
   4577b:	jne    44340 <hotaru_core::screen::State::print_utf8+0x160>
   45781:	lea    0x60(%rsp),%rdi
   45786:	call   *0x5d734(%rip)        # a2ec0 <_DYNAMIC+0x590>
   4578c:	jmp    44340 <hotaru_core::screen::State::print_utf8+0x160>
   45791:	shl    $0xc,%eax
   45794:	add    $0x3,%rsi
   45798:	or     %eax,%ecx
   4579a:	mov    %rsi,0x10(%rsp)
   4579f:	mov    %ecx,%edi
   457a1:	cmpb   $0x0,0x58(%rsp)
   457a6:	lea    0x8(%r12),%r14
   457ab:	mov    %rdi,0x20(%rsp)
   457b0:	jne    45088 <hotaru_core::screen::State::print_utf8+0xea8>
   457b6:	jmp    4451a <hotaru_core::screen::State::print_utf8+0x33a>
   457bb:	mov    %ebp,%r14d
   457be:	jmp    457d2 <hotaru_core::screen::State::print_utf8+0x15f2>
   457c0:	mov    %rbp,0x20(%rsp)
   457c5:	jmp    45404 <hotaru_core::screen::State::print_utf8+0x1224>
   457ca:	mov    %rbp,0x20(%rsp)
   457cf:	mov    %r15,%r13
   457d2:	mov    0x8(%rsp),%eax
   457d6:	mov    %r13,0x90(%rbx)
   457dd:	test   $0x1,%al
   457df:	jne    4542c <hotaru_core::screen::State::print_utf8+0x124c>
   457e5:	mov    0x20(%rsp),%r12
   457ea:	jmp    45226 <hotaru_core::screen::State::print_utf8+0x1046>
   457ef:	add    $0x148,%rsp
   457f6:	pop    %rbx
   457f7:	pop    %r12
   457f9:	pop    %r13
   457fb:	pop    %r14
   457fd:	pop    %r15
   457ff:	pop    %rbp
   45800:	ret
   45801:	lea    -0x385b3(%rip),%rdi        # d255 <hotaru_core::unicode::BREAKS+0x214d>
   45808:	lea    0x5a979(%rip),%rdx        # a0188 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x568>
   4580f:	mov    $0x14,%esi
   45814:	call   *0x5d4de(%rip)        # a2cf8 <_DYNAMIC+0x3c8>
   4581a:	jmp    45949 <hotaru_core::screen::State::print_utf8+0x1769>
   4581f:	call   *0x5d68b(%rip)        # a2eb0 <_DYNAMIC+0x580>
   45825:	lea    -0x385d7(%rip),%rdi        # d255 <hotaru_core::unicode::BREAKS+0x214d>
   4582c:	lea    0x5ab1d(%rip),%rdx        # a0350 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x730>
   45833:	mov    $0x14,%esi
   45838:	call   *0x5d4ba(%rip)        # a2cf8 <_DYNAMIC+0x3c8>
   4583e:	jmp    45949 <hotaru_core::screen::State::print_utf8+0x1769>
   45843:	mov    $0x8,%edi
   45848:	mov    $0x78,%esi
   4584d:	call   *0x5d365(%rip)        # a2bb8 <_DYNAMIC+0x288>
   45853:	jmp    45949 <hotaru_core::screen::State::print_utf8+0x1769>
   45858:	mov    $0x8,%edi
   4585d:	mov    $0x78,%esi
   45862:	call   *0x5d350(%rip)        # a2bb8 <_DYNAMIC+0x288>
   45868:	jmp    45949 <hotaru_core::screen::State::print_utf8+0x1769>
   4586d:	lea    0x5a95c(%rip),%rdx        # a01d0 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x5b0>
   45874:	jmp    45889 <hotaru_core::screen::State::print_utf8+0x16a9>
   45876:	mov    %rdx,%r15
   45879:	lea    0x5a968(%rip),%rdx        # a01e8 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x5c8>
   45880:	jmp    45889 <hotaru_core::screen::State::print_utf8+0x16a9>
   45882:	lea    0x5a92f(%rip),%rdx        # a01b8 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x598>
   45889:	mov    0x18(%rsp),%r12
   4588e:	mov    %r15,%rdi
   45891:	call   *0x5d2d9(%rip)        # a2b70 <_DYNAMIC+0x240>
   45897:	jmp    45949 <hotaru_core::screen::State::print_utf8+0x1769>
   4589c:	mov    %rcx,%rdi
   4589f:	lea    0x5acd2(%rip),%rdx        # a0578 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x958>
   458a6:	jmp    458d3 <hotaru_core::screen::State::print_utf8+0x16f3>
   458a8:	mov    %rcx,%rdi
   458ab:	mov    $0x1f,%esi
   458b0:	lea    0x5acd9(%rip),%rdx        # a0590 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x970>
   458b7:	jmp    458d3 <hotaru_core::screen::State::print_utf8+0x16f3>
   458b9:	mov    $0x7d00,%esi
   458be:	lea    0x5acb3(%rip),%rdx        # a0578 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x958>
   458c5:	jmp    458d3 <hotaru_core::screen::State::print_utf8+0x16f3>
   458c7:	mov    $0xbc,%esi
   458cc:	lea    0x5adc5(%rip),%rdx        # a0698 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0xa78>
   458d3:	mov    0x18(%rsp),%r12
   458d8:	vzeroupper
   458db:	call   *0x5d28f(%rip)        # a2b70 <_DYNAMIC+0x240>
   458e1:	jmp    45949 <hotaru_core::screen::State::print_utf8+0x1769>
   458e3:	lea    0x5a8b6(%rip),%rdx        # a01a0 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x580>
   458ea:	jmp    45889 <hotaru_core::screen::State::print_utf8+0x16a9>
   458ec:	lea    0x5a87d(%rip),%rdx        # a0170 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x550>
   458f3:	mov    $0x4,%esi
   458f8:	call   *0x5d272(%rip)        # a2b70 <_DYNAMIC+0x240>
   458fe:	mov    %r13,%rbp
   45901:	mov    0x30(%rsp),%r12
   45906:	lea    0x5aa5b(%rip),%rdx        # a0368 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x748>
   4590d:	mov    %rbp,%rdi
   45910:	call   *0x5d25a(%rip)        # a2b70 <_DYNAMIC+0x240>
   45916:	jmp    45949 <hotaru_core::screen::State::print_utf8+0x1769>
   45918:	mov    $0x7d00,%esi
   4591d:	jmp    45933 <hotaru_core::screen::State::print_utf8+0x1753>
   4591f:	mov    $0x1f,%esi
   45924:	lea    0x5ac65(%rip),%rax        # a0590 <anon.8cfae0649b24339a7c6ff37f2bd6b634.1766.llvm.13263554319387139704+0x970>
   4592b:	mov    %rax,0x80(%rsp)
   45933:	mov    0x80(%rsp),%rdx
   4593b:	mov    0x30(%rsp),%r12
   45940:	vzeroupper
   45943:	call   *0x5d227(%rip)        # a2b70 <_DYNAMIC+0x240>
   45949:	ud2
   4594b:	jmp    4594d <hotaru_core::screen::State::print_utf8+0x176d>
   4594d:	mov    0x30(%rsp),%r12
   45952:	mov    %rax,%rbx
   45955:	jmp    459a9 <hotaru_core::screen::State::print_utf8+0x17c9>
   45957:	jmp    4595b <hotaru_core::screen::State::print_utf8+0x177b>
   45959:	jmp    4595b <hotaru_core::screen::State::print_utf8+0x177b>
   4595b:	mov    0x30(%rsp),%r12
   45960:	jmp    459a1 <hotaru_core::screen::State::print_utf8+0x17c1>
   45962:	jmp    4596e <hotaru_core::screen::State::print_utf8+0x178e>
   45964:	mov    0x18(%rsp),%r12
   45969:	mov    %rax,%rbx
   4596c:	jmp    459ba <hotaru_core::screen::State::print_utf8+0x17da>
   4596e:	mov    %rax,%rbx
   45971:	jmp    4599a <hotaru_core::screen::State::print_utf8+0x17ba>
   45973:	lea    0xc0(%rsp),%rdi
   4597b:	mov    %rax,%rbx
   4597e:	call   4f1f0 <core::ptr::drop_in_place<hotaru_core::row::Row>>
   45983:	mov    0x30(%rsp),%r12
   45988:	jmp    459a4 <hotaru_core::screen::State::print_utf8+0x17c4>
   4598a:	lea    0xc0(%rsp),%rdi
   45992:	mov    %rax,%rbx
   45995:	call   4f1f0 <core::ptr::drop_in_place<hotaru_core::row::Row>>
   4599a:	mov    0x18(%rsp),%r12
   4599f:	jmp    459b5 <hotaru_core::screen::State::print_utf8+0x17d5>
   459a1:	mov    %rax,%rbx
   459a4:	test   %r12,%r12
   459a7:	je     459dc <hotaru_core::screen::State::print_utf8+0x17fc>
   459a9:	lock decq (%r12)
   459ae:	je     459ce <hotaru_core::screen::State::print_utf8+0x17ee>
   459b0:	jmp    459dc <hotaru_core::screen::State::print_utf8+0x17fc>
   459b2:	mov    %rax,%rbx
   459b5:	test   %r12,%r12
   459b8:	je     459dc <hotaru_core::screen::State::print_utf8+0x17fc>
   459ba:	lock decq (%r12)
   459bf:	lea    0x60(%rsp),%rax
   459c4:	mov    %rax,0xa0(%rsp)
   459cc:	jne    459dc <hotaru_core::screen::State::print_utf8+0x17fc>
   459ce:	mov    0xa0(%rsp),%rdi
   459d6:	call   *0x5d4e4(%rip)        # a2ec0 <_DYNAMIC+0x590>
   459dc:	mov    %rbx,%rdi
   459df:	call   9e790 <_Unwind_Resume@plt>
