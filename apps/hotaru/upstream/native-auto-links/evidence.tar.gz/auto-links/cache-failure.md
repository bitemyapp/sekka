The first native mapping builds reused the shared native Cargo target while
changing isolated Sidestep source/symlink targets. They failed with missing
GridMask, box_thickness_px, box_thickness_estimated and draw_grid_mask; after the
UI component rebuilt, its new AlphaMask operation was absent from the cached
engine artifact. These were stale component artifacts, not qualified results.
The repeated mapping-tests.log was overwritten; the full initial failed logs
were not retained. Representative captured terminal errors were:

    error[E0432]: unresolved import `aizome_kit::sidestep_ui::GridMask`
    error[E0609]: no field `box_thickness_px` on type `aizome_kit::sidestep_ui::grid::Metrics`
    error[E0599]: no variant named `AlphaMask` found for enum `Op`

The initial successful mapping run followed a forced engine/UI/Kit rebuild and
passed3 focused tests and11,088 real StringMap/regex endpoint comparisons. It is
retained as initial evidence. All subsequent work uses a distinct native target
/home/callen/.cache/hotaru-auto-links-target and a fresh component build, with
exact source/executable hashes. The authoritative final qualification will be
that isolated-target run, not inferred from cached success.
