#!/usr/bin/env python3
import fcntl,hashlib,json,pathlib,subprocess
base=pathlib.Path(__file__).resolve().parents[1];ref=pathlib.Path('/home/callen/work/ghostty-reference-20261028');clone=pathlib.Path('/home/callen/work/ghostty-url-map-reference-20261028');out=base/'artifacts/auto-links';out.mkdir(parents=True,exist_ok=True)
if not clone.exists():
 clone.mkdir()
 a=subprocess.Popen(['git','archive','6ba144158577d033ccb6ed4b574e4013957c9161'],cwd=ref,stdout=subprocess.PIPE)
 subprocess.run(['tar','-x','-C',str(clone)],stdin=a.stdout,check=True);assert a.wait()==0
 (clone/'zig-pkg').symlink_to(ref/'zig-pkg')
source=base/'tools/line-map-oracle.zig';dest=clone/'src/terminal/c/hotaru_url_map.zig';dest.write_bytes(source.read_bytes())
root=clone/'src/lib_vt.zig';original=(ref/'src/lib_vt.zig').read_bytes();root.write_bytes(original+b'\ncomptime { @export(&@import("terminal/c/hotaru_url_map.zig").map, .{ .name = "hotaru_url_map" }); }\n')
(out/'reference-adapter.patch').write_text(subprocess.run(['diff','-u',str(ref/'src/lib_vt.zig'),str(root)],capture_output=True,text=True).stdout)
zig='/home/callen/.cache/hotaru-reference/zig-x86_64-linux-0.17.0/zig';command=[zig,'build','--cache-dir','/home/callen/.cache/hotaru-url-map-zig','-Demit-lib-vt=true','-Demit-exe=false','-Dapp-runtime=none','-Doptimize=ReleaseSafe','-Demit-docs=false','-Demit-terminfo=false','-j8']
with pathlib.Path('/home/callen/.cache/hotaru-workstation.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 with (out/'reference-build.log').open('w') as log:subprocess.run(command,cwd=clone,stdout=log,stderr=subprocess.STDOUT,check=True)
 sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
 report={'pin':'6ba144158577d033ccb6ed4b574e4013957c9161','scope':'diagnostic adapter calls actual Screen.selectLine whitespace=null and selectionStringMap; reference behavior unmodified','command':command,'library':str(clone/'zig-out/lib/libghostty-vt.so'),'library_sha256':sha(clone/'zig-out/lib/libghostty-vt.so'),'bridge_sha256':sha(dest),'root_original_sha256':hashlib.sha256(original).hexdigest(),'root_adapter_sha256':sha(root),'sources':{str(p.relative_to(clone)):sha(p) for p in [clone/'src/terminal/Screen.zig',clone/'src/terminal/formatter.zig',clone/'src/terminal/StringMap.zig']}}
 (out/'reference-build.json').write_text(json.dumps(report,indent=2)+'\n')
