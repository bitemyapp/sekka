#!/usr/bin/env python3
"""Identity of the isolated candidate and its actual dependency source trees."""
import hashlib,json,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files={}
for name in ['desktop/aizome/apps/hotaru','desktop/aizome/crates/aizome-kit','desktop/aizome/crates/aizome-theme','desktop/aizome/crates/aizome-config','desktop/aizome/crates/aizome-shell-proto','desktop/aizome/crates/hotaru-link-regex','apps/hotaru/crates/hotaru-core','apps/hotaru/crates/hotaru-io','apps/hotaru/crates/hotaru-sprites','apps/hotaru/vendor/simdutf8','apps/hotaru/resources','vendor/sidestep']:
    folder=(root/name).resolve()
    for p in sorted(folder.rglob('*')):
        if p.is_file() and not set(p.relative_to(folder).parts)&{'.git','target','__pycache__'}:
            files[str(Path(name)/p.relative_to(folder))]=sha(p)
for name in ['desktop/aizome/Cargo.toml','desktop/aizome/Cargo.lock','apps/hotaru/Cargo.toml','apps/hotaru/Cargo.lock','desktop/aizome/nix/hotaru.nix','desktop/aizome/nix/package.nix','desktop/aizome/nix/default.nix']:
    files[name]=sha(root/name)
report={'base_core':'8f05f4a6','candidate':'isolated native automatic links; core adds Row::wrap_continuation accessor only','source_count':len(files),'sources':files,'source_sha256':hashlib.sha256(json.dumps(files,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'target_directory':'/home/callen/.cache/hotaru-auto-links-target'}
for name in ['aizome-hotaru','examples/auto_link_probe']:
    p=Path(report['target_directory'])/'debug'/name
    if p.exists():report[name]={'path':str(p),'sha256':sha(p)}
out=Path(sys.argv[1]);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='sources'}))
