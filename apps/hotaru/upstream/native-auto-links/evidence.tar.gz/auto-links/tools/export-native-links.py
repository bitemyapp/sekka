#!/usr/bin/env python3
import hashlib,json,subprocess,tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[1];shared=Path('/home/callen/work/sekka-hotaru');art=root/'artifacts/auto-links'
base='8f05f4a6'
paths=['apps/hotaru/crates/hotaru-core/src/row.rs','desktop/aizome/Cargo.lock','desktop/aizome/apps/hotaru/Cargo.toml',
       *[f'desktop/aizome/apps/hotaru/src/{p}.rs' for p in ['app','lib','main','links','terminal_view','link_resolver']],
       'desktop/aizome/apps/hotaru/src/automatic_links/mod.rs','desktop/aizome/apps/hotaru/src/automatic_links/mapping.rs',
       'desktop/aizome/apps/hotaru/examples/auto_link_probe.rs',
       *[f'desktop/aizome/apps/hotaru/tests/wayland/{p}' for p in ['auto_links.py','auto-link-pointer.c','smoke.py']],
       'desktop/aizome/nix/hotaru.nix','desktop/aizome/nix/package.nix']
paths += [str(p.relative_to(root)) for p in (root/'desktop/aizome/crates/hotaru-link-regex').rglob('*') if p.is_file()]
manifest={};pieces=[];boundary=[]
qualified=json.loads((art/'final-source-after.json').read_text())
with tempfile.TemporaryDirectory(prefix='hotaru-link-diff-') as tmp:
    old=Path(tmp)/'base'
    for name in sorted(paths):
        new=root/name;data=new.read_bytes();before=subprocess.run(['git','show',f'{base}:{name}'],cwd=shared,capture_output=True)
        if before.returncode==0 and before.stdout==data:continue
        digest=hashlib.sha256(data).hexdigest();assert qualified['sources'][name]==digest,(name,'not exact qualified input')
        manifest[name]=digest
        old.write_bytes(before.stdout)
        diff=subprocess.run(['git','diff','--no-index','--no-ext-diff','--no-textconv','--no-color','--binary','--',str(old) if before.returncode==0 else '/dev/null',str(new)],capture_output=True)
        assert diff.returncode==1,(name,diff.stderr)
        output=[]
        for line in diff.stdout.decode().splitlines(keepends=True):
            if line.startswith('diff --git '):line=f'diff --git a/{name} b/{name}\n'
            elif line.startswith('--- '):line=f'--- a/{name}\n' if before.returncode==0 else '--- /dev/null\n'
            elif line.startswith('+++ '):line=f'+++ b/{name}\n'
            output.append(line)
        piece=''.join(output);pieces.append(piece)
        if '/vendor/oniguruma/' not in name:boundary.append(piece)
(art/'candidate.patch').write_text(''.join(pieces));(art/'boundary.patch').write_text(''.join(boundary))
(art/'product-manifest.json').write_text(json.dumps({'base':base,'count':len(manifest),'files':manifest},indent=2)+'\n')
print(json.dumps({'files':len(manifest),'patch_sha256':hashlib.sha256((art/'candidate.patch').read_bytes()).hexdigest(),'boundary_sha256':hashlib.sha256((art/'boundary.patch').read_bytes()).hexdigest()}))
