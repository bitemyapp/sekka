#!/usr/bin/env python3
"""Actual Screen.selectLine/StringMap + exact regex endpoints; no model oracle."""
import ctypes as C,fcntl,hashlib,json,pathlib,subprocess
from reference_abi import Oracle,GridRef,Point,Coordinate,ModeConfig,checked
root=pathlib.Path(__file__).resolve().parents[1];art=root/'artifacts/auto-links';build=json.loads((art/'reference-build.json').read_text());library=pathlib.Path(build['library']);binary=pathlib.Path('/home/callen/.cache/hotaru-auto-links-target/debug/examples/auto_link_probe')
streams=[
'', 'https://example.test/a', '../src/file.rs:42:3', '/tmp/a b.txt',
'https://例子.test/雪e\u0301', 'https://x/🧑🏽\u200d💻', 'https://x/界',
'prefix https://x/a_(b) suffix', '\x1b]133;A\x07$ \x1b]133;B\x07https://x\x1b]133;C\x07 output',
'\x1b]133;P;k=s\x07> \x1b]133;B\x07../src/main.rs\x1b]133;C\x07',
'https://x \x1b]133;B\x07../file.txt', '\x1b]133;B\x07https://x/界\x1b]133;C\x07!',
'/tmp/a\x1b[Cb.txt', '/tmp/a\x1b[2Cb.txt', '/tmp/a\x1b[3Cb.txt',
'\x1b[5Ghttps://x', 'https://x   ', 'https://x\x1b[2D\x1b[X',
'http://x\r\nnext/file.txt', '1234567界https://x', '12345678901界https://x',
'\x1b]133;B\x07/ab/界\x1b]133;C\x07more',
'\x1b]133;A\x07prompt\x1b]133;B\x07\t../file.txt',
'\x1b]133;A\x07\x1b]133;I\x07https://x',
'abcdefghijklmno\r\x1b[2Khttps://x',
'\x1b]133;B\x07abcdefghi\x1b]133;C\x07https://x\x1b[H\x1b[2K',
'\x1b]8;id=x;https://explicit.test\x1b\\https://automatic.test\x1b]8;;\x1b\\',
'\x1b]133;B\x07abc\x1b[?1049hhttps://alternate.test',
]
cases=[]
for cols,rows in [(1,4),(8,4),(12,4),(24,3),(80,3)]:
 for data in streams:
  for row in range(rows):
   for col in range(cols):cases.append(dict(data=data,cols=cols,rows=rows,row=row,col=col,unicode=True))
report={'scope':'actual logical-selection boundaries/text and regex target endpoints at each clicked cell; native gesture and worker checks are recorded separately','cases':len(cases),'failures':[],'matches':0,'no_complete_line':0,'blank_map_order_observations':[]}
with pathlib.Path('/home/callen/.cache/hotaru-workstation.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
 assert sha(library)==build['library_sha256']
 oracle=Oracle(library);lib=oracle.lib
 lib.hotaru_url_map.argtypes=[C.c_void_p,C.POINTER(GridRef),C.c_void_p,C.POINTER(C.c_uint32),C.c_size_t,C.POINTER(C.c_size_t),C.POINTER(C.c_uint32)];lib.hotaru_url_map.restype=C.c_int
 regex_path=pathlib.Path('/home/callen/work/hotaru-auto-links-20261028/oracle/liburl-reference.so');regex=C.CDLL(str(regex_path));regex.reference_search.argtypes=[C.c_void_p,C.c_size_t,C.POINTER(C.c_int)];regex.reference_search.restype=C.c_int
 report.update(binary_sha256=sha(binary),library_sha256=sha(library),regex_adapter_sha256=sha(regex_path))
 expected=[];last_key=None;term=None
 try:
  for case in cases:
   key=(case['data'],case['cols'],case['rows'])
   if key!=last_key:
    if term:lib.ghostty_terminal_free(term)
    term=C.c_void_p();checked(lib.ghostty_terminal_new(None,C.byref(term),case['cols'],case['rows']))
    zero=C.c_size_t(0);checked(lib.ghostty_terminal_set(term,oracle.enum('GhosttyTerminalOption','SCROLLBACK_MAX_BYTES'),C.byref(zero)))
    mode=ModeConfig(2027,True);checked(lib.ghostty_terminal_set(term,oracle.enum('GhosttyTerminalOption','MODE_DEFAULT'),C.byref(mode)))
    raw=case['data'].encode();lib.ghostty_terminal_vt_write(term,raw,len(raw));last_key=key
   p=Point(tag=oracle.enum('GhosttyPointTag','ACTIVE'));p.value.coordinate=Coordinate(case['col'],case['row']);ref=GridRef(size=C.sizeof(GridRef));checked(lib.ghostty_terminal_grid_ref(term,p,C.byref(ref)))
   text=C.create_string_buffer(65536);points=(C.c_uint32*(2*65536))();bounds=(C.c_uint32*4)();count=C.c_size_t();code=lib.hotaru_url_map(term,C.byref(ref),text,points,65536,C.byref(count),bounds)
   if code==-1:expected.append({'error':'NoLine'});continue
   assert code==0,(case,code)
   raw=text.raw[:count.value];coords=[[points[2*i+1],points[2*i]] for i in range(count.value)]
   found=None;offset=0
   while offset<len(raw):
    pair=(C.c_int*2)();suffix=raw[offset:];buffer=C.create_string_buffer(suffix);code=regex.reference_search(buffer,len(suffix),pair)
    if code==-1:break
    assert code==0,(case,code)
    a,b=pair;assert 0<=a<b<=len(suffix)
    start,end=coords[offset+a],coords[offset+b-1]
    if start<=[case['row'],case['col']]<=end:
     found={'text':raw[offset+a:offset+b].decode(),'bytes':[offset+a,offset+b],'start':start,'end':end};break
    offset+=b
   if len(report['blank_map_order_observations'])<8 and any(a>b for a,b in zip(coords,coords[1:])):
    record={'data':case['data'],'cols':case['cols'],'rows':case['rows'],'row':case['row'],'col':case['col'],'text':raw.decode(),'points':coords}
    if record not in report['blank_map_order_observations']:report['blank_map_order_observations'].append(record)
   expected.append({'text':raw.decode(),'start':[bounds[1],bounds[0]],'end':[bounds[3],bounds[2]],'found':found})
 finally:
  if term:lib.ghostty_terminal_free(term)
 payload=''.join(json.dumps(c,ensure_ascii=False)+'\n' for c in cases)
 result=subprocess.run([str(binary)],input=payload,text=True,capture_output=True,check=True,timeout=120)
 actual=[json.loads(line) for line in result.stdout.splitlines()];assert len(actual)==len(cases)
 for i,(want,got) in enumerate(zip(expected,actual)):
  if want=={'error':'NoLine'} and got=={'error':'ClippedEnd'}:report['no_complete_line']+=1
  elif want!=got:report['failures'].append({'case':i,'input':cases[i],'reference':want,'candidate':got})
  else:report['matches']+=1
 report['sources']={str(p.relative_to(root)):sha(p) for folder in ['desktop/aizome/apps/hotaru/src/automatic_links','desktop/aizome/apps/hotaru/examples','tools'] for p in (root/folder).rglob('*') if p.is_file()}
report['status']='passed' if not report['failures'] else 'failed';(art/'mapping-oracle.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['status','cases','matches','no_complete_line']},ensure_ascii=False));print('failures',len(report['failures']));raise SystemExit(bool(report['failures']))
