// Diagnostic-only bridge to the actual unmodified Screen selection/formatter.
const lib = @import("../lib.zig");
const terminal_c = @import("terminal.zig");
const grid_ref = @import("grid_ref.zig");
pub fn map(
    terminal: terminal_c.Terminal,
    reference: *const grid_ref.CGridRef,
    bytes: [*]u8,
    coordinates: [*]u32,
    capacity: usize,
    count: *usize,
    bounds: [*]u32,
) callconv(lib.calling_conv) c_int {
    const t = terminal_c.zigTerminal(terminal) orelse return -2;
    const pin = reference.toPin() orelse return -2;
    const screen = t.screens.active;
    const selection = screen.selectLine(.{ .pin = pin, .whitespace = null, .semantic_prompt_boundary = true }) orelse return -1;
    const first = screen.pages.pointFromPin(.screen, selection.topLeft(screen)) orelse return -2;
    const last = screen.pages.pointFromPin(.screen, selection.bottomRight(screen)) orelse return -2;
    bounds[0] = first.coord().x; bounds[1] = first.coord().y;
    bounds[2] = last.coord().x; bounds[3] = last.coord().y;
    const string_map = screen.selectionStringMap(t.gpa(), .{ .sel = selection, .trim = false }) catch return -4;
    defer string_map.deinit(t.gpa());
    count.* = string_map.string.len;
    if (string_map.string.len > capacity or capacity > 65536) return -3;
    @memcpy(bytes[0..string_map.string.len], string_map.string);
    for (0..string_map.string.len) |i| {
        const p = string_map.map.get(i) orelse return -5;
        const point = screen.pages.pointFromPin(.screen, p) orelse return -5;
        coordinates[2*i] = point.coord().x;
        coordinates[2*i+1] = point.coord().y;
    }
    return 0;
}
