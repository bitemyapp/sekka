# Next native integration requirements

The frozen crate is a matcher, not an implemented native link feature. Product
work remains isolated. Add it only to the Aizome workspace/app, preserving the
core workspace separation. The existing desktop workspace's crates/* already
finds the new member; refresh its lock remotely and install the retained
Oniguruma BSD notice in Nix. Its source closure needs C/header/data/regex files,
not only Rust files. Keep the exact6.9.9 engine as the only Oniguruma owner.

The first native worker will have one in-flight request and one replaceable
latest request. A request holds exact displayed Arc<Snapshot>, pane/request
identity and pointer cell. New work cancels the previous token but never joins
or waits in UI/PTY teardown. Results are checked against all identities before
highlight or action; a closed pane cannot be revived by a late result. OSC8
retains priority. Retained rows/request text must have explicit admission limits.

Mapping walks immutable rows across softwraps while per-cell SemanticContent
matches the clicked cell, using the supplied byte→cell map rather than Unicode
scalar counts. RowPrompt is not a substitute. Missing viewport context or byte
budget returns an explicit incomplete outcome, never a truncated URL matched
under different boundaries. Start with that honest completeness limit; a later
actor capture requires validation against the same displayed row identities.

Regex deadlines are cooperative: one adversarial C call can exceed0.65 seconds.
A strict deadline design uses a dedicated helper process with a bounded framed
request/response protocol, the exact same matcher crate, one request at a time,
maximum frame size and monotonic request ID. The supervisor polls with an
absolute deadline, kills/reaps only its own helper on expiry, discards the result
and may restart for a newer request. Process startup/sandbox/IPC cost and shutdown
must be measured before claiming responsiveness. No asynchronous thread cancel.

Opening receives a literal single argv target, never shell syntax. Relative
paths are lexically resolved against accepted OSC7 cwd and used only when the
resolved path exists; otherwise preserve the original target. Do not expand~or
$VAR or strip line/column suffixes. Filesystem checks can block independently of
regex, so strict resolver timeouts likewise require a killable helper. No UI/PTY
thread may wait for a resolver. Native activation must reject stale cell/frame,
pane, modifiers or press/release identity before dispatch.
