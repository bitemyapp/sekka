# Native automatic URL/path detection design

This isolated component matches the exact default rule from pinned Ghostty
`6ba144158577d033ccb6ed4b574e4013957c9161`. It does not yet implement a native
hover worker, semantic prompt storage, filesystem resolution or click behavior.
The application logic and mapping are Rust; the existing external Oniguruma
regex engine is retained as an explicitly attributed C dependency.

## Dependency choice

The cached `onig 6.5.3` wrapper uses `onig_sys 69.9.3`, whose bundled header
identifies engine **6.9.10**. Ghostty pins **6.9.9**. Its safe wrapper also calls
`onig_initialize_match_param` after an unchecked nullable allocation, and forms
`add(from/to)` pointers before checking bounds. Those APIs are not used here.

A native-only private `hotaru-link-regex` crate instead compiles the unchanged
48 C files selected by Ghostty, with the same Linux config macros, plus their
recursive local headers/data. No Apple SDK or other platform build scripts are
included. Its checked Rust boundary uses only UTF8, one fixed trusted regex,
private opaque handles and one public C-layout region structure checked against
the actual header at C/Rust compile time. Allocation failure, invalid returned
ranges and engine failures are explicit errors. C allocations are freed by C;
Rust never adopts them into a Vec/Box. Regex, region and match params remain
worker-owned; there is no unsafe Send/Sync implementation. Initialization is
once per process, compilation is serialized, per-call limits never mutate global
settings, and `onig_end` is never called while other workers could still search.
The engine's small process-global tables deliberately survive until exit.

The BSD notice is retained alongside the Ghostty MIT rule notice. Neither core
workspace nor current product lockfiles are edited by this isolated prototype.
A safe Rust regex alternative cannot directly express the pinned variable-length
lookbehind; substituting a simpler regex would not establish compatibility.

## Immutable input and bounds

`LogicalSlice` owns `Arc<str>` and compressed `MappingRun` entries. Each entry
maps all bytes since the previous end to a source `CellPoint`, following
StringMap's byte-to-pin model. Construction validates complete ordered coverage,
UTF8 boundaries and bounded size; it belongs on the worker. No cell position is
inferred by counting Unicode scalars. Wide cells, combining clusters and soft
wraps are supplied by the exact source mapper, including repeated cell positions
for multiple byte runs. `Match` retains the slice, original byte range and
inclusive source endpoints.

`Matcher::find_at` returns the first match containing the requested cell.
`ranges` supplies full byte ranges for prefetch/oracle checking. Suffix iteration
is deliberate: upstream searches `string[offset..]`, so lookbehind sees that new
start, not the entire original buffer with a separate search offset. The fixed
rule cannot match empty text; unexpected zero-length results are rejected.

Hard input/mapping caps are 64 KiB/65,536 runs; up to 256 matches and searches,
engine stack entry limits in 512..=16,384, and a conservative 25.6M maximum
sum of granted retry allowances. Defaults are4,096 engine stack entries,64 searches,
6.4M aggregate allowance and a 25 ms cooperative deadline. Each suffix call
receives the same **100,000 whole-search retry limit** as pinned StringMap.
The engine API's stack limit counts `StackType` entries, not bytes. A separately
compiled exact implementation diagnostic reports32 bytes per entry,160 initial
entries, and2 pointer-metadata entries of8 bytes for this fixed regex on x86_64.
First promotion reaches320 entries regardless of the requested limit; later
reallocation computes doubled storage before clamping its usable count. The
accepted minimum512 stays above that promotion. Conservative transient stack
storage is at most3×the entry limit plus the retained initial160 entries, plus
pointer metadata and other engine allocations. This is not a byte/RSS cap.
Initial evidence under `pre-stack-unit-fix/` used a misnamed byte field and is
superseded by the corrected entry-limited qualification.

Exhaustion returns an explicit budget error instead of silently treating it as
no match or returning a truncated URL. Cancellation/deadline are checked before
and after each call. They cannot interrupt one foreign call; this is bounded
work, not a hard wall-clock guarantee. A killable persistent helper is required
if later UI policy demands strict wall-time termination.

## Native integration boundary

OSC 8 remains first priority. Auto-detection only follows when the cell has no
eligible OSC 8 link. One latest request per pane contains pane/token, exact
`Arc<Snapshot>`, pointer cell, immutable mapped logical slice and cancellation.
A small global worker pool performs matching; no regex compilation, flattening,
history decoding or filesystem checks run in a UI callback or PTY owner.
New requests replace pending work rather than growing an unbounded queue.
Results and press/release activation must still refer to the latest displayed
snapshot, same cell and modifiers, with no movement or intervening frame change.
Returned range coordinates drive highlight spans; source snapshot ownership
prevents ABA. No match can be rebased merely because text happens to be equal.

The current core lacks semantic prompt metadata. Upstream's `selectLine` compares
per-cell semantic content continuously across soft wraps, with whitespace=null,
and can stop within a physical row. Root is implementing that independent source
metadata. This prototype accepts an already bounded, fully mapped logical slice
and makes no prompt-boundary equivalence claim. Viewport-edge logical lines need
coherent owned context from the same capture; taking a newer terminal capture
and silently appending it to an old displayed frame is invalid. If a byte/context
cap prevents finding both real boundaries, return a limit result rather than
matching an arbitrary prefix/window that changes regex semantics.

The existing synchronous OSC 8 gesture can stay immediate. Auto-detection should
prefetch on stable hover/modifier changes. The native layer must explicitly test
fast modifier+click before completion, pointer movement, delayed result after
release, newer frames and pane closure; it must not open an old hit or quietly
reuse a stale match. No UI gesture behavior is claimed by this crate alone.

## Path resolution

Pinned Surface resolves only nonabsolute matched text, against the terminal's
accepted OSC 7 cwd, and uses that absolute lexical path only when access succeeds.
Otherwise it passes the original matched text to the desktop handler. It does
not shell-expand `$VAR`/`~`, strip `:line:column`, or invoke a shell. Absolute paths
remain unchanged. Preserve this behavior in a separate opening worker, using an
owned cwd captured consistently with the activation request. Keep targets as
single arguments to the existing bounded desktop opener.

A filesystem access call can block on a mount indefinitely. Byte/retry regex
limits do not solve that. Strict path-resolution deadlines therefore require a
separately killable helper; the UI/PTY must never wait, and a thread cannot be
safely cancelled. Existence is advisory and can change before the desktop handler
opens the path; do not present it as a security guarantee. Final launch must be
re-authorized against the still-current native gesture/snapshot before enqueue.

## Reference qualification approach

The independent diagnostic compiles the unchanged `src/config/url.zig` constant
with the pinned Zig compiler, and separately builds actual Oniguruma 6.9.9 source
from Ghostty's external reference checkout. Its exported regex bytes must equal
the generated Rust fixture before matching. It runs the actual default engine
syntax/options with 100k suffix retries and records exact byte ranges. This is
an engine/rule/iterator oracle, not a replacement model of the regex.

The 90 positive/negative upstream tests are retained verbatim as source-derived
expectations. Generated Unicode/punctuation/adjacency inputs extend that gate.
Mapping tests cover owned lifetime, wrap-spanning matches, wide/combining byte
runs, malformed maps and explicit budget/cancellation outcomes. Native hover
and semantic mapping will require additional actual terminal/gesture oracles
and real private Wayland tests after the independent metadata slice is ready.

## Adversarial latency observation

The44-case diagnostic includes inputs up to64KiB and one over-cap rejection.
Single C calls on64KiB slash/dollar strings took roughly0.56–0.65 seconds even
with100k retry allowance. A25ms cooperative deadline cannot preempt such a call.
Post-call cancellation/deadline checks also run when the engine returns an error.
The proposed GUI worker is isolated from UI/PTY ownership; strict interactive
wall-time termination would require a killable helper process. These are bounded
work observations, not throughput acceptance or a claim of25ms latency.
