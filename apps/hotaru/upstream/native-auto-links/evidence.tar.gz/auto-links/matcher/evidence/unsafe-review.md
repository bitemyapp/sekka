# Checked native regex boundary review

The independent native architecture agent reviewed the exact header and
regcomp.c/regexec.c implementation against engine.rs, abi.c, lib.rs and build.rs.
The review found one concrete defect: the original `stack_bytes` name and prose
misstated the engine's entry-count limit. That API is corrected to
`stack_entries`, default4,096 and accepted range512..=16,384. Historical reports
are preserved under pre-stack-unit-fix and do not qualify the new API.

The reviewer then confirmed the corrected public/private limits and post-call
cancellation/deadline checks, including engine-error paths. No additional
concrete unsafe or ownership defect was found. The review covered FFI integer
and pointer signatures, checked C/Rust region layout, exact constructor failure
cleanup, nullable match-param allocation, zero-initialized region equivalence,
free_self=0 ownership, one-past borrowed text endpoints, checked positive UTF8
match ranges, worker-local !Send/Sync handles, once-only initialization,
serialized compilation and absence of concurrent global termination.

This is a narrow boundary review, not a proof of every line of the retained C
engine. There is no Miri claim for foreign C execution. Integration must retain
exclusive global engine ownership and never call onig_end while workers exist.

Runtime gates:9 debug and9 release tests, strict all-target Clippy,3,474 exact
actual-reference comparisons,44 bounded process-isolated adversarial cases.
The independent actual implementation layout diagnostic reports32-byte stack
entries,160 initial entries, and two8-byte metadata slots for this fixed rule
on x86_64. The C call may run about0.67 seconds despite a25ms cooperative deadline;
worker isolation is mandatory and hard termination requires process isolation.
