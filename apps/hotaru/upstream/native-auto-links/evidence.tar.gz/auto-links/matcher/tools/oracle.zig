const rule = @import("url.zig");
export fn reference_regex() [*]const u8 { return rule.regex.ptr; }
export fn reference_regex_length() usize { return rule.regex.len; }
