from pathlib import Path
import hashlib,json,re
root=Path(__file__).resolve().parents[1];crate=root/'desktop/aizome/crates/hotaru-link-regex';vendor=crate/'vendor/oniguruma/src';source=(root/'reference/oniguruma-build.zig').read_text()
files=re.findall(r'"src/([^"\n]+\.c)"',source)
assert len(files)==48,(len(files),files)
keep=set(files);pending=list(files)
while pending:
 p=vendor/pending.pop()
 for name in re.findall(r'#\s*include\s*"([^"\n]+)"',p.read_text(errors='strict')):
  if (vendor/name).is_file() and name not in keep:keep.add(name);pending.append(name)
keep.add('oniguruma.h')
for p in vendor.iterdir():
 if p.is_file() and p.name not in keep:p.unlink()
(crate/'vendor/oniguruma/sources.txt').write_text('\n'.join(files)+'\n')
proof={'ghostty':'6ba144158577d033ccb6ed4b574e4013957c9161','oniguruma':'6.9.9','dependency_hash':'N-V-__8AAHjwMQDBXnLq3Q2QhaivE0kE2aD138vtX2Bq1g7c','source_note':'Unchanged exact files from pinned Ghostty dependency; only compiled C sources and recursive local includes retained. No platform build scripts or macOS components.','files':{str(p.relative_to(crate)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((crate/'vendor/oniguruma').rglob('*')) if p.is_file()}}
(root/'evidence/engine-provenance.json').write_text(json.dumps(proof,indent=2)+'\n')
# These are source-derived expectations, not computed candidate snapshots.
url=(root/'reference/url.zig').read_text();tests=[]
for a,b in re.findall(r'\.input = ("(?:[^"\\]|\\.)*"),\s*\.expect = ("(?:[^"\\]|\\.)*"),',url):tests.append({'input':json.loads(a),'expected':json.loads(b)})
no=url.split('const no_match_cases = [_][]const u8{',1)[1].split('};',1)[0]
for a in re.findall(r'^\s*("(?:[^"\\]|\\.)*"),',no,re.M):tests.append({'input':json.loads(a),'expected':None})
(crate/'tests/upstream.json').write_text(json.dumps(tests,ensure_ascii=False,indent=2)+'\n')
# Fold this restricted constant grammar; an actual Zig-compiled export independently verifies bytes.
values={}
for name,expr in re.findall(r'(?:pub )?const (\w+) =\n(.*?);\n',url.split('test "url regex"')[0],re.S):
 lines=expr.splitlines()
 if any(l.strip().startswith('\\\\') for l in lines):value='\n'.join(l.strip()[2:] for l in lines if l.strip().startswith('\\\\'))
 else:
  tokens=re.findall(r'"(?:[^"\\]|\\.)*"|\b[A-Za-z_]\w*\b',expr)
  value=''.join(json.loads(t) if t.startswith('"') else values[t] for t in tokens)
 values[name]=value
assert 'regex' in values
(crate/'src/default.regex').write_text(values['regex'])
print(json.dumps({'sources':len(files),'retained_files':len(keep),'upstream_cases':len(tests),'regex_bytes':len(values['regex'].encode()),'regex_sha256':hashlib.sha256(values['regex'].encode()).hexdigest()}))
