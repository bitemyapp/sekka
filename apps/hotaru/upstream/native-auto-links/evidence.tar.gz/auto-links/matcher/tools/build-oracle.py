#!/usr/bin/env python3
import hashlib,json,pathlib,shutil,subprocess
root=pathlib.Path(__file__).resolve().parents[1];out=root/'oracle';out.mkdir(exist_ok=True)
ref=pathlib.Path('/home/callen/work/ghostty-reference-20261028');engine=ref/'zig-pkg/N-V-__8AAHjwMQDBXnLq3Q2QhaivE0kE2aD138vtX2Bq1g7c/src';crate=root/'desktop/aizome/crates/hotaru-link-regex'
proof=json.loads((root/'evidence/engine-provenance.json').read_text())
for name,digest in proof['files'].items():
 if '/src/' in name:assert hashlib.sha256((engine/pathlib.Path(name).name).read_bytes()).hexdigest()==digest,name
shutil.copyfile(ref/'src/config/url.zig',out/'url.zig')
for name in ['oracle.zig','oracle.c']:shutil.copyfile(root/'tools'/name,out/name)
config=next((root/'target/debug/build').glob('hotaru-link-regex-*/out/config.h'));shutil.copyfile(config,out/'config.h')
files=(crate/'vendor/oniguruma/sources.txt').read_text().splitlines()
c=['cc','-shared','-fPIC','-O2','-I'+str(engine),'-I'+str(out),*[str(engine/x) for x in files],'-o',str(out/'liboniguruma-reference.so')];subprocess.run(c,check=True)
zig=pathlib.Path('/home/callen/.cache/hotaru-reference/zig-x86_64-linux-0.17.0/zig')
z=[str(zig),'build-lib','--name','url-rule','-dynamic','-lc','-O','ReleaseSafe',str(out/'oracle.zig'),'-femit-bin='+str(out/'liburl-rule.so')];subprocess.run(z,check=True)
a=['cc','-shared','-fPIC','-O2','-I'+str(engine),str(out/'oracle.c'),'-L'+str(out),'-lurl-rule','-loniguruma-reference','-Wl,-rpath,'+str(out),'-o',str(out/'liburl-reference.so')];subprocess.run(a,check=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(root/'evidence/reference-build.json').write_text(json.dumps({'source_pin':proof['ghostty'],'commands':[c,z,a],'library':str(out/'liburl-reference.so'),'library_sha256':sha(out/'liburl-reference.so'),'engine_sha256':sha(out/'liboniguruma-reference.so'),'rule_library_sha256':sha(out/'liburl-rule.so'),'rule_source_sha256':sha(out/'url.zig'),'adapter_sha256':{n:sha(out/n) for n in ['oracle.zig','oracle.c']},'config_sha256':sha(out/'config.h'),'zig_sha256':sha(zig)},indent=2)+'\n')
