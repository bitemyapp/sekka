#!/usr/bin/env python3
import fcntl,hashlib,json,pathlib,subprocess
root=pathlib.Path(__file__).resolve().parents[1];crate=root/'desktop/aizome/crates/hotaru-link-regex'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def manifest():
 paths=[root/'Cargo.toml',root/'Cargo.lock',*sorted(p for p in crate.rglob('*') if p.is_file())]
 return {str(p.relative_to(root)):sha(p) for p in paths}
with pathlib.Path('/home/callen/.cache/hotaru-workstation.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 sources=manifest()
 proof=json.loads((root/'evidence/engine-provenance.json').read_text())
 for name,want in proof['files'].items(): assert sha(crate/name)==want,name
 with (root/'evidence/qualified-release-tests.log').open('w') as out:
  subprocess.run(['/home/callen/.cargo/bin/cargo','+1.95.0','test','--locked','--release'],cwd=root,stdout=out,stderr=subprocess.STDOUT,check=True)
 assert sources==manifest(),'source changed during qualification'
 report={'scope':'isolated native-only matcher; no native hover/activation or terminal logical-slice extractor yet','source_pin':proof['ghostty'],'product_sources':sources,'binaries':{str(p.relative_to(root)):sha(p) for p in [root/'target/release/examples/probe',root/'target/release/examples/bounds']},'evidence':{str(p.relative_to(root)):sha(p) for p in sorted((root/'evidence').glob('*')) if p.is_file() and p.name!='qualification.json'},'reference_inputs':{str(p.relative_to(root)):sha(p) for p in (root/'reference').glob('*') if p.is_file()},'tools':{str(p.relative_to(root)):sha(p) for p in (root/'tools').glob('*') if p.is_file()}}
 (root/'evidence/qualification.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'files':len(sources),'status':'passed','binary_sha256':report['binaries']['target/release/examples/probe']}))
