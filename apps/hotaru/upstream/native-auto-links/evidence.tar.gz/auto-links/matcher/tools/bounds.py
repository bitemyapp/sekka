#!/usr/bin/env python3
"""Bounded adversarial diagnostic, not a throughput/performance acceptance gate."""
import fcntl,hashlib,json,pathlib,subprocess,time
root=pathlib.Path(__file__).resolve().parents[1];binary=root/'target/release/examples/bounds'
cases=[]
for n in [128,1024,8192,65536]:
 for label,piece in [('letters','a'),('slashes','/'),('dollars','$'),('brackets','['),('nested','('),('path','../'),('urls','https://x '),('unicode','雪'),('variables','$VARIABLE/path/'),('nested-url','https://x/(a(')]:
  text=(piece*((n+len(piece.encode())-1)//len(piece.encode()))).encode()[:n].decode(errors='ignore');cases.append((label+':'+str(n),{'text':text}))
cases += [('over-cap',{'text':'a'*65537}),('pre-cancelled',{'text':'https://x','cancel':True}),('expired',{'text':'https://x','deadline_ms':0}),('empty-cancelled',{'text':'','cancel':True})]
report={'scope':'single-process-per-case bounded-work observations; no hard wall-clock, UI, filesystem or throughput guarantee','results':[],'failures':[]}
with pathlib.Path('/home/callen/.cache/hotaru-workstation.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 report['binary_sha256']=hashlib.sha256(binary.read_bytes()).hexdigest()
 report['sources']={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for folder in ['desktop/aizome/crates/hotaru-link-regex/src','desktop/aizome/crates/hotaru-link-regex/examples','tools'] for p in (root/folder).rglob('*') if p.is_file()}
 for name,request in cases:
  begin=time.monotonic()
  try:
   p=subprocess.run([str(binary)],input=json.dumps(request),capture_output=True,text=True,timeout=5,check=True)
   row=json.loads(p.stdout);row.update(name=name,process_wall_s=time.monotonic()-begin,input_sha256=hashlib.sha256(request['text'].encode()).hexdigest())
   result=row['result'];assert 'ranges' in result or result.get('error','').startswith('Budget(') or result.get('error')=='Cancelled',result
   report['results'].append(row)
  except Exception as e:report['failures'].append({'name':name,'error':str(e)})
report['status']='passed' if not report['failures'] else 'failed';(root/'evidence/bounds.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'cases':len(cases),'failures':report['failures'],'max_search_ms':max((r['search_ns']/1e6 for r in report['results']),default=0)}));raise SystemExit(bool(report['failures']))
