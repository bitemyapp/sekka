#!/usr/bin/env python3
import argparse,ctypes,fcntl,hashlib,json,pathlib,random,subprocess,time
root=pathlib.Path(__file__).resolve().parents[1];crate=root/'desktop/aizome/crates/hotaru-link-regex';p=argparse.ArgumentParser();p.add_argument('--output',type=pathlib.Path,required=True);a=p.parse_args()
cases=[c['input'] for c in json.loads((crate/'tests/upstream.json').read_text())]
pieces=['https://example.test/a_(b)','src/file.rs:42:10','../two words/file.txt','$HOME/src/config','https://例子.测试/雪','./e\u0301.txt','a/$VAR/path.txt','foo/bar','//comment','https://[::1]:80/path','file:///tmp/a','mailto:a@example.test','ftp://host/a','\x00','雪',' ','.',':',',','\n','\t','(',')','[',']','!']
rng=random.Random(0x1a1109)
for _ in range(3000):cases.append(''.join(rng.choice(pieces) for _ in range(rng.randrange(1,24))))
for text in ['https://x/雪','./αβ.txt','https://x/e\u0301','../目錄/文件.txt','http://x/a(b)c','https://[2001:db8::1]/a']:
 for left in ['','雪','a',' ','.','(', '$10/', '\x00']:
  for right in ['',' ',')','.',':',',next.txt','/','\u0301']:
   cases.append(left+text+right)
report={'scope':'exact fixed regex and suffix iterator, not terminal semantic selection, filesystem opening or native gesture parity','cases':len(cases),'failures':[],'bounded':[],'matches':0}
with pathlib.Path('/home/callen/.cache/hotaru-workstation.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 lib=root/'oracle/liburl-reference.so';binary=root/'target/release/examples/probe';oracle=ctypes.CDLL(str(lib));oracle.reference_regex.restype=ctypes.c_void_p;oracle.reference_regex_length.restype=ctypes.c_size_t;oracle.reference_search.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.POINTER(ctypes.c_int)];oracle.reference_search.restype=ctypes.c_int
 sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
 actual_rule=ctypes.string_at(oracle.reference_regex(),oracle.reference_regex_length());candidate_rule=subprocess.check_output([str(binary),'--regex']);assert actual_rule==candidate_rule==(crate/'src/default.regex').read_bytes()
 report.update(binary_sha256=sha(binary),oracle_sha256=sha(lib),regex_sha256=hashlib.sha256(actual_rule).hexdigest())
 expected=[]
 for text in cases:
  raw=text.encode();offset=0;ranges=[];error=None
  while offset<len(raw):
   pair=(ctypes.c_int*2)();suffix=raw[offset:];buffer=ctypes.create_string_buffer(suffix);code=oracle.reference_search(buffer,len(suffix),pair)
   if code<0:
    if code!=-1:error=code
    break
   start,end=pair;assert 0<=start<end<=len(suffix)
   ranges.append([offset+start,offset+end]);offset+=end
  expected.append({'ranges':ranges,'error':error})
 payload=''.join(json.dumps(s,ensure_ascii=False)+'\n' for s in cases)
 got=subprocess.run([str(binary)],input=payload,capture_output=True,text=True,timeout=60,check=True)
 actual=[json.loads(line) for line in got.stdout.splitlines()];assert len(actual)==len(cases)
 for i,(want,found) in enumerate(zip(expected,actual)):
  if want['error'] in [-15,-17,-18,-19] and found.get('error')=='Budget(Engine)':report['bounded'].append({'case':i,'reference_error':want['error']});continue
  if want['error'] is not None or found.get('ranges')!=want['ranges']:
   report['failures'].append({'case':i,'text':cases[i],'reference':want,'candidate':found})
  else:report['matches']+=1
 report['sources']={str(p.relative_to(root)):sha(p) for folder in ['desktop/aizome/crates/hotaru-link-regex/src','desktop/aizome/crates/hotaru-link-regex/tests','tools'] for p in (root/folder).rglob('*') if p.is_file()}
report['status']='passed' if not report['failures'] else 'failed';a.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['status','cases','matches','bounded','failures']}));raise SystemExit(bool(report['failures']))
