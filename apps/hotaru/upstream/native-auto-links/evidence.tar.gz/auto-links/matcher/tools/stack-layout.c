/* Diagnostic only: ask the exact implementation for its private stack layout. */
#include "regexec.c"
#include <stdio.h>
extern const unsigned char *reference_regex(void);
extern size_t reference_regex_length(void);
int main(void) {
    OnigEncoding encoding[] = {ONIG_ENCODING_UTF8};
    if (onig_initialize(encoding,1) != 0) return 1;
    OnigRegex regex=NULL;
    const unsigned char *p=reference_regex();
    if (onig_new(&regex,p,p+reference_regex_length(),0,ONIG_ENCODING_UTF8,ONIG_SYNTAX_DEFAULT,NULL) != 0) return 1;
    printf("{\"stack_entry_bytes\":%zu,\"pointer_entry_bytes\":%zu,\"pointer_entries\":%d,\"initial_stack_entries\":%d}\n", sizeof(StackType), sizeof(StkPtrType), PTR_NUM_SIZE(regex), INIT_MATCH_STACK_SIZE);
    onig_free(regex);
    return 0;
}
