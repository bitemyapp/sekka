/* Independent diagnostic: exact library/header plus the actual Zig rule bytes. */
#include <stddef.h>
#include "oniguruma.h"
extern const unsigned char *reference_regex(void);
extern size_t reference_regex_length(void);
int reference_search(const unsigned char *text, size_t len, int out[2]) {
    OnigEncoding encoding[] = {ONIG_ENCODING_UTF8};
    int code = onig_initialize(encoding, 1);
    if (code != ONIG_NORMAL) return code;
    OnigRegex regex = NULL;
    const unsigned char *pattern = reference_regex();
    code = onig_new(&regex, pattern, pattern + reference_regex_length(),
                    ONIG_OPTION_NONE, ONIG_ENCODING_UTF8, ONIG_SYNTAX_DEFAULT, NULL);
    if (code != ONIG_NORMAL) return code;
    OnigRegion *region = onig_region_new();
    OnigMatchParam *param = onig_new_match_param();
    if (region == NULL || param == NULL) { code = ONIGERR_MEMORY; goto done; }
    code = onig_set_retry_limit_in_search_of_match_param(param, 100000);
    if (code != ONIG_NORMAL) goto done;
    code = onig_search_with_param(regex, text, text + len, text, text + len,
                                  region, ONIG_OPTION_NONE, param);
    if (code >= 0) { out[0] = region->beg[0]; out[1] = region->end[0]; code = 0; }
done:
    if (param != NULL) onig_free_match_param(param);
    if (region != NULL) onig_region_free(region, 1);
    onig_free(regex);
    return code;
}
