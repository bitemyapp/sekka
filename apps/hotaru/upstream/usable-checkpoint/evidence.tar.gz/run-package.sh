#!/usr/bin/env bash
set -euo pipefail
base=/home/callen/work/hotaru-usable-checkpoint-20261028
mirror=/home/callen/work/sekka-hotaru-nix-20261028
exec 9>/home/callen/.cache/hotaru-workstation.lock
flock -x 9
/nix/var/nix/profiles/default/bin/nix build "path:$mirror#hotaru" --no-update-lock-file --out-link "$base/result" --cores 32 --max-jobs 2 -L >"$base/nix-build.log" 2>&1
python3 "$base/nix-checkpoint.py" --root "$base" --scope 'Usable CPU-rendered Aizome app with semantic metadata, DECALN and automatic links; deferred margin, GPU and OSC52 experiments excluded'
prepared=$(python3 -c 'import json;print(json.load(open("/home/callen/work/hotaru-usable-checkpoint-20261028/package-checkpoint.json"))["source"])')
/nix/var/nix/profiles/default/bin/nix-store --add-root "$base/prepared-source" --indirect --realise "$prepared"
bash "$base/qualify.sh" "$mirror" "$base/result" "$prepared" "$base/native" /home/callen/work/hotaru-sprites-geometric-20261028/oracle-expanded/libsprites-fast.so >"$base/qualification.log" 2>&1
